<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Candidate extends Model
{

    protected $primaryKey = 'Id';
    protected $fillable = [
        'JobTitle',
        'Name',
        'Email',
        'ContactNo',
        'CurrentLocation',
        'PrefferedLocation',
        'Dob',
        'MaritalStatus',
        'Gender',
        'FatherName',
        'Nationality',
        'Interest',
        'Languages',
        'job_id',
        'status_id',
        'Summary',
        'ResumeLink',
        'ResumePath',
        'Source',
        'MRFId',
        'IsActive',
        'TotalExperience',
        'CurrentSalary',
        'SalaryExpectation',
        'NoticePeriod',
        'IsDeleted',
        'CreatedBy',
        'CreatedOn',
        'UpdatedBy',
        'UpdatedOn',
        'link_used'
    ];
    public function candidate_history()
    {
        return $this->hasMany(candidate_history::class, 'candidate_id','Id');
    }

    public function candidate_status()
{
    return $this->belongsTo(candidate_status::class, 'status_id');
}
    

    public function job()
    {
        return $this->belongsTo(Job::class, 'job_id')->with('department','jobassigned');
    }
    public function feedbacks()
    {
        return $this->hasMany(Feedback::class);
    }
   
    public function ProjectWork()
    {
        return $this->hasMany(ProjectWork::class, 'CandidateId','Id');
    }

    public function CandidateSkill()
    {
        return $this->hasMany(CandidateSkill::class, 'CandidateId', 'Id');
    }

    public function Certificates()
    {
        return $this->hasMany(Certificates::class, 'CandidateId', 'Id');
    }
    
    public function CandidateQualification()
    {
        return $this->hasMany(CandidateQualification::class, 'CandidateId');
    }

    public function CandidateExperience()
    {
        return $this->hasMany(CandidateExperience::class, 'CandidateId');
    }
    protected $table = 'candidate';

    public $timestamps = false; // Disable default timestamps
    
}
