<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CandidateExperience extends Model
{
    use HasFactory;
    protected $table = 'candidateexperience';
    protected $primaryKey = 'Id';

    protected $fillable = [
        'CandidateId',
        'CompanyName',
        'Designation',
        'StartDate',
        'EndDate',
    ];
    public function candidate()
    {
        return $this->belongsTo(Candidate::class, 'CandidateId', 'Id');
    }
}
