<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CandidateSkill extends Model
{
    use HasFactory;
    protected $primaryKey = 'Id';
    protected $table = 'CandidateSkill';
    protected $fillable = [
        'CandidateId',
        'name',
        'technology',
        'comments',
    ];
    public function candidate()
    {
        return $this->belongsTo(Candidate::class, 'CandidateId', 'Id');
    }

}
