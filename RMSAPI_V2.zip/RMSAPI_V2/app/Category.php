<?php

namespace App;

use App\Scopes\CompanyScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

// use Observers\ZoomCategoryObserver;

class Category extends Model
{
    
    protected $table = 'zoom_categories';
    protected $fillable = [];

   
}
