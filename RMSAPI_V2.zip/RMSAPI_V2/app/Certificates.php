<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Certificates extends Model
{
    use HasFactory;
    protected $primaryKey = 'Id';
    protected $table = 'Certificates';
    protected $fillable = [
        'CandidateId',
        'name',
        'link',
        'description',
    ];
    public function candidate()
    {
        return $this->belongsTo(Candidate::class, 'CandidateId', 'Id');
    }
}
