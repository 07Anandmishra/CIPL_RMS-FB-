<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
     protected $guarded = [];
 public function department(){
   return $this->belongsTo(Department::class, 'department_id');

   

}
    public function headOfDepartments()
    {
        return $this->hasMany(HeadOfDepartment::class);
    }
    //remove if not work
    public function headOfDepartment()
    {
        return $this->hasOne(HeadOfDepartment::class, 'DepartmentId', 'id');
    }

    public function onboard()
    {
        return $this->hasMany(Onboard::class);
    }
}
