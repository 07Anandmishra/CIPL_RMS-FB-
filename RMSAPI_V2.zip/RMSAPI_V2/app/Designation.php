<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Designation extends Model
{
    //
    public function onboard()
    {
        return $this->hasMany(Onboard::class);
    }
    public function jobApplications()
    {
        return $this->hasMany(JobApplication::class, 'designation_id');
    }
}
