<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmailLog extends Model
{
    use HasFactory;
    protected $table = 'email_logs';
    protected $primaryKey = 'id';
    protected $fillable = [
        'recipient',
        'subject',
        'body',
        'candidate_id',
        'Sender'
    ];
}
