<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $fillable = [
        'job_application_id',
        'interview_schedule_id',
        'remark',
        'status',
        'assignBy',
        'assignTo'
    ];
    public function candidate()
    {
        return $this->belongsTo(Candidate::class);
    }

    public function interviewSchedule()
    {
        return $this->belongsTo(InterviewSchedule::class);
    }
}
