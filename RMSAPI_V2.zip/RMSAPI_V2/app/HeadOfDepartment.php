<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HeadOfDepartment extends Model
{
    use HasFactory;
    protected $table = 'headofdepartment';
    protected $primaryKey = 'Id'; // Or whatever your primary key column is named


    protected $fillable = [
        'Name', 
        'Email', 
        'MobileNo', 
        'DepartmentId'
    ];

    /**
     * Get the department that the head of department belongs to.
     */
    public function department()
    {
        return $this->belongsTo(Department::class);
    }
}
