<?php

namespace App\Http\Controllers\API;
use Illuminate\Support\Facades\Log; 
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\JobApplication;
use App\Job;
class AdminApplicationArchiveController extends Controller
{

    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,                                                                         
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }

    // public function data(Request $request)
    // {
        
    //     if(!auth()->user()->cans('view_job_applications')){
    //         return $this->errorJson('Not authenticated to perform this request',403);
    //     }else{
       
    //     //     $jobApplications = JobApplication::with([
    //     //     'job'
    //     //     // 'qualification',
    //     //     // 'subqualifications',
    //     //     // 'status:id,status',
    //     // ])->onlyTrashed();
    //     $jobApplications = JobApplication::all();

    //        // $jobApplications = $jobApplications->get();
           
    //         if($jobApplications){
    //     return $this->successJson('Candidate database list Successfully',200,$jobApplications);
    //     }else{
    //     return $this->errorJson('Candidate database not founds',404);
    //     }
        
    //     }
    // }


    public function data(Request $request)
{
    if (!auth()->user()->cans('view_candidate')) {
        return $this->errorJson('Not authenticated to perform this request', 403);
    }

    try {
        // Fetch job applications
        $jobApplications = JobApplication::all();

        if ($jobApplications->isEmpty()) {
            return $this->errorJson('Candidate database not found', 404);
        }

        return $this->successJson('Candidate database list retrieved successfully', 200, $jobApplications);
    } catch (\Throwable $th) {
        return $this->errorJson('Something went wrong', 500, $th->getMessage());
    }
}



   

   
//     public function recruitment_type( $recruitment_type)
   
//     {
//     try {
//     //     $jobApplications = JobApplication::select(
//     //         'job_applications.full_name',
//     //         'job_applications.email',
//     //         'job_applications.phone',
//     //         'jobs.pid',
//     //         'qualifications.name as qualification_name' // Alias for qualification name
//     //     )
//     //     ->join('jobs', 'job_applications.job_id', '=', 'jobs.id')
//     //     ->leftJoin('qualifications', 'job_applications.qualifications_id', '=', 'qualifications.id')
//     //     ->where('jobs.recruitment_type', $recruitment_type)
//     //    ->wherenull('job_applications.deleted_at')
//     //     ->get();

//     // Retrieve job applications that have been soft deleted
//     $jobApplications = Job::join('job_applications', 'jobs.id', '=', 'job_applications.job_id')
//     ->leftJoin('qualifications', 'job_applications.qualifications_id', '=', 'qualifications.id')
//     ->select(
//      'job_applications.full_name',
//      'job_applications.email',
//      'job_applications.phone',
//      'job_applications.id',
//      'jobs.pid',
//      'qualifications.name as qualification_name' 
//     )
//     ->where('jobs.recruitment_type', $recruitment_type) 
//     ->whereNotNull('job_applications.deleted_at') 
//     ->get();

//         if ($jobApplications->isEmpty()) {
//             return $this->errorJson('No job applications found for the specified recruitment type', 404);
//         }

//         // Return success response with job applications
//         return $this->successJson('Job applications filtered by recruitment type successfully retrieved', 200, $jobApplications);
//     } catch (\Exception $e) {
//         // Return error response in case of exception
//         return $this->errorJson('Error retrieving job applications', 500, $e->getMessage());
//     }

// }




public function recruitment_type($recruitment_type)
{
    try {
        // Retrieve job applications that have been soft deleted and match the recruitment type
        $jobApplications = Job::join('job_applications', 'jobs.id', '=', 'job_applications.job_id')
            ->leftJoin('qualifications', 'job_applications.qualifications_id', '=', 'qualifications.id')
            ->select(
                'job_applications.full_name',
                'job_applications.email',
                'job_applications.phone',
                'job_applications.id',
                'jobs.pid',
                'qualifications.name as qualification_name'
            )
            ->where('jobs.recruitment_type', $recruitment_type)
            ->whereNotNull('job_applications.deleted_at')
            ->get();

        // Check if job applications are found
        if ($jobApplications->isEmpty()) {
            return $this->errorJson('No job applications found for the specified recruitment type', 404);
        }

        // Return success response with job applications
        return $this->successJson('Job applications filtered by recruitment type successfully retrieved', 200, $jobApplications);
    } catch (\Exception $e) {
        // Return error response in case of exception
        return $this->errorJson('Error retrieving job applications', 500, $e->getMessage());
    }
}


// public function recruitment_typedel($recruitment_type)
// {
//     try {

//         // $jobApplications = Job::join('job_applications', 'jobs.id', '=', 'job_applications.job_id')
//         // ->select('job_applications.full_name','job_applications.email','job_applications.phone', 'jobs.pid')
// //         // ->where('jobs.recruitment_type', $recruitment_type) // Add recruitment_type filter
//         // ->WhereNotNull('job_applications.deleted_at')
//         // ->get();


//  // Retrieve job applications that have been soft deleted
//  $jobApplications = Job::join('job_applications', 'jobs.id', '=', 'job_applications.job_id')
//  ->leftJoin('qualifications', 'job_applications.qualifications_id', '=', 'qualifications.id')
//  ->select(
//      'job_applications.full_name',
//      'job_applications.email',
//      'job_applications.phone',
//      'jobs.pid',
//      'qualifications.name as qualification_name' // Alias for qualification name
//  )
//  ->where('jobs.recruitment_type', $recruitment_type) // Add recruitment_type filter
//  ->whereNotNull('job_applications.deleted_at') // Check for soft-deleted records
//  ->get();

//         // Return success response with job applications
//         return $this->successJson('Soft deleted job applications filtered by recruitment type successfully retrieved', 200, $jobApplications);
//     } catch (\Exception $e) {
//         // Return error response in case of exception
//         return $this->errorJson('Error retrieving job applications', 500, $e->getMessage());
//     }
// }

public function recruitment_typedel($recruitment_type)
{
    try {
        // Retrieve job applications that have been soft deleted and match the recruitment type
        $jobApplications = Job::join('job_applications', 'jobs.id', '=', 'job_applications.job_id')
            ->leftJoin('qualifications', 'job_applications.qualifications_id', '=', 'qualifications.id')
            ->select(
                'job_applications.full_name',
                'job_applications.email',
                'job_applications.phone',
                'jobs.pid',
                'qualifications.name as qualification_name' // Alias for qualification name
            )
            ->where('jobs.recruitment_type', $recruitment_type) // Add recruitment_type filter
            ->whereNotNull('job_applications.deleted_at') // Check for soft-deleted records
            ->get();

        // Check if job applications are found
        if ($jobApplications->isEmpty()) {
            return $this->errorJson('No soft deleted job applications found for the specified recruitment type', 404);
        }

        // Return success response with job applications
        return $this->successJson('Soft deleted job applications filtered by recruitment type successfully retrieved', 200, $jobApplications);
    } catch (\Exception $e) {
        // Return error response in case of exception
        return $this->errorJson('Error retrieving job applications', 500, $e->getMessage());
    }
}



}
