<?php

namespace App\Http\Controllers\API;
use App\Providers\SmsService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\EmailLog;
use Illuminate\Support\Facades\View; 
use App\User;
use App\Onboard;
use App\Currency;
use App\Department;
use App\Designation;
use App\Helper\Files;
use App\Helper\Reply;
use App\OnboardFiles;
use App\JobApplication;
use App\JobRecruitment;
use Mail;
use App\Notifications\JobOffer;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Requests\Onboard\StoreRequest;
use App\Http\Requests\Onboard\UpdateStatus;
use App\JobOfferQuestion;
use App\JobOnboardQuestion;
use App\OnboardAnswer;
use App\Notifications\JobOfferAccepted;
use App\Notifications\JobOfferRejected;
use Illuminate\Support\Facades\Notification;
use App\candidate_status;
use App\candidate_history;
use App\Candidate;
use App\Mail\OfferLetterResponse;
use App\Mail\JobOfferMail;
class AdminJobOnboardController extends Controller
{

    
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }


    public function store(Request $request,$Candidateid)
    { 
        // Find the job application using CandidateId
        $jobApplication = JobApplication::where('CandidateId', $Candidateid)->firstOrFail();

        // Get the JobApplication ID
        $jobApplicationId = $jobApplication->id;

        $application = JobApplication::findOrFail($jobApplicationId);
        // Save On Board Details

        //$check=Onboard::where(['job_application_id'=>$id,'hired_status'=>'offered'])->count();
           $check = Onboard::where('job_application_id', $jobApplicationId)->where(function ($query) {
     	   $query->where('hired_status', 'offered')
              ->orWhere('hired_status', 'accepted');
         })->count(); 
        if(empty($check)){
            $onBoard = new Onboard();      
            $onBoard->job_application_id = $application->id;
            $onBoard->department_id      = $request->department_id;
            $onBoard->degination     = $request->degination;
            $onBoard->currency_id        = $request-> currency_id; 
            $onBoard->salary_offered     = $request->salary_offered ;
            $onBoard->joining_date      = $request->joining_date;
            $onBoard->reports_to_id     = $request->reports_to_id;
            $onBoard->hired_status    = 'offered';
            $onBoard->accept_last_date   = $request->last_date;
            $onBoard->offer_code         = Str::random(18);
            $onBoard->message         = $request->message;
            $onBoard->template_id         = $request->template_id;
            $onBoard->save();
            // $names = $request->name;
            // $files = $request->file;
           //echo  $onBoard;
            if ($request->send_email=='yes') {
                Log::info('Sending offer email to candidate.', ['application_id' => $application->id, 'candidate_id' => $application->CandidateId]);
                 $this->sendOffer($application->id);    
              
            } 
    
            if(!empty($onBoard)){
 

                return $this->successJson('Offer Letter Sent',200,$onBoard);
            }else{
                return $this->successJson('Not Found Details',200);
            }
        }else{
           return $this->errorJson('Offer letter already sent',409);
        }
        
      
    }
//


// public function store(Request $request, $id)
// {
//     try {
//         // Find the job application by ID
//         $application = JobApplication::findOrFail($id);

//         // Check if an offer has already been made or accepted
//         $check = Onboard::where('job_application_id', $id)
//             ->where(function ($query) {
//                 $query->where('hired_status', 'offered')
//                     ->orWhere('hired_status', 'accepted');
//             })->count();

//         if (empty($check)) {
//             // Create a new Onboard record
//             $onBoard = new Onboard();
//             $onBoard->job_application_id = $application->id;
//             $onBoard->joining_date = $request->joining_date;
//             $onBoard->hired_status = 'offered'; 
//             $onBoard->offer_code = Str::random(18);
//             $onBoard->message = $request->message;
//             $onBoard->template_id = $request->template_id;
//             $onBoard->save();
//            // echo "onboard detail " . $application->id;
//             Log::info("Created new Onboard record for application ID: {$id}");
//             // Send offer email if requested
//             if ($request->send_email == 'yes') {
//                 $this->sendOffer($application->id);
//                 Log::info("Offer email sent for application ID: {$id}");
//             }

//             if (!empty($onBoard)) {
//                 return $this->successJson('Offer Letter Sent', 200, $onBoard);
//             } else {
//                 Log::warning("Failed to create Onboard record for application ID: {$id}");
//                 return $this->errorJson('Not Found Details', 200);
//             }
//         } else {
//             return $this->errorJson('Offer letter already sent', 409);
//         }
//     } catch (\Exception $e) {
//         // Return error response in case of exception
//         return $this->errorJson('An error occurred while processing the request', 500, $e->getMessage());
//     }
// }


    // public function sendOffer($userID)
    // {
       
    //     $jobApplication = JobApplication::select('id', 'job_id', 'full_name', 'email','jobrecruitment_id')
    //     ->with(['job:id','recruitment','onboard:id,offer_code,job_application_id,hired_status'])
    //     ->where('id', $userID)->first();
      
    //     if ($jobApplication->onboard->hired_status !== 'offered') {
    //         $jobApplication->onboard->hired_status = 'offered';

    //         $jobApplication->onboard->save();
    //     }
    //     //Notification::send($admins, new JobOffer($jobApplication));
    //     // Send Email Or Sms to applicant.Request
    //    return  $jobApplication->notify(new JobOffer($jobApplication));

        
    // }


    // public function sendOffer($userID)
    // {
    //     try {
    //         // Fetch the job application with the necessary relationships
    //         $jobApplication = JobApplication::select('id', 'job_id', 'full_name', 'email', 'jobrecruitment_id','CandidateId','JobTitle')
    //             ->with(['job:id', 'recruitment', 'onboard:id,offer_code,accept_last_date,job_application_id,hired_status'])
    //             ->where('id', $userID)
    //             ->first();
            
    //         $candidateId = $jobApplication->CandidateId;

    //         // Find the candidate in the candidate table using the CandidateId
    //         $candidate = Candidate::findOrFail($candidateId);
    //         // Check if the job application exists
    //         if (!$jobApplication) {
    //             return $this->errorJson('Job application not found', 404);
    //         }

    //         // Check and update the hired status
    //         if ($jobApplication->onboard->hired_status !== 'offered') {
    //             $jobApplication->onboard->hired_status = 'offered';
    //             $jobApplication->onboard->save();
    //             Log::info("Updated hired status to 'offered' for job application ID: {$jobApplication->id}");
    //         }


    //         Notification::send($jobApplication,new JobOffer($jobApplication));
        

    //         candidate_history::create([
    //             'remarks' => 'Offer latter send..',
    //             'status_id' =>15,
    //             //'status_id' => $request->input('status_id'),// for dynamic
    //             'candidate_id' => $jobApplication->CandidateId,
    //             'isactive' => 1,
    //         ]);
    //         $candidate->status_id = 15; // or use $request->input('status_id') for dynamic values
    //         $candidate->save();

            
    //     // $jobApplication->notify(new JobOffer($jobApplication));

    //         //Log::info("Sent job offer notification to user ID: {$userID}");

    //         // Return success response
    //         return $this->successJson('Offer notification sent successfully', 200);
    //     } catch (\Exception $e) {
    //         // Return error response in case of exception
    //         return $this->errorJson('An error occurred while sending the offer', 500, $e->getMessage());
    //     }
    // }

    public function sendOffer($userID)
{
    try {
        // Fetch the job application with the necessary relationships
        $jobApplication = JobApplication::select('id', 'job_id', 'Name', 'Email', 'jobrecruitment_id', 'CandidateId', 'JobTitle')
            ->with(['job:id', 'recruitment', 'onboard:id,offer_code,accept_last_date,job_application_id,hired_status'])
            ->where('id', $userID)
            ->first();

        if (!$jobApplication) {
            Log::error("Job application not found for user ID: {$userID}");
            return $this->errorJson('Job application not found', 404);
        }

        $candidateId = $jobApplication->CandidateId;
        Log::info("Fetched job application for user ID: {$userID} with Candidate ID: {$candidateId}");

        // Find the candidate in the candidate table using the CandidateId
        $candidate = Candidate::findOrFail($candidateId);
        Log::info("Found candidate with ID: {$candidateId}");

        // Check and update the hired status
        if ($jobApplication->onboard->hired_status !== 'offered') {
            $jobApplication->onboard->hired_status = 'offered';
            $jobApplication->onboard->save();
            Log::info("Updated hired status to 'offered' for job application ID: {$jobApplication->id}");
        }

        // Send notification
        // Notification::send($jobApplication, new JobOffer($jobApplication));
         // Send email using the mailable class
         $acceptLastDate = Carbon::parse($jobApplication->onboard->accept_last_date)->format('Y-m-d');
         // Log the email content
         $emailContent = View::make('emails.job_offer', [
            'jobApplication' => $jobApplication,
            'acceptLastDate' => $acceptLastDate,
        ])->render();

        //echo $emailContent;
         \Mail::to($jobApplication->Email)->send(new JobOfferMail($jobApplication, $acceptLastDate));
         Log::info("Sent job offer email for job application ID: {$jobApplication->id}");
         

         $SenderEmail = APP_EMAIL;
                    EmailLog::create([
                        'recipient' =>$jobApplication->Email,
                        'subject' => 'Sent job offerLetter',
                        'body' => $emailContent,
                        'candidate_id' =>  $candidateId,
                        'Sender' => $SenderEmail
                    ]);
        

         // Send SMS notification to the candidate
         $smsService = new SmsService();
         $smsVariables = [
             'var1' => $candidate->Name,
             'var2' => $candidate->JobTitle,
         ];

         $smsResponse = $smsService->sendSms([$candidate->ContactNo], 'Offer', $smsVariables);
        // Record candidate history
        candidate_history::create([
            'remarks' => 'Offer letter sent..',
            'status_id' => 15,
            'candidate_id' => $jobApplication->CandidateId,
            'isactive' => 1,
        ]);
        Log::info("Recorded candidate history for candidate ID: {$candidateId}");

        // Update candidate status
        $candidate->status_id = 15;
        $candidate->save();
        Log::info("Updated candidate status to 15 for candidate ID: {$candidateId}");

        // Return success response
        return $this->successJson('Offer notification sent successfully', 200);
    } catch (\Exception $e) {
        // Log the error
        Log::error("An error occurred while sending the offer for user ID: {$userID}", ['error' => $e->getMessage()]);
        // Return error response in case of exception
        return $this->errorJson('An error occurred while sending the offer', 500, $e->getMessage());
    }
}
    //   public function view($id)
    //   {
    //      $jobApplications = Onboard::with(['applications','applications.recruitment','template','salary','files','applications.job', 'department', 'designation', 'onboardQuestion'])
    //     ->where('offer_code', $id)->where('hired_status','!=','accepted')->where('hired_status','!=','rejected')
    //     ->first();

    //     if(!empty($jobApplications)){
    //         return $this->successJson('Offer  Details',200,$jobApplications);
    //     }else{
    //         return $this->successJson('Page Not Found Details',404);
    //     }
    // }

    public function view($id)
    {
        try {
            // Fetch the job applications with the necessary relationships
            $jobApplications = Onboard::with(['applications', 'applications.recruitment', 'template', 'salary', 'files', 'applications.job', 'department', 'designation', 'onboardQuestion'])
                ->where('offer_code', $id)
                ->where('hired_status', '!=', 'accepted')
                ->where('hired_status', '!=', 'rejected')
                ->first();
    
            // Check if job applications exist
            if (!empty($jobApplications)) {
                return $this->successJson('Offer Details', 200, $jobApplications);
            } else {
                return $this->errorJson('Page Not Found', 404);
            }
        } catch (\Exception $e) {
            // Return error response in case of exception
            return $this->errorJson('An error occurred while fetching the offer details', 500, $e->getMessage());
        }
    }
    

//  public function saveOffer(Request $request)
//         {
//            try{
//             // dd($request->all());
//             $offer = Onboard::where('offer_code', $request->offer_code)->first();
//             $jobApplication = JobApplication::findOrFail($offer->applications->id);
//             //return $this->successJson('Offer  Details',200,$jobApplication);
//             if($request->type == 'accept'){
//                 $offer->hired_status = 'accepted';
//                 $jobApplication->status_id='5';       
//                 $jobApplication->save();
//             }
//             else{
//                 $offer->reject_reason = $request->reason;
//                 $offer->hired_status  = 'rejected';
// 		        $jobApplication->status_id='6';
//                 $jobApplication->save();
//             }
    
//             $offer->save();
   
//             // All admins data for send mail.
//             $admins = User::allAdmins();
//             //$admins = User::findOrFail(1);

//            if ($admins) {
//             if($request->type == 'accept'){
//                 // Send Email Or SMS to admin on accept.
//                 Notification::send($admins, new JobOfferAccepted($jobApplication));
//             }
//             else
//             {
//                 // Send Email Or SMS to admin on accept.
//                // Notification::send($admins, new JobOfferAccepted($jobApplication));

//             }
//           }
//             return $this->successJson('Thank you for your response',200,$jobApplication);
//            }catch(\Throwable $th) {
                 
//                 return $this->errorJson('something else wrong',403,$th->getMessage());
//          }

//       }


// public function saveOffer(Request $request)
// {
//     try {
//         // Retrieve the offer based on the offer code
//         $offer = Onboard::where('offer_code', $request->offer_code)->firstOrFail();

//         // Retrieve the related job application
//         $jobApplication = JobApplication::findOrFail($offer->job_application_id);

//         $candidateId = $jobApplication->CandidateId;
//         $job_id = $jobApplication->job_id;

//         // Find the candidate in the candidate table using the CandidateId
//         $candidate = Candidate::findOrFail($candidateId);

//         // $jobRecruitment = JobRecruitment::where('job_id', $jobApplication->id)->firstOrFail();
//         // $projectManager = User::findOrFail($jobRecruitment->project_manager_id);
       
//         // Check the request type and update the offer and job application accordingly
//         if ($request->type == 'accept') {
//             $offer->hired_status = 'accepted';
//             $jobApplication->status_id = 5; // Update status to accepted
//             candidate_history::create([
//                 'remarks' => 'Offer Latter Accepted',
//                 'status_id' =>9,
//                 //'status_id' => $request->input('status_id'),// for dynamic
//                 'candidate_id' => $jobApplication->CandidateId,
//                 'isactive' => 1,
//             ]);
//             $candidate->status_id = 9; // or use $request->input('status_id') for dynamic values
//             $candidate->save();

//         } else {
//             $offer->reject_reason = $request->reason;
//             $offer->hired_status = 'rejected';
//             $jobApplication->status_id = 6; // Update status to rejected

//             candidate_history::create([
//                 'remarks' => 'Offer Latter Not Accepted',
//                 'status_id' =>17,
//                 //'status_id' => $request->input('status_id'),// for dynamic
//                 'candidate_id' => $jobApplication->CandidateId,
//                 'isactive' => 1,
//             ]);
//             $candidate->status_id = 17; // or use $request->input('status_id') for dynamic values
//             $candidate->save();
//         }

//         // Save the updated offer and job application
//         $offer->save();
//         $jobApplication->save();
//         Log::info("Updated and saved offer and job application records");
//         // Retrieve all admin users
//         $admins = User::allAdmins();
//         $jobRecruitment = JobRecruitment::where('job_id', $jobApplication->job_id)->first();
//         if (!$jobRecruitment) {
//             throw new \Exception("No JobRecruitment found for job_application_id: " . $jobApplication->id);
//         }
//         Log::info("JobRecruitment found: " . $jobRecruitment->id);
//         $projectManager = User::findOrFail($jobRecruitment->project_manager);
//         $projectLeader= $projectManager->name;
       
//         // Send notification to admins if any admin users exist
//         if ($admins) {
//             if ($request->type == 'accept') {
//                 // Send notification for accepted offer
//                 //Notification::send($admins, new JobOfferAccepted($jobApplication));

//                 $status ="accepted";
//                 $joiningDate=$offer->joining_date;

//                     // Render the view to a string
//                     $emailContent = View::make('emails.offer_letter_response', [
//                         'candidate' => $candidate,
//                         'projectLeader' => $projectLeader,
//                         'JobTitle' => $candidate->JobTitle,
//                         'status' => $status,
//                         'joiningDate' => $joiningDate
//                     ])->render();

//                 Mail::to($projectManager->email)->send(new OfferLetterResponse($candidate, $projectLeader, $candidate->JobTitle, $status, $joiningDate));

//                 // Log the email content if needed
//                 $SenderEmail = APP_EMAIL;
//                     EmailLog::create([
//                         'recipient' => $projectManager->email,
//                         'subject' => 'Offer Letter Response',
//                         'body' => $emailContent,
//                         'candidate_id' =>  $candidateId,
//                         'Sender' => $SenderEmail
//                     ]);


//                 Log::info("Sent job offer accepted notification to admins");
//             } else {
//                 // Uncomment the line below if you want to send notification for rejected offer
//                 // Notification::send($admins, new JobOfferRejected($jobApplication));

//                 $status ="Reject";
//                 $emailContent = View::make('emails.offer_letter_response', [
//                     'candidate' => $candidate,
//                     'projectLeader' => $projectLeader,
//                     'JobTitle' => $candidate->JobTitle,
//                     'status' => $status
                    
//                 ])->render();
                
//                 Mail::to($projectManager->email)->send(new OfferLetterResponse($candidate, $projectLeader, $candidate->JobTitle, $status));

//                  // Log the email content if needed
//                  $SenderEmail = APP_EMAIL;
//                  EmailLog::create([
//                     'recipient' => $projectManager->email,
//                     'subject' => 'Offer Letter Response',
//                     'body' => $emailContent,
//                     'candidate_id' =>  $candidateId,
//                     'Sender' => $SenderEmail
//                 ]);

//                 Log::info("Job offer rejected notification to admins (not sent as line is commented out)");
//             }
//         }

//         // Return success response
//         return $this->successJson('Thank you for your response', 200, $jobApplication);
//     } catch (\Throwable $th) {
//         // Return error response in case of exception
//         return $this->errorJson('Something went wrong', 403, $th->getMessage());
//     }
// }


//new one 

public function saveOffer(Request $request)
{
    try {
        // Log the incoming request data
        Log::info('Received request data: ', $request->all());

        // Retriseve the offer based on the offer code
        $offerCode = $request->offer_code;
        Log::info('Searching for Onboard with offer_code: ' . $offerCode);
        $offer = Onboard::where('offer_code', $offerCode)->firstOrFail();

        // Retrieve the related job application
        $jobApplication = JobApplication::findOrFail($offer->job_application_id);

        $candidateId = $jobApplication->CandidateId;
        $job_id = $jobApplication->job_id;

        // Find the candidate in the candidate table using the CandidateId
        $candidate = Candidate::findOrFail($candidateId);

        // Check the request type and update the offer and job application accordingly
        if ($request->type == 'accept') {
            $offer->hired_status = 'accepted';
            $jobApplication->status_id = 5; // Update status to accepted
            candidate_history::create([
                'remarks' => 'Offer Letter Accepted',
                'status_id' => 9,
                'candidate_id' => $jobApplication->CandidateId,
                'isactive' => 1,
            ]);
            $candidate->status_id = 9; // or use $request->input('status_id') for dynamic values
            $candidate->save();
        } else {
            $offer->reject_reason = $request->reason;
            $offer->hired_status = 'rejected';
            $jobApplication->status_id = 6; // Update status to rejected

            candidate_history::create([
                'remarks' => 'Offer Letter Not Accepted',
                'status_id' => 17,
                'candidate_id' => $jobApplication->CandidateId,
                'isactive' => 1,
            ]);
            $candidate->status_id = 17; // or use $request->input('status_id') for dynamic values
            $candidate->save();
        }

        // Save the updated offer and job application
        $offer->save();
        $jobApplication->save();
        Log::info("Updated and saved offer and job application records");

        // Retrieve all admin users
        $admins = User::allAdmins();
        $jobRecruitment = JobRecruitment::where('id',$candidate->MRFId)->firstOrFail();
        Log::info("JobRecruitment found: " . $jobRecruitment->id);
        $projectManager = User::findOrFail($jobRecruitment->project_manager);
        $projectLeader = $projectManager->name;

        // Send notification to admins if any admin users exist
        if ($admins) {
            $status = $request->type == 'accept' ? 'accepted' : 'rejected';
            $joiningDate = $request->type == 'accept' ? $offer->joining_date : null;

            // Render the view to a string
            $emailContent = View::make('emails.offer_letter_response', [
                'candidate' => $candidate,
                'projectLeader' => $projectLeader,
                'JobTitle' => $candidate->JobTitle,
                'status' => $status,
                'joiningDate' => $joiningDate
            ])->render();

            Mail::to($projectManager->email)->send(new OfferLetterResponse($candidate, $projectLeader, $candidate->JobTitle, $status, $joiningDate));

            // Log the email content if needed
            $SenderEmail = config('app.email');
            EmailLog::create([
                'recipient' => $projectManager->email,
                'subject' => 'Offer Letter Response',
                'body' => $emailContent,
                'candidate_id' => $candidateId,
                'Sender' => $SenderEmail
            ]);

            Log::info("Sent job offer " . $status . " notification to admins");
        }

        // Return success response
        return $this->successJson('Thank you for your response', 200, $jobApplication);
    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        Log::error('Model not found: ' . $e->getMessage());
        return $this->errorJson('Invalid offer code or job application not found', 404, $e->getMessage());
    } catch (\Throwable $th) {
        Log::error('Error in saveOffer: ' . $th->getMessage());
        return $this->errorJson('Something went wrong', 403, $th->getMessage());
    }
}


///admin onboad list






// public function onboadList($onboadList){
//     $jobApplications = Onboard::select('on_board_details.id','on_board_details.message','on_board_details.cancel_reason','on_board_details.reject_reason', 'job_applications.id as application_id', 'job_applications.full_name', 'jobs.erf_id', 'jobrecruitments.location as location', 'on_board_details.joining_date', 'on_board_details.accept_last_date', 'on_board_details.hired_status')
//             ->join('job_applications', 'job_applications.id', 'on_board_details.job_application_id')
//             ->leftJoin('jobs', 'jobs.id', 'job_applications.job_id')
//             ->leftjoin('jobrecruitments', 'jobrecruitments.id', 'job_applications.jobrecruitment_id')
//             ->leftjoin('application_status', 'application_status.id', 'job_applications.status_id')
//             ->where('jobs.recruitment_type',$onboadList)
//             ->get();
//             return $this->successJson('onboard list',200,$jobApplications);
// }

public function onboadList($onboadList)
{
    try {
        $jobApplications = Onboard::select(
            'on_board_details.id',
            'on_board_details.message',
            'on_board_details.cancel_reason',
            'on_board_details.reject_reason',
            'job_applications.id as application_id',
            'job_applications.full_name',
            'jobs.erf_id',
            'jobrecruitments.location as location',
            'on_board_details.joining_date',
            'on_board_details.accept_last_date',
            'on_board_details.hired_status'
        )
        ->join('job_applications', 'job_applications.id', 'on_board_details.job_application_id')
        ->leftJoin('jobs', 'jobs.id', 'job_applications.job_id')
        ->leftJoin('jobrecruitments', 'jobrecruitments.id', 'job_applications.jobrecruitment_id')
        ->leftJoin('application_status', 'application_status.id', 'job_applications.status_id')
        ->where('jobs.recruitment_type', $onboadList)
        ->get();

        if ($jobApplications->isEmpty()) {
            return $this->errorJson('No onboard details found for the specified recruitment type', 404);
        }

        return $this->successJson('Onboard list', 200, $jobApplications);
    } catch (\Exception $e) {
        return $this->errorJson('Error retrieving onboard list', 500, $e->getMessage());
    }
}


// public function updateStatus(Request $request, $id)
// {
//     $onboard = Onboard::findOrFail($id);
//     $onboard->cancel_reason = $request->cancel_reason;
//     $onboard->hired_status = 'canceled';
//     $onboard->save();   

//     return $this->successJson('Update Successfully',200,$onboard);
// }


public function updateStatus(Request $request, $id)
{
    try {
        // Find the onboard record by ID or throw a 404 error if not found
        $onboard = Onboard::findOrFail($id);

        // Update the cancel_reason and hired_status fields
        $onboard->cancel_reason = $request->cancel_reason;
        $onboard->hired_status = 'canceled';
        Log::info("Updated onboard record with cancel_reason: {$request->cancel_reason} and hired_status: canceled");

        // Save the updated onboard record
        $onboard->save();
        Log::info("Saved updated onboard record with ID: {$id}");
        // Return a success response with the updated onboard data
        return $this->successJson('Update Successfully', 200, $onboard);
    } catch (\Exception $e) {
        // Return an error response in case of exception
        return $this->errorJson('Error updating status', 500, $e->getMessage());
    }
}

public function getOnboardPermissions()
{
    $users = User::with('role.role.permissions')->get();
    $requiredPermissions = [62,63,93]; 
    $OnboardPermissions = [];
    foreach ($users as $user) {
        // Check if the user's role has any of the required permissions
        $hasPermission = collect($user['role']['role']['permissions'])
            ->whereIn('permission_id', $requiredPermissions)
            ->isNotEmpty(); 
            
        if ($hasPermission) {
            $OnboardPermissions[] = [
                'id' => $user['id'],
                'name' => $user['name']
            ];
        }
    }

        return response()->json([
            'OnboardPermissions' => $OnboardPermissions
        ]);
    
}


}
