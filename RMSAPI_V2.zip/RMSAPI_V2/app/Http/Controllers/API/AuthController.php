<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log; 
class AuthController extends Controller
{
  

    // public function login(Request $request)
    // {
    //     $loginData = $request->validate([
    //         'email' => 'email|required',
    //         'password' => 'required'
    //     ]); 

    //     if (!auth()->attempt($loginData)) {
    //         return response()->json([
    //             'code' => 401,
    //             'message' =>  'Enter valid credentials',
    //             'status'=>0,
    //             ]);
    //     }else{
           
    //         $user = $request->user();    
    //         $tokenResult = $user->createToken('CIPL');
    //         $token = $tokenResult->token;
            
    //        //get permission and roles
    //         $data=User::with('roles.permissions.permission')->find(auth()->user()->id);
    //         $userPermissions = array();
    //         foreach ($data->roles[0]->permissions as $key => $value) {
    //             $userPermissions[] = $value->permission->name;
    //         }
    //         $data['userPermissions'] = $userPermissions;
    //         return response()->json([
    //             'access_token' => $tokenResult->accessToken,
    //             'token_type' => 'Bearer',
                 
    //               'code' => 200,
    //               'data' => $data,
    //               'message' => 'Login successful!!',
    //               'status'=>1,
    //            ]);
    //     }

       

    // }

    public function login(Request $request)
{
    try {
        // Validate the login data
        $loginData = $request->validate([
            'email' => 'email|required',
            'password' => 'required'
        ]);

        // Attempt to authenticate the user with the provided credentials
        if (!auth()->attempt($loginData)) {
            // Return a response with an error message if authentication fails
            return response()->json([
                'code' => 401,
                'message' => 'Enter valid credentials',
                'status' => 0,
            ]);
        } else {
            // Get the authenticated user
            $user = $request->user();

            // Create a token for the user
            $tokenResult = $user->createToken('CIPL');
            $token = $tokenResult->token;
         
            // Get the user's roles and permissions
            $data = User::with('roles.permissions.permission')->find(auth()->user()->id);
            $userPermissions = array();
            foreach ($data->roles[0]->permissions as $key => $value) {
                $userPermissions[] = $value->permission->name;
            }
            $data['userPermissions'] = $userPermissions;

            // Return a response with the token and user data
            return response()->json([
                'access_token' => $tokenResult->accessToken,
                'token_type' => 'Bearer',
                'code' => 200,
                'data' => $data,
                'message' => 'Login successful!!',
                'status' => 1,
            ]);
        }
    } catch (\Exception $e) {
        // Return a response with an error message in case of an exception
        return response()->json([
            'code' => 500,
            'message' => 'An error occurred during login',
            'status' => 0,
            'error' => $e->getMessage(),
        ]);
    }
}

    
}
