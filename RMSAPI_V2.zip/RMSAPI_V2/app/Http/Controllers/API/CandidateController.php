<?php

namespace App\Http\Controllers\Api;
use Smalot\PdfParser\Parser as PdfParser;
use PhpOffice\PhpWord\IOFactory;
use App\Providers\SmsService;
use App\Helper\Files;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Candidate;
use App\Jobrecruitment;
use App\User;
use App\EmailLog;
use Illuminate\Support\Facades\View; 
use App\JobApplication;
use App\CandidateHistory;
use App\candidate_status;
use App\candidate_history;
use App\ProjectWork;
use App\Certificates;
use App\CandidateSkill;
use Illuminate\Support\Facades\DB; // Add this line
use Illuminate\Support\Facades\Crypt;
use Mail;
use Auth;
use Illuminate\Support\Facades\Log; 
use Illuminate\Pagination\LengthAwarePaginator;
use App\Mail\CandidateShortlisted;





class CandidateController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
 

   
    //working index
    
    public function index()
    {
        try {
            $perPage = 10; // You can change this to the desired number of items per page

            $query = Candidate::leftJoin('candidate_status', 'candidate.status_id', '=', 'candidate_status.id')
                ->leftJoin('job_applications', 'candidate.Id', '=', 'job_applications.CandidateId') // Join with job_applications table
                ->leftJoin('jobrecruitments', 'candidate.MRFId', '=', 'jobrecruitments.id')
                ->select(
                    'candidate.Id',
                    'candidate.JobTitle',
                    'candidate.Name',
                    'candidate.Email',
                    'candidate.ContactNo',
                    'candidate.CurrentLocation',
                    'candidate.PrefferedLocation',
                    'candidate.Dob',
                    'candidate.MaritalStatus',
                    'candidate.Gender',
                    'candidate.FatherName',
                    'candidate.Nationality',
                    'candidate.Interest',
                    'candidate.Languages',
                    'candidate.Summary',
                    'candidate.ResumeLink',
                    'candidate.Source',
                    'candidate.TotalExperience',
                    'candidate.CurrentSalary',
                    'candidate.SalaryExpectation',
                    'candidate.NoticePeriod',
                    'candidate.IsDeleted',
                    'candidate.CreatedBy',
                    'candidate.CreatedOn',
                    'candidate.UpdatedBy',
                    'candidate.UpdatedOn',
                    'candidate.MRFId',
                    'candidate.job_id',
                    'candidate.status_id',
                    
                    'candidate_status.name as CandidateStatus',
                    'candidate_status.id as StatusId', // if Status id needed, uncomment this line
                    'job_applications.id as JobApplicationId',
                    'jobrecruitments.M_id as M_id'
                    // Select job_applications id
                );
                //->whereNotNull('candidate.status_id');

                // Apply role-based condition
              $user = Auth::user();      
              if ($user->id != 1) {
              // If the logged-in user is a regular user, show only assigned candidates
              $query = $query->where('jobrecruitments.assignTo', $user->id); 
          }
            // Apply pagination
            $allCandidates = $query->get();
                
            $uniqueCandidates = [];
            foreach ($allCandidates as $candidate) {
                if (!isset($uniqueCandidates[$candidate->Id])) {
                    $uniqueCandidates[$candidate->Id] = [
                      'Id' => $candidate->Id,
                        'JobTitle' => $candidate->JobTitle,
                        'Name' => $candidate->Name,
                        'Email' => $candidate->Email,
                        'ContactNo' => $candidate->ContactNo,
                        'CurrentLocation' => $candidate->CurrentLocation,
                        'PrefferedLocation' => $candidate->PrefferedLocation,
                        'Dob' => $candidate->Dob,
                        'MaritalStatus' => $candidate->MaritalStatus,
                        'Gender' => $candidate->Gender,
                        'FatherName' => $candidate->FatherName,
                        'Nationality' => $candidate->Nationality,
                        'Interest' => $candidate->Interest,
                        'Languages' => $candidate->Languages,
                        'Summary' => $candidate->Summary,
                        'ResumeLink' => $candidate->ResumeLink,
                        'Source' => $candidate->Source,
                        'IsActive' => $candidate->IsActive,
                        'TotalExperience' => $candidate->TotalExperience,
                        'CurrentSalary' => $candidate->CurrentSalary,
                        'SalaryExpectation' => $candidate->SalaryExpectation,
                        'NoticePeriod' => $candidate->NoticePeriod,
                          'JobApplicationId' => $candidate->JobApplicationId,
                        'MRFId' => $candidate->MRFId,
                        'status_id' => $candidate->status_id,
                        'job_id' => $candidate->job_id,
                        'CandidateStatus' => $candidate->CandidateStatus,
                        'M_id'=>$candidate->M_id
                    ];
                }
            }

            // Paginate the transformed unique candidates
            $uniqueCandidates = array_values($uniqueCandidates);
            $totalCandidates = count($uniqueCandidates);
            $currentPage = LengthAwarePaginator::resolveCurrentPage();
            $currentCandidates = array_slice($uniqueCandidates, ($currentPage - 1) * $perPage, $perPage);
            $paginatedCandidates = new LengthAwarePaginator($currentCandidates, $totalCandidates, $perPage, $currentPage, [
                'path' => LengthAwarePaginator::resolveCurrentPath()
            ]);

            // Include pagination details and links in the response
            $response = [
                'candidates' => $currentCandidates,
                'current_page' => $paginatedCandidates->currentPage(),
                'total_pages' => $paginatedCandidates->lastPage(),
                'per_page' => $paginatedCandidates->perPage(),
                'total_candidates' => $paginatedCandidates->total(),
                'next_page_url' => $paginatedCandidates->nextPageUrl(),
                'prev_page_url' => $paginatedCandidates->previousPageUrl(),
            ];

            return $this->successJson('Candidates Details', 200, $response);
        } catch (\Exception $e) {
            return $this->errorJson('Failed to fetch candidates', 500, $e->getMessage());
        }
    }
    
    
    


    
    public function indexstatus()
    {
        try
        {
           // $condidatestatus=candidate_status::all();
            $condidatestatus = candidate_status::orderBy('name', 'asc')->get();

            if($condidatestatus->isEmpty())
            {
                return $this->errorJson('No candidates  status Found', 404, $condidatestatus);
            }
            
            return $this->successJson('candidates status Details', 200, $condidatestatus);

        }
        catch (\Exception $e) {
            return $this->errorJson('Failed to fetch candidates status', 500, $e->getMessage());
        }
    }

    public function indexhistory()
    {
        try
        {
            $condidatehistory=candidate_history::all();
            if($condidatehistory->isEmpty())
            {
                return $this->errorJson('No candidates  history Found', 404,$condidatehistory);
            }
            
            return $this->successJson('candidates history Details', 200, $condidatehistory);

        }
        catch (\Exception $e) {
            return $this->errorJson('Failed to fetch candidates history', 500, $e->getMessage());
        }
    }

    public function historyByCandidateId($candidate_id)
    {
        try {
            $candidateHistories = candidate_history::where('candidate_id', $candidate_id)->get();

            if ($candidateHistories->isEmpty()) {
                return $this->errorJson('No candidates  history Found', 404,$candidateHistories);
               // return response()->json(['message' => 'Candidate History Not Found'], 404);
            }
            Log::info("Candidate history retrieved successfully for candidate ID: {$candidate_id}");
            return $this->successJson('Candidate History Retrieved Successfully', 200, $candidateHistories);
           // return response()->json(['message' => 'Candidate History Retrieved Successfully', 'data' => $candidateHistories], 200);
        } catch (\Exception $e) {
            return $this->errorJson('Failed to fetch candidates history', 500, $e->getMessage());
        }
    }
   

    public function store(Request $request)
    {
        try {
           
            $validatedData = $request->validate([
                'JobTitle' => 'required|string|max:255',
                'Name' => 'required|string|max:255',
                // 'Email' => 'required|email|max:255|unique:candidate,email',
                'Email' => 'required|email|max:255',
                'ContactNo' => 'required|string|max:255',
                'CurrentLocation' => 'nullable|string|max:255',
                'PrefferedLocation' => 'nullable|string|max:255',
                'Dob' => 'nullable|date',
                'MaritalStatus' => 'nullable|integer',
                'Gender' => 'nullable|integer',
                'FatherName' => 'nullable|string|max:255',
                'Nationality' => 'nullable|string|max:255',
                'Interest' => 'nullable|string|max:255',
                'Languages' => 'nullable|string|max:255',
                'MRFId' => 'nullable|string|max:255',
                'job_id' => 'nullable|string|max:255',
                'Source' => 'nullable|string|max:255',
                'ResumeLink' => 'nullable|string|max:255',
                'resume_file' => 'nullable|file|mimes:pdf,doc,docx|max:2048',
            ]);
            DB::beginTransaction();

          

                // Save the candidate to the database using mass assignment
                $candidate = Candidate::create($validatedData);

                // $messagedata="Dear $request->Name, Congratulations!!! your CV has been shortlisted for job opening at Corporate Infotech Private Limited.  If you want to proceed with further process please reply YES or reply NO to stop the process.Thank you.Team CIPL";

                // Files::smssend($request->ContactNo,$messagedata);
                // echo $messagedata;
                // echo $request->ContactNo;
       



            // Handle file upload
        if (request()->hasFile('resume_file')) {
            $file = request()->file('resume_file');
            $candidateId = $candidate->Id; // Get the candidate's ID

            // Extract the file extension
            $extension = $file->getClientOriginalExtension();

            // Create a new file name using the candidate's ID and file extension
            $newFileName = $candidateId . '.' . $extension;

            // Store the file with the new name
            $filePath = $file->storeAs('Resumes/' , $newFileName, 'local');

            // Generate URL for accessing the file
            $fileUrl = 'user-uploads/Resumes/'  . $newFileName;

            // Save the file URL to the candidate's ResumePath
            $candidate->ResumePath = $fileUrl;
            $candidate->save();
        }


           // $status = candidate_status::where('name', 'Screening')->first();

          

            // Check if MRF ID is null and create candidate history if it is
        if (is_null($request->MRFId)) {
            candidate_history::create([
                'remarks' => 'New Candidate created With out MRFID',
                'status_id' => 31,
                'candidate_id' => $candidate->Id,
                'isactive' => 1,
            ]);
        $candidate->status_id = 31; // or use $request->input('status_id') for dynamic values
        $candidate->save();
        }else
        {
            candidate_history::create([
                'remarks' => 'New Candidate created With  MRFID',
                'status_id' => 1,
                'candidate_id' => $candidate->Id,
                'isactive' => 1,
            ]);
        $candidate->status_id = 1; // or use $request->input('status_id') for dynamic values
        $candidate->save();
        }

       

           // Check if MRF ID is present in the request
           if ($request->has('MRFId')) {

            //change for getting email of project lead 
            $mrf = Jobrecruitment::where('id', '=', $request->input('MRFId'))->first();
            if (!$mrf) {
                Log::error('MRF record not found for MRFId: ' . $request->input('MRFId'));
                return $this->errorJson('MRF record not found', 404);
            }

            // Log MRF record information
                Log::info('MRF record found', ['MRF' => $mrf]);
            $teamleadid=$mrf->reporting_team;
            $mail = User::where('id', '=', $teamleadid)->first();
            if (!$mail) {
                Log::error('User record not found for teamlead ID: ' . $teamleadid);
                return $this->errorJson('User record not found', 404);
            }
                    // Log User record information
                    Log::info('User record found', ['User' => $mail]);

            if ($mrf) {
               
                $projectManagerEmail = $mail->email ;
                $projectManagerName = $mail->name ;

                    // Encrypt the candidate ID
                    $encryptedCandidateId = Crypt::encrypt($candidate->Id);

                // Encrypt the action (Accept/Reject)
                $encryptedAccept = Crypt::encrypt('Accept');
                $encryptedReject = Crypt::encrypt('Reject');

                // Define the URL with encrypted parameters

                $url = config('app.AppBaseURL').'candidate/action/' . $encryptedCandidateId . '/' . $encryptedAccept;
                $url2 = config('app.AppBaseURL').'candidate/action/' . $encryptedCandidateId . '/' . $encryptedReject;
                
                 // Render the Blade view to a string
                 $body = View::make('emails.CandidateShortlist', [
                    'acceptLink' => $url,
                    'rejectLink' => $url2,
                    'candidate' => $candidate,
                    // 'Name' => $fullName,
                    'projectManagerName' => $projectManagerName
                ])->render();

                // Send email with the links
                Mail::send('emails.CandidateShortlist', ['acceptLink' => $url, 'rejectLink' => $url2,'candidate' => $candidate,'projectManagerName'=>$projectManagerName], function ($message) use ($projectManagerEmail) {
                    $message->to($projectManagerEmail)
                            ->subject('New Candidate Shortlist');
                });

                       

                 // Storing email details in the database
                 $SenderEmail = APP_EMAIL;
                    EmailLog::create([
                        'recipient' => $projectManagerEmail,
                        'subject' => 'New Candidate Shortlist',
                        'body' => $body,
                        'candidate_id' => $candidate->Id,
                        'Sender'=> $SenderEmail
                    ]);

                Log::info('Email sent to project manager', ['email' => $projectManagerEmail]);
            }
        }

        

        DB::commit();
            return $this->successJson('Candidate Created Successfully', 201, $candidate);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->errorJson('Failed to create candidate', 500, $e->getMessage());
        }
    }

    public function show($id)
    {
        try {
            Log::info('Attempting to fetch candidate data', ['CandidateId' => $id]);
    
            // Retrieve candidate by ID with related data
            try {
                $candidate = Candidate::with([
                    'CandidateQualification',
                    'CandidateExperience',
                    'ProjectWork',
                    'CandidateSkill',
                    'Certificates',
                    'candidate_history.candidate_status'
                ])
                ->where('Id', $id)
                ->first();
    
                if (!$candidate) {
                    Log::warning('Candidate not found', ['CandidateId' => $id]);
                    return $this->errorJson('Candidate not found', 404);
                }
            } catch (\Exception $e) {
                Log::error('An error occurred while fetching candidate from database', ['error' => $e->getMessage()]);
                return $this->errorJson('Failed to fetch candidate from database', 500, $e->getMessage());
            }
    
            Log::info('Candidate data retrieved successfully', ['CandidateId' => $id]);
      // Filter candidate history with non-null status_id
            $filteredHistory = $candidate->candidate_history->filter(function ($history) {
                return !is_null($history->status_id);
            });

            // Generate the URL for the resume file if it exists
            $resumeUrl = $candidate->ResumePath ? url($candidate->ResumePath) : null;
    
            // Transform the candidate data
            try {
                $candidateData = [
                    'Id' => $candidate->Id,
                    'JobTitle' => $candidate->JobTitle,
                    'MRFId' => $candidate->MRFId,
                    'IsActive' => $candidate->IsActive,
                    'IsDeleted' => $candidate->IsDeleted,
                    'CreatedBy' => $candidate->CreatedBy,
                    'CreatedOn' => $candidate->CreatedOn,
                    'UpdatedBy' => $candidate->UpdatedBy,
                    'UpdatedOn' => $candidate->UpdatedOn,
                    'ResumeLink' => $candidate->ResumeLink,
                    'Source' => $candidate->Source,
                    'link_used' => $candidate->link_used,
                    'job_id' => $candidate->job_id,
                    'status_id' => $candidate->status_id,
                    'ResumeUrl' =>$resumeUrl,
                    'Name' => $candidate->Name,
                    'Email' => $candidate->Email,
                    'ContactNo' => $candidate->ContactNo,
                    'CurrentLocation' => $candidate->CurrentLocation,
                    'PrefferedLocation' => $candidate->PrefferedLocation,
                    'Dob' => $candidate->Dob,
                    'MaritalStatus' => $candidate->MaritalStatus,
                    'Gender' => $candidate->Gender,
                    'FatherName' => $candidate->FatherName,
                    'Nationality' => $candidate->Nationality,
                    'Interest' => $candidate->Interest,
                    'Languages' => $candidate->Languages,
                    'TotalExperience'=> $candidate->TotalExperience,
                    'CurrentSalary'=>$candidate->CurrentSalary,
                    'SalaryExpectation'=>$candidate->SalaryExpectation,
                    'NoticePeriod'=>$candidate->NoticePeriod,
                    'Summary'=>$candidate->Summary,
                    'CandidateQualification' => $candidate->CandidateQualification,
                    'CandidateExperience' => $candidate->CandidateExperience,
                    'ProjectWork' => $candidate->ProjectWork,
                    'CandidateSkill' => $candidate->CandidateSkill,
                    'Certificates' => $candidate->Certificates,
                    'CandidateStatuses' => $filteredHistory->map(function ($history) {
                        return [
                            'Status' => $history->candidate_status ? $history->candidate_status->name : null,
                            'StatusId' => $history->status_id,
                            'CreatedAt' => $history->created_at,
                        ];
                    }),
                ];
    
                Log::info('Candidate data transformation completed', ['CandidateId' => $id]);
            } catch (\Exception $e) {
                Log::error('An error occurred while transforming candidate data', ['error' => $e->getMessage()]);
                return $this->errorJson('Failed to transform candidate data', 500, $e->getMessage());
            }
    
            return $this->successJson('Candidate data retrieved successfully', 200, $candidateData);
        } catch (\Exception $e) {
            Log::error('An unexpected error occurred', ['error' => $e->getMessage()]);
            return $this->errorJson('Failed to fetch candidate', 500, $e->getMessage());
        }
    }
    

    
   
    public function update(Request $request, $id)
    {
        DB::beginTransaction();
        try {
        

            $request->validate([
                'JobTitle' => 'nullable|string|max:255',
                'Name' => 'nullable|string|max:255',
                // 'Email' => 'required|email|max:255|unique:candidate,email',
                'Email' => 'nullable|email|max:255',
                'ContactNo' => 'nullable|string|max:255',
                'CurrentLocation' => 'nullable|string|max:255',
                'PrefferedLocation' => 'nullable|string|max:255',
                'Dob' => 'nullable|date',
                'MaritalStatus' => 'nullable|integer',
                'Gender' => 'nullable|integer',
                'FatherName' => 'nullable|string|max:255',
                'Nationality' => 'nullable|string|max:255',
                'Interest' => 'nullable|string|max:255',
                'Languages' => 'nullable|string|max:255',
                'MRFId' => 'nullable|string|max:255',
                'job_id' => 'nullable|string|max:255',
                'Source' => 'nullable|string|max:255',
                'ResumeLink' => 'nullable|string|max:255',
            ]);

          
            $candidate = Candidate::find($id);
            
            $jobApplication=JobApplication::where('CandidateId',$id);
            
            $status = candidate_status::where('name', $request->name)->first();
            // if (!$status) {
            //     DB::rollBack();
            //     return $this->errorJson('Status not found', 404);
            // }
            if (!$candidate) {
                return $this->errorJson('Candidate not found', 404);
            }

            if ($request->has('MRFId')) {
                $mrf = Jobrecruitment::where('id', $request->input('MRFId'))->first();
                if (!$mrf) {
                    Log::error('MRF record not found for MRFId: ' . $request->input('MRFId'));
                    return $this->errorJson('MRF record not found', 404);
                }

                if (is_null($candidate->MRFId) || $candidate->MRFId != $request->input('MRFId')) {
                    Log::info('MRF record found', ['MRF' => $mrf]);
                    $teamleadid = $mrf->reporting_team;
                    $mail = User::where('id', $teamleadid)->first();
                    if (!$mail) {
                        Log::error('User record not found for teamlead ID: ' . $teamleadid);
                        return $this->errorJson('User record not found', 404);
                    }

                    Log::info('User record found', ['User' => $mail]);
                    $projectManagerEmail = $mail->email;
                    $projectManagerName = $mail->name;

                    $encryptedCandidateId = Crypt::encrypt($candidate->Id);
                    $encryptedAccept = Crypt::encrypt('Accept');
                    $encryptedReject = Crypt::encrypt('Reject');

                    $url = config('app.AppBaseURL') . 'candidate/action/' . $encryptedCandidateId . '/' . $encryptedAccept;
                    $url2 = config('app.AppBaseURL') . 'candidate/action/' . $encryptedCandidateId . '/' . $encryptedReject;
                    // Render the Blade view to a string

                    $body = View::make('emails.CandidateShortlist', [
                        'acceptLink' => $url,
                        'rejectLink' => $url2,
                        'candidate' => $candidate,
                        // 'Name' => $fullName,
                        'projectManagerName' => $projectManagerName
                    ])->render();

                    Mail::send('emails.CandidateShortlist', ['acceptLink' => $url, 'rejectLink' => $url2, 'candidate' => $candidate, 'projectManagerName' => $projectManagerName], function ($message) use ($projectManagerEmail) {
                        $message->to($projectManagerEmail)
                            ->subject('New Candidate Shortlist');
                    });

                    // Storing email details in the database
                    $SenderEmail = APP_EMAIL;
                    EmailLog::create([
                        'recipient' => $projectManagerEmail,
                        'subject' => 'New Candidate Shortlist',
                        'body' => $body,
                        'candidate_id' => $candidate->Id,
                        'Sender'=> $SenderEmail
                    ]);

                    Log::info('Email sent to project manager', ['email' => $projectManagerEmail]);
                }
            }


            $candidate->update($request->all());
             $jobApplication->update($request->all());
            Log::info('Candidate details updated', ['candidate' => $candidate]);
            // Create or update candidate history
            candidate_history::create([
                'remarks' => 'Candidate updated',
                'status_id' => $request->status_id,
                //'status_id'=>11, 
                'candidate_id' => $candidate->Id,
                'isactive' => 1,
            ]);
        // $candidate->save();
            DB::commit();


            return $this->successJson('Candidate Updated Successfully', 200, $candidate);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->errorJson('Failed to update candidate', 500, $e->getMessage());
        }
    }

   
    public function bulkUpload(Request $request)
    {
        
        try {
            Log::info('Bulk upload process started');
            
            // Check if file is present in the request
            if (!$request->hasFile('file')) {
                Log::error('No file uploaded');
                return $this->errorJson('No file uploaded', 400);
            }

            $file = $request->file('file');
            Log::info('File uploaded', ['file_name' => $file->getClientOriginalName()]);

            // Validate file type and extension (assuming Excel file)
            if (!$file->isValid() || !in_array($file->getClientOriginalExtension(), ['xlsx', 'xls'])) {
                Log::error('Invalid file type', ['file_type' => $file->getClientOriginalExtension()]);
                return $this->errorJson('Invalid file. Please upload an Excel file.', 400);
            }

            // Parse Excel file to get candidates data
            try {
                $candidates = Excel::toArray(new YourImportClass, $file);
                Log::info('Excel file parsed successfully', ['candidates_count' => count($candidates)]);
            } catch (\Exception $e) {
                Log::error('Failed to parse Excel file', ['error' => $e->getMessage()]);
                return $this->errorJson('Failed to parse Excel file', 500, $e->getMessage());
            }

            if (empty($candidates)) {
                Log::error('No data found in the uploaded file');
                return $this->errorJson('No data found in the uploaded file', 400);
            }

            $rules = [
                'JobTitle' => 'required|string|max:255',
                'DateOfApplication' => 'required|date',
                'Name' => 'required|string|max:255',
                'EmailId' => 'required|string|email|max:255',
                'PhoneNumber' => 'required|string|max:50',
                'CurrentLocation' => 'required|string|max:255',
                'PreferredLocations' => 'required|string|max:255',
                'TotalExperience' => 'required|string|max:50',
                'KeySkills' => 'required|string|max:255',
                'AnnualSalary' => 'required|numeric',
                'NoticePeriod' => 'required|string|max:50',
                'ResumeHeadline' => 'required|string|max:255',
                'Summary' => 'required|string',
                'UnderGraduationDegree' => 'required|string|max:255',
                'UGSpecialization' => 'required|string|max:255',
                'UGUniversityName' => 'required|string|max:255',
                'UGGraduationYear' => 'required|string|max:4',
                'Gender' => 'required|string|max:10',
                'MaritalStatus' => 'required|string|max:50',
                'HomeTownOrCity' => 'required|string|max:255',
                'PinCode' => 'required|string|max:20',
                'PermanentAddress' => 'required|string',
                'MRFId' => 'nullable|string|max:255',
            ];

            DB::beginTransaction();
            Log::info('Database transaction started');
            
            $errors = [];

            foreach ($candidates as $index => $candidateData) {
                Log::info('Processing candidate', ['index' => $index]);
                
                $validator = Validator::make($candidateData, $rules);
                if ($validator->fails()) {
                    Log::error('Validation failed for candidate', ['index' => $index, 'errors' => $validator->errors()->all()]);
                    $errors[$index] = $validator->errors()->all();
                    continue;
                }

                try {
                    // Create candidate
                    $candidate = Candidate::create($candidateData);
                    Log::info('New candidate created', ['candidate_id' => $candidate->id]);

                    // Create candidate history
                    $status = candidate_status::where('name', 'Screening')->first();
                    candidate_history::create([
                        'remarks' => 'New Candidate created by bulkUpload',
                        'status_id' => $status->id,
                        'candidate_id' => $candidate->id,
                        'isactive' => 1,
                    ]);

                    // Send email if MRFId is provided
                    if ($request->has('MRFId')) {
                        $mrfId = $request->input('MRFId');
                        $mrf = Jobrecruitment::find($mrfId);
                        if (!$mrf) {
                            Log::error('MRF record not found', ['MRFId' => $mrfId]);
                            continue;
                        }

                        // Find project lead's email
                        $projectManager = User::find($mrf->reporting_team);
                        if (!$projectManager) {
                            Log::error('User record not found', ['teamlead_id' => $mrf->reporting_team]);
                            continue;
                        }

                        // Encrypt candidate ID
                        $encryptedCandidateId = Crypt::encrypt($candidate->id);

                        // Define URLs
                        $acceptUrl = config('app.AppBaseURL').'candidate/action/' . $encryptedCandidateId . '/' . Crypt::encrypt('Accept');
                        $rejectUrl = config('app.AppBaseURL').'candidate/action/' . $encryptedCandidateId . '/' . Crypt::encrypt('Reject');

                        // Send email
                        Mail::send('emails.CandidateShortlist', [
                            'acceptLink' => $acceptUrl,
                            'rejectLink' => $rejectUrl,
                            'candidate' => $candidate,
                        ], function ($message) use ($projectManager) {
                            $message->to($projectManager->email)
                                    ->subject('New Candidate Shortlist');
                        });

                        Log::info('Email sent to project manager', ['email' => $projectManager->email]);
                    }
                } catch (\Exception $e) {
                    Log::error('Failed to process candidate', ['index' => $index, 'error' => $e->getMessage()]);
                    $errors[$index] = ['Failed to process candidate: ' . $e->getMessage()];
                }
            }

            DB::commit();
            Log::info('Database transaction committed successfully');

            if (!empty($errors)) {
                Log::warning('Some candidates could not be processed', ['errors' => $errors]);
                return $this->errorJson('Some candidates could not be processed', 422, $errors);
            }

            Log::info('Bulk upload process completed successfully');
            return $this->successJson('Candidates uploaded successfully', 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Failed to upload candidates', ['error' => $e->getMessage()]);
            return $this->errorJson('Failed to upload candidates', 500, $e->getMessage());
        }
    }


    



    public function SerchCandidates(Request $request, $id = null)
    {
        try {
            $perPage = 10; // You can change this to the desired number of items per page

            $query = Candidate::leftJoin('candidate_status', 'candidate.status_id', '=', 'candidate_status.id')
                ->leftJoin('job_applications', 'candidate.Id', '=', 'job_applications.CandidateId')
                ->leftJoin('jobrecruitments', 'candidate.MRFId', '=', 'jobrecruitments.id')
                ->leftJoin('jobs', 'candidate.job_id', '=', 'jobs.id')
                ->select(
                    'candidate.Id',
                    'candidate.JobTitle',
                    'candidate.Name',
                    'candidate.Email',
                    'candidate.ContactNo',
                    'candidate.CurrentLocation',
                    'candidate.PrefferedLocation',
                    'candidate.Dob',
                    'candidate.MaritalStatus',
                    'candidate.Gender',
                    'candidate.FatherName',
                    'candidate.Nationality',
                    'candidate.Interest',
                    'candidate.Languages',
                    'candidate.Summary',
                    'candidate.ResumeLink',
                    'candidate.Source',
                    'candidate.TotalExperience',
                    'candidate.CurrentSalary',
                    'candidate.SalaryExpectation',
                    'candidate.NoticePeriod',
                    'candidate.IsDeleted',
                    'candidate.CreatedBy',
                    'candidate.CreatedOn',
                    'candidate.UpdatedBy',
                    'candidate.UpdatedOn',
                    'candidate.link_used',
                    'candidate.MRFId',
                    'candidate.job_id',
                    'candidate.status_id',
                    'jobrecruitments.M_id as M_id',
                    'jobrecruitments.numberOfInterviewRound	 as interviewround',
                    'jobrecruitments.isclientSide	 as isclientSide',
                    'candidate_status.name as CandidateStatus',
                    'job_applications.id as JobApplicationId',
                    'jobs.pid as ProjectId'
                );
                   
              // Apply role-based condition
              $user = Auth::user();      
            if ($user->id != 1) {
            // If the logged-in user is a regular user, show only assigned candidates
            $query = $query->where('jobrecruitments.assignTo', $user->id); 
        }
            if ($request->has('MRFId')) {
                $query = $query->where('candidate.MRFId', 'LIKE', '%' . $request->MRFId . '%');
            }
            
            if ($id != null) {
                $query = $query->where('candidate.MRFId', $id);
            }
            if ($request->has('status_id')) {
                $statusId = $request->status_id;
                if (!$statusId) {
                    return $this->errorJson('Invalid status', 400);
                }
                $query = $query->where('candidate.status_id', $statusId);
            }

            if ($request->has('Name')) {
                $query = $query->where('candidate.Name', 'LIKE', '%' . $request->Name . '%');
            }

            if ($request->has('CurrentLocation')) {
                $query = $query->where('candidate.CurrentLocation', 'LIKE', $request->CurrentLocation . '%');
            }

            // if ($request->has('KeySkills')) {
            //     $query = $query->where('candidate.KeySkills', 'LIKE', '%' . $request->KeySkills . '%');
            // }

            if ($request->has('TotalExperience')) {
                $query = $query->where('candidate.TotalExperience', 'LIKE', $request->TotalExperience . '%');
            }
                


            // Fetch all data without pagination
            $allCandidates = $query->get();

            $uniqueCandidates = [];
            foreach ($allCandidates as $candidate) {
                if (!isset($uniqueCandidates[$candidate->Id])) {
                    $uniqueCandidates[$candidate->Id] = [
                        'Id' => $candidate->Id,
                        'JobTitle' => $candidate->JobTitle,
                        'Name' => $candidate->Name,
                        'Email' => $candidate->Email,
                        'ContactNo' => $candidate->ContactNo,
                        'CurrentLocation' => $candidate->CurrentLocation,
                        'PrefferedLocation' => $candidate->PrefferedLocation,
                        'Dob' => $candidate->Dob,
                        'MaritalStatus' => $candidate->MaritalStatus,
                        'Gender' => $candidate->Gender,
                        'FatherName' => $candidate->FatherName,
                        'Nationality' => $candidate->Nationality,
                        'Interest' => $candidate->Interest,
                        'Languages' => $candidate->Languages,
                        'Summary' => $candidate->Summary,
                        'ResumeLink' => $candidate->ResumeLink,
                        'Source' => $candidate->Source,
                        'IsActive' => $candidate->IsActive,
                        'TotalExperience' => $candidate->TotalExperience,
                        'CurrentSalary' => $candidate->CurrentSalary,
                        'SalaryExpectation' => $candidate->SalaryExpectation,
                        'NoticePeriod' => $candidate->NoticePeriod,
                        'JobApplicationId' => $candidate->JobApplicationId,
                        'MRFId' => $candidate->MRFId,
                        'M_id' => $candidate->M_id,
                        'status_id' => $candidate->status_id,
                        'job_id' => $candidate->job_id,
                        'CandidateStatus' => $candidate->CandidateStatus,
                        'ProjectId' => $candidate->ProjectId,
                        'numberOfInterviewRound' => $candidate->interviewround	,
                        'isclientSide' => $candidate->isclientSide	
                    ];
                }
            }

            // Paginate the transformed unique candidates
            $uniqueCandidates = array_values($uniqueCandidates);
            $totalCandidates = count($uniqueCandidates);
            $currentPage = LengthAwarePaginator::resolveCurrentPage();
            $currentCandidates = array_slice($uniqueCandidates, ($currentPage - 1) * $perPage, $perPage);
            $paginatedCandidates = new LengthAwarePaginator($currentCandidates, $totalCandidates, $perPage, $currentPage, [
                'path' => LengthAwarePaginator::resolveCurrentPath()
            ]);

            if (empty($currentCandidates)) {
                return $this->errorJson('No candidates found', 404, $paginatedCandidates);
            }

            // Include pagination details and links in the response
            $response = [
                'candidates' => $currentCandidates,
                'current_page' => $paginatedCandidates->currentPage(),
                'total_pages' => $paginatedCandidates->lastPage(),
                'per_page' => $paginatedCandidates->perPage(),
                'total_candidates' => $paginatedCandidates->total(),
                'next_page_url' => $paginatedCandidates->nextPageUrl(),
                'prev_page_url' => $paginatedCandidates->previousPageUrl(),
            ];

            return $this->successJson('Candidate Details', 200, $response);
        } catch (\Exception $e) {
            return $this->errorJson('Failed to fetch candidates', 500, $e->getMessage());
        }
    }





public function actionCandidate($encryptedId,$action)
{
    Log::info('Api payload: ' . $encryptedId);
    
    DB::beginTransaction();
   
    try {
        $CandidateId = crypt::decrypt($encryptedId);
        Log::info('method calling'. crypt::decrypt($encryptedId));
        $deaction = Crypt::decrypt($action);
        Log::info('Decrypted Candidate ID: ' . $CandidateId);
        Log::info('Decrypted Action: ' . $deaction);
        $candidate = Candidate::findOrFail($CandidateId);
    
        // Check if the link has already been used
        if ($candidate->link_used) {
            return response()->json(['error' => 'This link has already been used.'], 400);
        }
       
        if ($deaction == 'Accept') {
            Log::info('Processing acceptance for candidate ID: ' . $CandidateId);

            $candidate->status_id = 2; // or use $request->input('status_id') for dynamic values
            $candidate->save();
            // Create or update candidate history
            candidate_history::create([
                'remarks' => 'Candidate Selected',
                'status_id' => 2,
                'candidate_id' => $candidate->Id,
                'isactive' => 1,
            ]);

        

            // Add entry to job_applications table
            $jobApplication = JobApplication::create([
                'CandidateId' => $candidate->Id,
                'job_id' => $candidate->job_id,
                'JobTitle' => $candidate->JobTitle,
                'Name' => $candidate->Name,
                'Email' => $candidate->Email,
                'ContactNo' => $candidate->ContactNo,
                'CurrentLocation' => $candidate->CurrentLocation,
                'PrefferedLocation' => $candidate->PrefferedLocation,
                'Dob' => $candidate->Dob,
                'MaritalStatus' => $candidate->MaritalStatus,
                'Gender' => $candidate->Gender,
                'FatherName' => $candidate->FatherName,
                'Nationality' => $candidate->Nationality,
                'Interest' => $candidate->Interest,
                'Languages' => $candidate->Languages,
                'Summary' => $candidate->Summary,
                'ResumeLink' => $candidate->ResumeLink,
                'Source' => $candidate->Source,
                'MRFId' => $candidate->MRFId,
                'TotalExperience' => $candidate->TotalExperience,
                'CurrentSalary' => $candidate->CurrentSalary,
                'SalaryExpectation' => $candidate->SalaryExpectation,
                'NoticePeriod' => $candidate->NoticePeriod,
                // 'CreatedBy' => $candidate->CreatedBy,
                // 'CreatedOn' => $candidate->CreatedOn,
                // 'UpdatedBy' => $candidate->UpdatedBy,
                // 'UpdatedOn' => $candidate->UpdatedOn
               
            ]);
       
            //echo "jobb_application".$jobApplication;
            //echo "condidate".$candidate;
            Log::info('Job application created log', ['job_application' => $jobApplication]);

            $body = view('emails.candidate_shortlisted', ['candidate' => $candidate])->render();

            Mail::to($candidate->Email)->send(new CandidateShortlisted($candidate));

             // Send SMS notification to the candidate
             $smsService = new SmsService();
             $smsVariables = [
                 'var1' => $candidate->Name,
                 'var2' => $candidate->JobTitle,
             ];
 
             $smsResponse = $smsService->sendSms([$candidate->ContactNo], 'Shortlisted', $smsVariables);
            
             

            $SenderEmail = APP_EMAIL;
            EmailLog::create([
                'recipient' => $candidate->Email,
                'subject' => 'Application Received',
                'body' => $body,
                'candidate_id' => $candidate->Id,
                'Sender'=> $SenderEmail
            ]);
            
        } elseif ($deaction == 'Reject') {
            Log::info('Processing rejection for candidate ID: ' . $CandidateId);
            
            // Create or update candidate history
            candidate_history::create([
                'remarks' => 'Candidate Rejected',
                'status_id' => 10,
                'candidate_id' => $candidate->Id,
                'isactive' => 1,
            ]);
            $candidate->status_id = 10; // or use $request->input('status_id') for dynamic values
            $candidate->save();

            // Send SMS notification to the candidate
            $smsService = new SmsService();
            $smsVariables = [
                'var1' => $candidate->Name,
                'var2' => $candidate->JobTitle,
            ];

            $smsResponse = $smsService->sendSms([$candidate->ContactNo], 'CandidateReject', $smsVariables);

        } else {
            return response()->json(['error' => 'Invalid action'], 400);
        }
        // Mark the link as used before committing the transaction
        $candidate->link_used = true;
        $candidate->save();
        DB::commit();
        Log::info('Candidate action processed successfully for candidate ID: ' . $CandidateId);
       // return $this->successJson('candidates status Accept', 200, $action);
       return response()->json(['message' => 'Candidate ' . ($deaction == 'Accept' ? 'accepted' : 'rejected') . ' successfully'], 200);

    } catch (\Exception $e) {
        DB::rollBack();
        Log::error('Error processing candidate action: ' . $e->getMessage());
        return response()->json(['error' => 'Invalid or expired link', 'message' => $e->getMessage()], 400);
    }
}

public function storeProjectWork(Request $request)
{
    
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('add_candidate')) {
        Log::warning('Unauthorized access attempt to store project work', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Validating request data for storing project work', ['request_data' => $request->all()]);

        // Validate the request
        $request->validate([
            'CandidateId' => 'required|exists:candidate,id',
            'project' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);
       
        Log::info('Request data validated successfully');

        // Create a new project work record
        $projectWork = ProjectWork::create([
            'CandidateId' => $request->CandidateId,
            'project' => $request->project,
            'description' => $request->description,
        ]);
        
        Log::info('Project work created successfully', ['project_work' => $projectWork]);

        // Return a success response
        return $this->successJson('Project work created successfully', 200, $projectWork);
       
    } catch (\Illuminate\Validation\ValidationException $e) {
        Log::error('Validation failed for storing project work', ['errors' => $e->errors()]);
        return response()->json(['errors' => $e->errors()], 422);

    } catch (\Exception $e) {
        Log::error('An error occurred while storing project work', ['error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to create project work'], 500);
    }
}

public function indexProjectWork()
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('view_candidate')) {
        Log::warning('Unauthorized access attempt to view project work', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Fetching all project work records');

        // Retrieve all project work records
        $projectWorks = ProjectWork::all();

        Log::info('Project work records fetched successfully', ['project_works_count' => $projectWorks->count()]);

        // Return the project work records
        return $this->successJson('Project work records retrieved successfully', 200,$projectWorks);
       
    } catch (\Exception $e) {
        Log::error('An error occurred while fetching project work records', ['error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to retrieve project work records'], 500);
    }
}

public function indexByProjectWork(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('view_candidate')) {
        Log::warning('Unauthorized access attempt to view project work', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve project work', ['project_work_id' => $id]);

        // Retrieve the project work record by ID
        $projectWork = ProjectWork::where('Id', $id)->first();

        if (!$projectWork) {
            Log::info('Project work not found', ['project_work_id' => $id]);
            return $this->errorJson('Project work not found', 404,$projectWork);
        }

        Log::info('Project work retrieved successfully', ['project_work' => $projectWork]);

        // Return the project work record
        return $this->successJson('Project work record retrieved successfully', 200, $projectWork);
    } catch (\Exception $e) {
        Log::error('An error occurred while retrieving project work', ['project_work_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to retrieve project work'], 500);
    }
}

public function updateProjectWork(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('edit_candidate')) {
        Log::warning('Unauthorized access attempt to edit project work', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve project work for updating', ['project_work_id' => $id]);

        // Retrieve the project work record by ID
        $projectWork = ProjectWork::where('Id', $id)->first();

        if (!$projectWork) {
            Log::info('Project work not found', ['project_work_id' => $id]);
            return $this->errorJson('Project work not found', 404,$projectWork);
        }

        Log::info('Project work retrieved successfully', ['project_work' => $projectWork]);

       // Update the project work record with specific columns
       $updatedData = $request->only(['project', 'description']);
       $projectWork->update($updatedData);

        Log::info('Project work updated successfully', ['project_work' => $projectWork]);

        // Return a success response
        return $this->successJson('Project work updated successfully', 200, $projectWork);
    } catch (\Illuminate\Validation\ValidationException $e) {
        Log::error('Validation failed for updating project work', ['errors' => $e->errors()]);
        return response()->json(['errors' => $e->errors()], 422);
    } catch (\Exception $e) {
        Log::error('An error occurred while updating project work', ['project_work_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to update project work'], 500);
    }
}


public function deleteProjectWork(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('delete_candidate')) {
        Log::warning('Unauthorized access attempt to delete project work', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve project work for deletion', ['project_work_id' => $id]);

        // Retrieve the project work record by ID
        $projectWork = ProjectWork::where('Id', $id)->first();

        if (!$projectWork) {
            Log::info('Project work not found', ['project_work_id' => $id]);
            return $this->errorJson('Project work not found', 404,$projectWork);
        }

        Log::info('Project work retrieved successfully', ['project_work' => $projectWork]);

        // Delete the project work record
        $projectWork->delete();

        Log::info('Project work deleted successfully', ['project_work_id' => $id]);

        // Return a success response
        return $this->successJson('Project work deleted successfully', 200);
    } catch (\Exception $e) {
        Log::error('An error occurred while deleting project work', ['project_work_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to delete project work'], 500);
    }
}

public function storeCandidateSkill(Request $request)
{
    
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('add_candidate')) {
        Log::warning('Unauthorized access attempt to store candidate skill', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Validating request data for storing project work', ['request_data' => $request->all()]);

        // Validate the request
        $request->validate([
            'CandidateId' => 'required|exists:candidate,id',
            'name' => 'required|string|max:255',
            'technology' => 'required|string',
            'comments'=>'nullable|string'
        ]);
       
        Log::info('Request data validated successfully');

        // Create a new candidate skill record
        $candidateskill = CandidateSkill::create([
            'CandidateId' => $request->CandidateId,
            'name' => $request->name,
            'technology' => $request->technology,
            'comments'=>$request->comments
        ]);
        
        Log::info('Candidate Skill created successfully', ['candidate_skill' => $candidateskill]);

        // Return a success response
        return $this->successJson('Candidate skill created successfully', 200, $candidateskill);
       
    } catch (\Illuminate\Validation\ValidationException $e) {
        Log::error('Validation failed for storing project work', ['errors' => $e->errors()]);
        return response()->json(['errors' => $e->errors()], 422);

    } catch (\Exception $e) {
        Log::error('An error occurred while storing project work', ['error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to create candidate skill'], 500);
    }
}

public function indexCandidateSkill()
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('view_candidate')) {
        Log::warning('Unauthorized access attempt to view candidate skill', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Fetching all candidate skill records');

        // Retrieve all project work records
        $candidateskill = CandidateSkill::all();

        Log::info('Candidate skill records fetched successfully', ['candidate_skill_count' => $candidateskill->count()]);

        // Return the project work records
        return $this->successJson('Candidate skill records retrieved successfully', 200,$candidateskill);
       
    } catch (\Exception $e) {
        Log::error('An error occurred while fetching Candidate skill records', ['error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to retrieve candidate skill records'], 500);
    }
}

public function indexByCandidateSkill(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('view_candidate')) {
        Log::warning('Unauthorized access attempt to view candidate skill', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve candidate skill', ['candidateskill_id' => $id]);

        // Retrieve the project work record by ID
        $candidateskill = CandidateSkill::where('Id', $id)->first();

        if (!$candidateskill) {
            Log::info('Candidate skill not found', ['candidate_skil_id' => $id]);
            return $this->errorJson('candidate skill not found', 404,$candidateskill);
        }

        Log::info('Candidate skill retrieved successfully', ['candidate_skill' => $candidateskill]);

        // Return the project work record
        return $this->successJson('Candidate SKill record retrieved successfully', 200, $candidateskill);
    } catch (\Exception $e) {
        Log::error('An error occurred while retrieving candidate skill', ['candidate_skill_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to retrieve project work'], 500);
    }
}

public function updateByCandidateSkill(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('edit_candidate')) {
        Log::warning('Unauthorized access attempt to edit candidate skill', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve candidate skill for updating', ['candidate skill_id' => $id]);

        // Retrieve the project work record by ID
        $candidateskill = CandidateSkill::where('Id', $id)->first();

        if (!$candidateskill) {
            Log::info('candidateskill not found', ['candidateskill_id' => $id]);
            return $this->errorJson('Project work not found', 404,$candidateskill);
        }

        Log::info('candidateskill retrieved successfully', ['candidateskill' => $candidateskill]);

       // Update the project work record with specific columns
       $updatedData = $request->only(['name', 'technology','comments']);
       $candidateskill->update($updatedData);

        Log::info('candidateskill updated successfully', ['candidateskill' => $candidateskill]);

        // Return a success response
        return $this->successJson('Candidate_skill updated successfully', 200, $candidateskill);
    } catch (\Illuminate\Validation\ValidationException $e) {
        Log::error('Validation failed for updating candidateskill', ['errors' => $e->errors()]);
        return response()->json(['errors' => $e->errors()], 422);
    } catch (\Exception $e) {
        Log::error('An error occurred while updating candidateskill', ['candidateskill_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to update project work'], 500);
    }
}

public function deleteByCandidateSkill(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('delete_candidate')) {
        Log::warning('Unauthorized access attempt to delete candidate skill', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve candidate skill for deletion', ['candidate_skill_id' => $id]);

        // Retrieve the project work record by ID
        $candidateskill = CandidateSkill::where('Id', $id)->first();

        if (!$candidateskill) {
            Log::info('candidate skill not found', ['candidate skill_id' => $id]);
            return $this->errorJson('candidate skill not found', 404,$candidateskill);
        }

        Log::info('candidate skill retrieved successfully', ['candidate skill' => $candidateskill]);

        // Delete the project work record
        $candidateskill->delete();

        Log::info('candidate skill deleted successfully', ['candidate_skill_id' => $id]);

        // Return a success response
        return $this->successJson('candidate skill deleted successfully', 200);
    } catch (\Exception $e) {
        Log::error('An error occurred while deleting candidate skill', ['candidate skill_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to delete candidate skill'], 500);
    }
}

public function storecertificates(Request $request)
{
    
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('add_candidate')) {
        Log::warning('Unauthorized access attempt to store certificate', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Validating request data for storing certificates', ['request_data' => $request->all()]);

        // Validate the request
        $request->validate([
            'CandidateId' => 'required|exists:candidate,id',
            'name' => 'required|string|max:255',
            'link' => 'required|string',
            'description'=>'nullable|string'
        ]);
       
        Log::info('Request data validated successfully');

        // Create a new candidate skill record
        $certificates = Certificates::create([
            'CandidateId' => $request->CandidateId,
            'name' => $request->name,
            'link' => $request->link,
            'description'=>$request->description
        ]);
        
        Log::info('Certificates created successfully', ['certificates' => $certificates]);

        // Return a success response
        return $this->successJson('Certificates created successfully', 200, $certificates);
       
    } catch (\Illuminate\Validation\ValidationException $e) {
        Log::error('Validation failed for storing project work', ['errors' => $e->errors()]);
        return response()->json(['errors' => $e->errors()], 422);

    } catch (\Exception $e) {
        Log::error('An error occurred while storing certificates', ['error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to create certificates'], 500);
    }
}


public function indexcertificates()
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('view_candidate')) {
        Log::warning('Unauthorized access attempt to view certificates', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Fetching all certificates records');

        // Retrieve all project work records
        $certificates = Certificates::all();

        Log::info('certificates records fetched successfully', ['certificates_count' => $certificates->count()]);

        // Return the project work records
        return $this->successJson('certificates records retrieved successfully', 200,$certificates);
       
    } catch (\Exception $e) {
        Log::error('An error occurred while fetching certificates records', ['error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to retrieve certificates records'], 500);
    }
}

public function indexByCertificates(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('view_candidate')) {
        Log::warning('Unauthorized access attempt to view certificates', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve certificates', ['certificates_id' => $id]);

        // Retrieve the project work record by ID
        $certificates = Certificates::where('Id', $id)->first();

        if (!$certificates) {
            Log::info('certificates not found', ['certificates_id' => $id]);
        return $this->errorJson('certificates not found', 404,$certificates);
        }

        Log::info('certificates retrieved successfully', ['certificates' => $certificates]);

        // Return the project work record
        return $this->successJson('certificates record retrieved successfully', 200, $certificates);
    } catch (\Exception $e) {
        Log::error('An error occurred while retrieving certificates', ['certificates_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to retrieve project work'], 500);
    }
}

public function updateByCertificates(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('edit_candidate')) {
        Log::warning('Unauthorized access attempt to edit certificates', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve certificates for updating', ['certificates_id' => $id]);

        // Retrieve the project work record by ID
        $certificates = Certificates::where('Id', $id)->first();

        if (!$certificates) {
            Log::info('certificates not found', ['certificates_id' => $id]);
        return $this->errorJson('certificates not found', 404,$certificates);
        }

        Log::info('certificates retrieved successfully', ['certificates' => $certificates]);

       // Update the project work record with specific columns
       $updatedData = $request->only(['name', 'link','description']);
       $certificates->update($updatedData);

        Log::info('certificates updated successfully', ['certificates' => $certificates]);

        // Return a success response
        return $this->successJson('certificates updated successfully', 200, $certificates);
    } catch (\Illuminate\Validation\ValidationException $e) {
        Log::error('Validation failed for updating certificates', ['errors' => $e->errors()]);
        return response()->json(['errors' => $e->errors()], 422);
    } catch (\Exception $e) {
        Log::error('An error occurred while updating certificates', ['certificates_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to update project work'], 500);
    }
}

public function deleteByCertificates(Request $request, $id)
{
    // Check if the authenticated user has the required permission
    if (!auth()->user()->cans('delete_candidate')) {
        Log::warning('Unauthorized access attempt to delete certificates', ['user_id' => auth()->user()->id]);
        return response()->json(['message' => 'Not authenticated to perform this request'], 403);
    }

    try {
        Log::info('Attempting to retrieve certificates for deletion', ['certificates_id' => $id]);
       
        // Retrieve the project work record by ID
        $certificates = Certificates::where('Id', $id)->first();
        
        if (!$certificates) {
            Log::info('certificates not found', ['certificates_id' => $id]);            
        return $this->errorJson('certificates not found', 404,$certificates);
        }

        Log::info('certificates retrieved successfully', ['certificates' => $certificates]);

        // Delete the project work record
        $certificates->delete();

        Log::info('certificates deleted successfully', ['certificates_id' => $id]);

        // Return a success response
        return $this->successJson('certificates deleted successfully', 200);
    } catch (\Exception $e) {
        Log::error('An error occurred while deleting certificates', ['certificates_id' => $id, 'error' => $e->getMessage()]);
        return response()->json(['message' => 'Failed to delete certificates'], 500);
    }
}

//get the all data for related candidate data
public function getAllCandidateData()
{
    try {
        Log::info('Fetching all candidates data');

        
        $candidates = Candidate::with([
            'CandidateQualification',
            'CandidateExperience',
            'ProjectWork',
            'CandidateSkill',
            'Certificates'
        ])->get();

        Log::info('Successfully fetched candidates data', ['count' => $candidates->count()]);

        return $this->successJson('Candidates data retrieved successfully', 200, $candidates);
    } catch (\Exception $e) {
        Log::error('An error occurred while fetching candidates data', ['error' => $e->getMessage()]);
        return $this->errorJson('Failed to retrieve candidates data', 500, $e->getMessage());
    }
}

// public function uploadResume(Request $request)
// {
//     // Validate that the uploaded file is a resume (txt, pdf, docx, etc.)
//     $request->validate([
//         'resume' => 'required|mimes:txt,pdf,doc,docx|max:2048'
//     ]);

//     // Get the file contents (this could vary if you're using a different file format like PDF)
//     $file = $request->file('resume');
//     $resumeContent = file_get_contents($file->getRealPath());

//     // Parse the resume content (you can use regex or an NLP tool to parse it)
//     $parsedData = $this->parseResume($resumeContent);

//     // Map the parsed data to the Candidate model
//     $candidate = new Candidate();
//     $candidate->name = $parsedData['name'] ?? null;
//     $candidate->email = $parsedData['email'] ?? null;
//     $candidate->phone = $parsedData['phone'] ?? null;
//     $candidate->linkedin = $parsedData['linkedin'] ?? null;
//     $candidate->objective = $parsedData['objective'] ?? null;
//     $candidate->work_experience = json_encode($parsedData['work_experience']) ?? null;
//     $candidate->education = json_encode($parsedData['education']) ?? null;
//     $candidate->skills = json_encode($parsedData['skills']) ?? null;
//     $candidate->certifications = json_encode($parsedData['certifications']) ?? null;
//     $candidate->projects = json_encode($parsedData['projects']) ?? null;
//     $candidate->languages = json_encode($parsedData['languages']) ?? null;
//     echo  $candidate;
    
    

//     // Return the candidate data as a response
//     return response()->json(['message' => 'Resume uploaded and parsed successfully!', 'candidate' => $candidate]);
// }

// private function extractWorkExperience($experienceSection)
// {
//     // This function can parse the work experience into structured data
//     $experiences = [];
//     preg_match_all('/\d+\.\s*(.*?)Duration:\s*(.*?)Location:\s*(.*?)\-\s*(.*?)(?=\d+\.|$)/is', $experienceSection, $matches, PREG_SET_ORDER);
    
//     foreach ($matches as $match) {
//         $experiences[] = [
//             'company' => trim($match[1]),
//             'duration' => trim($match[2]),
//             'location' => trim($match[3]),
//             'description' => trim($match[4]),
//         ];
//     }

//     return $experiences;
// }

// private function extractProjects($projectsSection)
// {
//     $projects = [];
//     preg_match_all('/\d+\.\s*(.*?)\-\s*(.*?)\s*\-/is', $projectsSection, $matches, PREG_SET_ORDER);

//     foreach ($matches as $match) {
//         $projects[] = [
//             'title' => trim($match[1]),
//             'description' => trim($match[2]),
//         ];
//     }

//     return $projects;
// }

// private function parseResume($resumeContent)
// {
//     // Basic regex patterns to extract the data
//     $data = [];
    
//     // Extract name
//     preg_match('/Name:\s*(.*)/i', $resumeContent, $matches);
//     $data['name'] = $matches[1] ?? null;

//     // Extract email
//     preg_match('/Email:\s*(.*)/i', $resumeContent, $matches);
//     $data['email'] = $matches[1] ?? null;

//     // Extract phone
//     preg_match('/Phone:\s*(.*)/i', $resumeContent, $matches);
//     $data['phone'] = $matches[1] ?? null;

//     // Extract LinkedIn
//     preg_match('/LinkedIn:\s*(.*)/i', $resumeContent, $matches);
//     $data['linkedin'] = $matches[1] ?? null;

//     // Extract objective
//     preg_match('/Objective:\s*(.*?)(Work Experience|Education|Skills)/is', $resumeContent, $matches);
//     $data['objective'] = $matches[1] ?? null;

//     // Extract work experience
//     preg_match('/Work Experience:\s*(.*?)(Education|Skills)/is', $resumeContent, $matches);
//     $data['work_experience'] = $this->extractWorkExperience($matches[1] ?? '');

//     // Extract education
//     preg_match('/Education:\s*(.*?)(Skills|Certifications|Projects|Languages)/is', $resumeContent, $matches);
//     $data['education'] = $this->extractEducation($matches[1] ?? '');

//     // Extract skills
//     preg_match('/Skills:\s*(.*?)(Certifications|Projects|Languages)/is', $resumeContent, $matches);
//     $data['skills'] = explode(',', $matches[1] ?? '');

//     // Extract certifications
//     preg_match('/Certifications:\s*(.*?)(Projects|Languages)/is', $resumeContent, $matches);
//     $data['certifications'] = explode(',', $matches[1] ?? '');

//     // Extract projects
//     preg_match('/Projects:\s*(.*?)(Languages|References)/is', $resumeContent, $matches);
//     $data['projects'] = $this->extractProjects($matches[1] ?? '');

//     // Extract languages
//     preg_match('/Languages:\s*(.*)/i', $resumeContent, $matches);
//     $data['languages'] = explode(',', $matches[1] ?? '');

//     return $data;
// }

}






