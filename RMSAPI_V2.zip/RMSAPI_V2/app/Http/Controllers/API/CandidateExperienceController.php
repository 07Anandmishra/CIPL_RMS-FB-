<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\CandidateExperience;

class CandidateExperienceController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' => $message,
            'data' => $data,
            'status' => 0,
        ], $code);
    }

    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' => $message,
            'data' => $data,
            'status' => 1,
        ], 200);
    }

    public function index()
    {
        try {
            Log::info('Accessing index method of CandidateExperienceController');

            $experiences = CandidateExperience::all();

            Log::info('Retrieved ' . count($experiences) . ' candidate experiences');

            if ($experiences->isEmpty()) {
                Log::warning('No candidate experiences found');
                return $this->errorJson('No Candidate Experiences Found', 404);
            }

            Log::info('Successfully fetched candidate experiences');
            return $this->successJson('Candidate Experience Details', 200, $experiences);

        } catch (\Exception $e) {
            Log::error('Failed to fetch candidate experiences: ' . $e->getMessage());
            return $this->errorJson('Failed to fetch candidate experiences', 500, $e->getMessage());
        }
    }

    public function store(Request $request)
    {
        try {
            Log::info('Accessing store method of CandidateExperienceController');

            $validatedData = $request->validate([
                'CandidateId' => 'required|integer|exists:candidate,id',
                'CompanyName' => 'required|string|max:255',
                'Designation' => 'required|string|max:255',
                'StartDate' => 'required|date',
                'EndDate' => 'nullable|date|after_or_equal:StartDate',
            ]);

            $experience = CandidateExperience::create($validatedData);

            return $this->successJson('Candidate Experience Created Successfully', 201, $experience);

        } catch (\Exception $e) {
            Log::error('Failed to create candidate experience: ' . $e->getMessage());
            return $this->errorJson('Failed to create candidate experience', 500, $e->getMessage());
        }
    }

    public function show($id)
    {
        try {
            Log::info('Accessing show method of CandidateExperienceController');

            $experience = CandidateExperience::find($id);

            if (!$experience) {
                Log::warning('Candidate Experience Not Found', ['id' => $id]);
                return $this->errorJson('Candidate Experience Not Found', 404);
            }

            Log::info('Candidate Experience Retrieved Successfully', ['candidate_experience' => $experience]);
            return $this->successJson('Candidate Experience Retrieved Successfully', 200, $experience);

        } catch (\Exception $e) {
            Log::error('Failed to retrieve candidate experience: ' . $e->getMessage());
            return $this->errorJson('Failed to retrieve candidate experience', 500, $e->getMessage());
        }
    }

    public function update(Request $request, $id)
    {
        try {
          //  Log::info('Accessing update method of CandidateExperienceController', ['request_data' => $request->all(), 'id' => $id]);

            $validatedData = $request->validate([
                'CandidateId' => 'nullable|integer|exists:candidate,id',
                'CompanyName' => 'nullable|string|max:255',
                'Designation' => 'nullable|string|max:255',
                'StartDate' => 'nullable|date',
                'EndDate' => 'nullable|date|after_or_equal:StartDate',
            ]);

            $experience = CandidateExperience::find($id);

            if (!$experience) {
                Log::warning('Candidate Experience Not Found', ['id' => $id]);
                return $this->errorJson('Candidate Experience Not Found', 404);
            }

            $experience->update($validatedData);

            Log::info('Candidate Experience Updated Successfully', ['candidate_experience' => $experience]);
            return $this->successJson('Candidate Experience Updated Successfully', 200, $experience);

        } catch (\Exception $e) {
            Log::error('Failed to update candidate experience: ' . $e->getMessage());
            return $this->errorJson('Failed to update candidate experience', 500, $e->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            Log::info('Accessing destroy method of CandidateExperienceController', ['id' => $id]);

            $experience = CandidateExperience::find($id);

            if (!$experience) {
                Log::warning('Candidate Experience Not Found', ['id' => $id]);
                return $this->errorJson('Candidate Experience Not Found', 404);
            }

            $experience->delete();

            Log::info('Candidate Experience Deleted Successfully', ['id' => $id]);
            return $this->successJson('Candidate Experience Deleted Successfully', 200);

        } catch (\Exception $e) {
            Log::error('Failed to delete candidate experience: ' . $e->getMessage());
            return $this->errorJson('Failed to delete candidate experience', 500, $e->getMessage());
        }
    }

}
