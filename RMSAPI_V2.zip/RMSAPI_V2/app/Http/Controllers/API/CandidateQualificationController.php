<?php

namespace App\Http\Controllers\API;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\CandidateQualification;

class CandidateQualificationController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' => $message,
            'data' => $data,
            'status' => 0,
        ], $code);
    }

    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' => $message,
            'data' => $data,
            'status' => 1,
        ], 200);
    }

    public function index()
    {
        try {
            \Log::info('Accessing index method of CandidateQualificationController');

            $qualifications = CandidateQualification::all();

            \Log::info('Retrieved ' . count($qualifications) . ' qualifications');

            return $this->successJson('Qualifications Details', 200, $qualifications);

        } catch (\Exception $e) {
            \Log::error('Failed to fetch qualifications: ' . $e->getMessage());
            return $this->errorJson('Failed to fetch qualifications', 500, $e->getMessage());
        }
    }

    public function store(Request $request)
    {
        try {
            \Log::info('Accessing store method of CandidateQualificationController');

            $validatedData = $request->validate([
                'CandidateId' => 'required|integer|exists:candidate,id',
                'Degree' => 'required|string|max:255',
                'BoardUniversity' => 'required|string|max:255',
                'PassingYear' => 'required|integer',
                'Score' => 'required|numeric|min:0|max:100',
            ]);

            $qualification = CandidateQualification::create($validatedData);

            \Log::info('Qualification created successfully', ['qualification' => $qualification]);
            return $this->successJson('Qualification created successfully', 200, $qualification);

        } catch (\Exception $e) {
            \Log::error('Failed to create qualification: ' . $e->getMessage());
            return $this->errorJson('Failed to create qualification', 500, $e->getMessage());
        }
    }

    public function show($id)
    {
        try {
            \Log::info('Accessing show method of CandidateQualificationController', ['id' => $id]);

            $qualification = CandidateQualification::findOrFail($id);

            \Log::info('Qualification retrieved successfully', ['qualification' => $qualification]);
            return $this->successJson('Qualification retrieved successfully', 200, $qualification);

        } catch (\Exception $e) {
            \Log::error('Failed to retrieve qualification: ' . $e->getMessage());
            return $this->errorJson('Failed to retrieve qualification', 500, $e->getMessage());
        }
    }

    public function update(Request $request, $id)
    {
        try {
            \Log::info('Accessing update method of CandidateQualificationController', ['id' => $id]);

            $validatedData = $request->validate([
                // 'CandidateId' => 'required|integer|exists:candidate,id',
                'Degree' => 'nullable|string|max:255',
                'BoardUniversity' => 'nullable|string|max:255',
                'PassingYear' => 'nullable|integer',
                'Score' => 'nullable|numeric|min:0|max:100',
            ]);

            $qualification = CandidateQualification::findOrFail($id);
            $qualification->update($validatedData);

            \Log::info('Qualification updated successfully', ['qualification' => $qualification]);
            return $this->successJson('Qualification updated successfully', 200, $qualification);

        } catch (\Exception $e) {
            \Log::error('Failed to update qualification: ' . $e->getMessage());
            return $this->errorJson('Failed to update qualification', 500, $e->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            \Log::info('Accessing destroy method of CandidateQualificationController', ['id' => $id]);

            $qualification = CandidateQualification::findOrFail($id);
            $qualification->delete();

            \Log::info('Qualification deleted successfully', ['id' => $id]);
            return $this->successJson('Qualification deleted successfully', 200);

        } catch (\Exception $e) {
            \Log::error('Failed to delete qualification: ' . $e->getMessage());
            return $this->errorJson('Failed to delete qualification', 500, $e->getMessage());
        }
    }

}
