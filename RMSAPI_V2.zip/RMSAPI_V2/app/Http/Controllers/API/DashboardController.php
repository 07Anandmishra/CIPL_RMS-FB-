<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\EmailSetting;
use App\InterviewSchedule;
use App\Job;
use App\JobApplication;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log; 
use App\Company;
use App\SmsSetting;
use App\User;
use App\Jobrecruitment;
use App\Candidate;
use App\candidate_history;
use App\Role;

class DashboardController extends Controller
{
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }
    public function dashboardold(){
        try{
       $data['totalOpenings'] = Job::where('status', '=', '1')->count();
        $data['totalApplications'] = JobApplication::count();
        $data['totalHired'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
            ->where('application_status.status', 'hired')
            ->count();
        $data['totalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
            ->where('application_status.status', 'rejected')
            ->count();
        $data['newApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
            ->where('application_status.status', 'applied')
            ->count();
        $data['onlineexam'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
            ->where('application_status.status', 'online exam')           
            ->count();
        $data['condidatestore'] = JobApplication::onlyTrashed()->count();
        $data['interviewround1'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
            ->where('application_status.status', 'interview round 1')           
            ->count();
        $data['interviewround2'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
            ->where('application_status.status', 'interview round 2')           
            ->count();
        $currentDate = Carbon::now()->format('Y-m-d');

        $data['totalTodayInterview'] = InterviewSchedule::where(DB::raw('DATE(`schedule_date`)'), "$currentDate")
            ->count();
            if(!empty($data)){
                return $this->successJson('Details',200,$data);
            }else{
                return $this->successJson('not found Details',200,$data);
            }
        } catch (\Exception $e) {
            return $this->errorJson('Error fetching dashboard details', 500, $e->getMessage());
        }
            
    }
 
        public function dashboard(Request $request)
    {
        try {
        $roleName = $request->input('type'); // Assuming 'type' is the query parameter for role name

        if ($roleName == 'ERF Generator') {
            // Handle ERF Generator role
            $data['totalOpenings'] = Job::where('status', '!=', '0')->where('user_id', auth()->user()->id)->count();
            $data['totalApplications'] = JobApplication::join('jobs', 'jobs.id', '=', 'job_applications.job_id')
                ->where('jobs.user_id', auth()->user()->id)
                ->count();
            $data['totalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'rejected')
                ->join('jobs', 'jobs.id', '=', 'job_applications.job_id')
                ->where('jobs.user_id', auth()->user()->id)
                ->count();
            $data['newApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'applied')
                ->join('jobs', 'jobs.id', '=', 'job_applications.job_id')
                ->where('jobs.user_id', auth()->user()->id)
                ->count();
        } elseif ($roleName == 'Recruiter') {
            // Handle Recruiter role
            $data['totalOpenings'] = Job::join('jobassigns', 'jobassigns.job_id', '=', 'jobs.id')
                ->where('jobassigns.user_id', auth()->user()->id)
                ->where('jobs.status', '!=', '0')
                ->count();
            $data['totalApplications'] = JobApplication::where('added_by', auth()->user()->id)->count();
            $data['totalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'rejected')
                ->where('job_applications.added_by', auth()->user()->id)
                ->count();
            $data['condidatestore'] = JobApplication::onlyTrashed()->where('added_by', auth()->user()->id)->count();
            $data['newApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'applied')
                ->where('job_applications.added_by', auth()->user()->id)
                ->count();
            $data['onlineexam'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'Pass')
                ->where('job_applications.added_by', auth()->user()->id)
                ->count();
            $data['interviewround1'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
                ->leftJoin('job_applications', 'job_applications.id', 'interview_schedules.job_application_id')
                ->where('interview_schedules.status', 'interview round 1')
                ->whereNull('job_applications.deleted_at')
                ->count();
            $data['interviewround2'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
                ->leftJoin('job_applications', 'job_applications.id', 'interview_schedules.job_application_id')
                ->where('interview_schedules.status', 'interview round 2')
                ->whereNull('job_applications.deleted_at')
                ->count();
        } else {
            // Handle other roles
            $data['totalOpenings'] = Job::where('status', '!=', '0')->count();
            $data['totalApplications'] = JobApplication::count();
            $data['totalHired'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'hired')
                ->count();
            $data['totalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'rejected')
                ->count();
            $data['newApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'applied')
                ->count();
            $data['onlineexam'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
                ->where('application_status.status', 'Pass')
                ->count();
            // $data['condidatestore'] = JobApplication::onlyTrashed()->count();
            // $data['interviewround1'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
            //     ->leftJoin('job_applications', 'job_applications.id', 'interview_schedules.job_application_id')
            //     ->where('interview_schedules.status', 'interview round 1')
            //     ->whereNull('job_applications.deleted_at')
            //     ->count();
            // $data['interviewround2'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
            //     ->leftJoin('job_applications', 'job_applications.id', 'interview_schedules.job_application_id')
            //     ->where('interview_schedules.status', 'interview round 2')
            //     ->whereNull('job_applications.deleted_at')
            //     ->count();

            $data['condidatestore'] = JobApplication::count();
        $data['interviewround1'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
        ->where('application_status.status', 'interview round 1')           
            ->count();
        $data['interviewround2'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
            ->where('application_status.status', 'interview round 2')           
            ->count();
            $currentDate = Carbon::now()->format('Y-m-d');
            $data['totalTodayInterview'] = InterviewSchedule::whereDate('schedule_date', $currentDate)->count();
        }

        if (!empty($data)) {
            return $this->successJson('Details', 200, $data);
        } else {
            return $this->errorJson('Details not found', 404);
        }
           
        } catch (\Exception $e) {
            return $this->errorJson('Error fetching dashboard details', 500, $e->getMessage());
        }
    }



    public function login(Request $request)
    {
        try{
        $loginData = $request->validate([
            'email' => 'email|required',
            'password' => 'required'
        ]); 
        $user = User::where('email', $request->email)->first();
        if (!auth()->attempt($loginData)) {
            return response()->json([
                'code' => 401,
                'message' =>  'Enter valid credentials',
                'status'=>0,
                ]);
        }
       else if($user->deleted_at == 1)
       {
        return response()->json([
            'code' => 403,
            'message' => 'This account has been deactivated. Please contact support.',
            'status' => 0,
        ]);
       }
        else{
           
            $user = $request->user();    
            $tokenResult = $user->createToken('CIPL');
            $token = $tokenResult->token;
            
           //get permission and roles 
            $data=User::with('roles.permissions.permission')->find(auth()->user()->id);
            $userPermissions = array();
            foreach ($data->roles[0]->permissions as $key => $value) {
                $userPermissions[] = $value->permission->name;
            }
            $data['userPermissions'] = $userPermissions;
            Log::info('User permissions fetched', ['user_id' => $user->id, 'permissions' => $userPermissions]);

            return response()->json([
                'access_token' => $tokenResult->accessToken,
                'token_type' => 'Bearer',
                 
                  'code' => 200,
                  'data' => $data,
                  'message' => 'Login successful!!',
                  'status'=>1,
               ]);
        }

    } catch (\Exception $e) {
        return $this->errorJson('Error fetching dashboard details', 500, $e->getMessage());
    }

    }

    public function logout(Request $request)
    {
        
        if ($request->user()) {
            $request->user()->token()->revoke();
            return response()->json([
                'code' => 200,
                'status' => 1,
                'message' => 'Logout Successfully.'
            ]);
        }
    }

    // MRf Insight

    public function getMrfStatusInsights()
    {
        try {
            // Fetch MRFs with their status and timestamps
            $mrfStatuses['OpenMRF'] = Jobrecruitment::where('MrfStatus', '=', '1')->count();
        
            $mrfStatuses['ApproveMRF'] = Jobrecruitment::where('MrfStatus', '=', '3')->count();
            $mrfStatuses['DisapproveMRF'] = Jobrecruitment::where('MrfStatus', '=', '4')->count();
                

                return $this->successJson('MRF Insight',200,$mrfStatuses);
        } catch (\Exception $e) {
            // Log the exception
            Log::error('Failed to retrieve MRF status insights', ['error' => $e->getMessage()]);

            return $this->errorJson('Something went wrong', 500, $e->getMessage());
        }
    }

    // public function getDashboardInsights()
    // {
    //     try {
    //         // Fetch total projects
    //     $candidateCount['TotalProject'] = Job::count();

    //     // Fetch candidate insights with unique candidate counts
    //     $candidateCount['TotalCandidate'] = Candidate::count();
    //     $candidateCount['ShortlistedCandidate'] = candidate_history::distinct('candidate_id')->where('status_id', 2)->count('candidate_id');
    //     $candidateCount['RejectedCandidate'] = candidate_history::distinct('candidate_id')->where('status_id', 10)->count('candidate_id');
    //     $candidateCount['Interview 1'] = candidate_history::distinct('candidate_id')->where('status_id', 3)->count('candidate_id');
    //     $candidateCount['Interview 1 Clear'] = candidate_history::distinct('candidate_id')->where('status_id', 11)->count('candidate_id');
    //     $candidateCount['Interview 1 Rejected'] = candidate_history::distinct('candidate_id')->where('status_id', 12)->count('candidate_id');
    //     $candidateCount['Interview 2'] = candidate_history::distinct('candidate_id')->where('status_id', 4)->count('candidate_id');
    //     $candidateCount['Interview 2 Clear'] = candidate_history::distinct('candidate_id')->where('status_id', 13)->count('candidate_id');
    //     $candidateCount['Interview 2 Rejected'] = candidate_history::distinct('candidate_id')->where('status_id', 14)->count('candidate_id');
    //     $candidateCount['TotalHired'] = candidate_history::distinct('candidate_id')->where('status_id', 9)->count('candidate_id');
                

    //             return $this->successJson('Candidate Insight',200,$candidateCount);
    //     } catch (\Exception $e) {
    //         // Log the exception
    //         Log::error('Failed to retrieve MRF status insights', ['error' => $e->getMessage()]);

    //         return $this->errorJson('Something went wrong', 500, $e->getMessage());
    //     }
    // }

    //     public function getDashboardInsights()
    // {
    //     try {
    //         // Fetch total projects
    //         $candidateCount['TotalProject'] = Job::count();

    //         // Fetch total candidates
    //         $candidateCount['TotalCandidate'] = Candidate::count();

    //         // Fetch status-wise candidate counts
    //         $statusCounts = Candidate::select('status_id', DB::raw('count(*) as count'))
    //             ->groupBy('status_id')
    //             ->pluck('count', 'status_id')
    //             ->toArray();

    //         // Define status mappings
    //         $statusMapping = [
    //             // 1 => 'New',
    //             2 => 'Shortlisted',
    //             3 => 'Interview 1',
    //             4 => 'Interview 2',
    //             9 => 'Hired',
    //             10 => 'Rejected',
    //             11 => 'Interview 1 Clear',
    //             12 => 'Interview 1 Rejected',
    //             13 => 'Interview 2 Clear',
    //             14 => 'Interview 2 Rejected',
    //         ];

    //         // Map status counts to human-readable names
    //         foreach ($statusMapping as $statusId => $statusName) {
    //             $candidateCount[$statusName] = $statusCounts[$statusId] ?? 0;
    //         }

    //         return $this->successJson('Candidate Insight', 200, $candidateCount);
    //     } catch (\Exception $e) {
    //         // Log the exception
    //         Log::error('Failed to retrieve candidate insights', ['error' => $e->getMessage()]);

    //         return $this->errorJson('Something went wrong', 500, $e->getMessage());
    //     }
    // }

    public function getDashboardInsights()
{
    try {
        // Fetch total projects
        $candidateCount['TotalProject'] = Job::count();

        // Fetch valid candidate IDs
        $validCandidateIds = Candidate::pluck('Id')->toArray();

        // Fetch candidate insights with unique candidate counts, filtered by valid candidate IDs
        $candidateCount['TotalCandidate'] = Candidate::count();
        
        $candidateCount['ShortlistedCandidate'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 2)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['RejectedCandidate'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 10)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['Interview 1'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 3)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['Interview 1 Clear'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 11)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['Interview 1 Rejected'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 12)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['Interview 2'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 4)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['Interview 2 Clear'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 13)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['Interview 2 Rejected'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 14)
            ->distinct('candidate_id')
            ->count('candidate_id');
        
        $candidateCount['TotalHired'] = candidate_history::whereIn('candidate_id', $validCandidateIds)
            ->where('status_id', 9)
            ->distinct('candidate_id')
            ->count('candidate_id');

        return $this->successJson('Candidate Insight', 200, $candidateCount);
    } catch (\Exception $e) {
        // Log the exception
        Log::error('Failed to retrieve candidate insights', ['error' => $e->getMessage()]);

        return $this->errorJson('Something went wrong', 500, $e->getMessage());
    }
}




//     public function getDashboardInsights()
// {
//     try {
//         // Fetch total projects
//         $dashboardData['TotalProjects'] = Job::count();

//         // Fetch candidate insights with unique candidate counts
//         $dashboardData['TotalCandidates'] = Candidate::count();
//         $dashboardData['ShortlistedCandidates'] = candidate_history::distinct('candidate_id')->where('status_id', 2)->count('candidate_id');
//         $dashboardData['RejectedCandidates'] = candidate_history::distinct('candidate_id')->where('status_id', 10)->count('candidate_id');
//         $dashboardData['Interview1'] = candidate_history::distinct('candidate_id')->where('status_id', 3)->count('candidate_id');
//         $dashboardData['Interview1Clear'] = candidate_history::distinct('candidate_id')->where('status_id', 11)->count('candidate_id');
//         $dashboardData['Interview1Rejected'] = candidate_history::distinct('candidate_id')->where('status_id', 12)->count('candidate_id');
//         $dashboardData['Interview2'] = candidate_history::distinct('candidate_id')->where('status_id', 4)->count('candidate_id');
//         $dashboardData['Interview2Clear'] = candidate_history::distinct('candidate_id')->where('status_id', 13)->count('candidate_id');
//         $dashboardData['Interview2Rejected'] = candidate_history::distinct('candidate_id')->where('status_id', 14)->count('candidate_id');
//         $dashboardData['TotalHired'] = candidate_history::distinct('candidate_id')->where('status_id', 9)->count('candidate_id');

//         // Fetch today's interviews
//         $currentDate = Carbon::now()->format('Y-m-d');
//         $dashboardData['TotalTodayInterviews'] = InterviewSchedule::whereDate('schedule_date', $currentDate)->count();

//         // Fetch overall counts for job applications and statuses
//         $dashboardData['TotalApplications'] = JobApplication::count();
//         $dashboardData['TotalRejectedApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
//             ->where('application_status.status', 'rejected')
//             ->count();
//         $dashboardData['NewApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
//             ->where('application_status.status', 'applied')
//             ->count();
//         // $dashboardData['OnlineExamsPassed'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
//         //     ->where('application_status.status', 'Pass')
//         //     ->count();
//         // $dashboardData['InterviewRound1'] = InterviewSchedule::where('status', 'interview round 1')->count();
//         // $dashboardData['InterviewRound2'] = InterviewSchedule::where('status', 'interview round 2')->count();

//         return $this->successJson('Dashboard Insights', 200, $dashboardData);

//     } catch (\Exception $e) {
//         Log::error('Failed to retrieve dashboard insights', ['error' => $e->getMessage()]);
//         return $this->errorJson('Something went wrong', 500, $e->getMessage());
//     }
// }

    

    // public function getDashboardInsights()
    // {
    //     try {
    //         // Fetch total projects
    //         $candidateCount['TotalProject'] = Job::count();
    
    //         // Fetch candidate insights with unique candidate counts
    //         $candidateCount['TotalCandidate'] = Candidate::count();
    //         $candidateCount['ShortlistedCandidate'] = candidate_history::distinct('candidate_id')->where('status_id', 2)->count('candidate_id');
    //         $candidateCount['RejectedCandidate'] = candidate_history::distinct('candidate_id')->where('status_id', 10)->count('candidate_id');
    //         $candidateCount['Interview1'] = candidate_history::distinct('candidate_id')->where('status_id', 3)->count('candidate_id');
    //         $candidateCount['Interview1Clear'] = candidate_history::distinct('candidate_id')->where('status_id', 11)->count('candidate_id');
    //         $candidateCount['Interview1Rejected'] = candidate_history::distinct('candidate_id')->where('status_id', 12)->count('candidate_id');
    //         $candidateCount['Interview2'] = candidate_history::distinct('candidate_id')->where('status_id', 4)->count('candidate_id');
    //         $candidateCount['Interview2Clear'] = candidate_history::distinct('candidate_id')->where('status_id', 13)->count('candidate_id');
    //         $candidateCount['Interview2Rejected'] = candidate_history::distinct('candidate_id')->where('status_id', 14)->count('candidate_id');
    //         $candidateCount['TotalHired'] = candidate_history::distinct('candidate_id')->where('status_id', 9)->count('candidate_id');
    
    //         // Fetch today's interviews
    //         $currentDate = Carbon::now()->format('Y-m-d');
    //         $candidateCount['TotalTodayInterview'] = InterviewSchedule::whereDate('schedule_date', $currentDate)->count();
    
    //         // Fetch role-specific counts
    //         $roles = Role::all();
    //         $roleCounts = [];
    
    //         foreach ($roles as $role) {
    //             switch ($role->name) {
    //                 case 'admin':
    //                 case 'super_admin':
    //                     $roleCounts[$role->name]['TotalOpenings'] = Job::count();
    //                     $roleCounts[$role->name]['TotalApplications'] = JobApplication::count();
    //                     $roleCounts[$role->name]['TotalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'rejected')
    //                         ->count();
    //                     $roleCounts[$role->name]['NewApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'applied')
    //                         ->count();
    //                     $roleCounts[$role->name]['OnlineExam'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'Pass')
    //                         ->count();
    //                     $roleCounts[$role->name]['InterviewRound1'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
    //                         ->where('interview_schedules.status', 'interview round 1')
    //                         ->count();
    //                     $roleCounts[$role->name]['InterviewRound2'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
    //                         ->where('interview_schedules.status', 'interview round 2')
    //                         ->count();
    //                     break;
    //                 case 'Manager':
    //                     $roleCounts[$role->name]['TotalOpenings'] = Job::where('status', '!=', '0')->count();
    //                     $roleCounts[$role->name]['TotalApplications'] = JobApplication::count();
    //                     $roleCounts[$role->name]['TotalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'rejected')
    //                         ->count();
    //                     $roleCounts[$role->name]['NewApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'applied')
    //                         ->count();
    //                     $roleCounts[$role->name]['OnlineExam'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'Pass')
    //                         ->count();
    //                     $roleCounts[$role->name]['InterviewRound1'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
    //                         ->where('interview_schedules.status', 'interview round 1')
    //                         ->count();
    //                     $roleCounts[$role->name]['InterviewRound2'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
    //                         ->where('interview_schedules.status', 'interview round 2')
    //                         ->count();
    //                     break;
    //                 case 'content_viewer':
    //                     $roleCounts[$role->name]['TotalOpenings'] = Job::where('status', '!=', '0')->count();
    //                     $roleCounts[$role->name]['TotalApplications'] = JobApplication::count();
    //                     $roleCounts[$role->name]['TotalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'rejected')
    //                         ->count();
    //                     $roleCounts[$role->name]['NewApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'applied')
    //                         ->count();
    //                     break;
    //                 case 'content_contributor':
    //                     $roleCounts[$role->name]['TotalOpenings'] = Job::where('status', '!=', '0')->count();
    //                     $roleCounts[$role->name]['TotalApplications'] = JobApplication::count();
    //                     $roleCounts[$role->name]['TotalHired'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'hired')
    //                         ->count();
    //                     $roleCounts[$role->name]['TotalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'rejected')
    //                         ->count();
    //                     $roleCounts[$role->name]['NewApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'applied')
    //                         ->count();
    //                     $roleCounts[$role->name]['OnlineExam'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'Pass')
    //                         ->count();
    //                     break;
    //                 case 'section_manager':
    //                     $roleCounts[$role->name]['TotalOpenings'] = Job::join('jobassigns', 'jobassigns.job_id', '=', 'jobs.id')
    //                         ->where('jobassigns.user_id', auth()->user()->id)
    //                         ->where('jobs.status', '!=', '0')
    //                         ->count();
    //                     $roleCounts[$role->name]['TotalApplications'] = JobApplication::where('added_by', auth()->user()->id)->count();
    //                     $roleCounts[$role->name]['TotalRejected'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'rejected')
    //                         ->where('job_applications.added_by', auth()->user()->id)
    //                         ->count();
    //                     $roleCounts[$role->name]['CandidateStore'] = JobApplication::onlyTrashed()->where('added_by', auth()->user()->id)->count();
    //                     $roleCounts[$role->name]['NewApplications'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'applied')
    //                         ->where('job_applications.added_by', auth()->user()->id)
    //                         ->count();
    //                     $roleCounts[$role->name]['OnlineExam'] = JobApplication::join('application_status', 'application_status.id', '=', 'job_applications.status_id')
    //                         ->where('application_status.status', 'Pass')
    //                         ->where('job_applications.added_by', auth()->user()->id)
    //                         ->count();
    //                     $roleCounts[$role->name]['InterviewRound1'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
    //                         ->leftJoin('job_applications', 'job_applications.id', 'interview_schedules.job_application_id')
    //                         ->where('interview_schedules.status', 'interview round 1')
    //                         ->whereNull('job_applications.deleted_at')
    //                         ->count();
    //                     $roleCounts[$role->name]['InterviewRound2'] = InterviewSchedule::select('interview_schedules.id', 'interview_schedules.status')
    //                         ->leftJoin('job_applications', 'job_applications.id', 'interview_schedules.job_application_id')
    //                         ->where('interview_schedules.status', 'interview round 2')
    //                         ->whereNull('job_applications.deleted_at')
    //                         ->count();
    //                     break;
    //                 default:
    //                     $roleCounts[$role->name] = [];
    //                     break;
    //             }
    //         }
    
    //         return $this->successJson('Dashboard Insights', 200, [
    //             'CandidateCount' => $candidateCount,
    //             'RoleCounts' => $roleCounts
    //         ]);
    
    //     } catch (\Exception $e) {
    //         Log::error('Failed to retrieve dashboard insights', ['error' => $e->getMessage()]);
    //         return $this->errorJson('Something went wrong', 500, $e->getMessage());
    //     }
    // }
    



    public function getMrfInsights($Pid)
    {
        try {
            // Fetch all MRF details
            $mrfDetails = Jobrecruitment::select('id', 'MrfStatus', 'updated_at', 'M_id', 'total_positions') ->where('job_id', $Pid)
                ->get();

            $mrfInsights = [];

            foreach ($mrfDetails as $mrf) {
                // Count the number of candidates associated with this MRF
                $candidateCount = Candidate::where('MRFId', $mrf->id)->count();

                // Calculate the number of left candidates
                $leftCandidates = $mrf->total_positions - $candidateCount;

                $mrfInsights[] = [
                    // 'id' => $mrf->id,
                    // 'MrfStatus' => $this->getMrfStatusName($mrf->MrfStatus),
                    'updated_at' => $mrf->updated_at,
                    'M_id' => $mrf->M_id,
                    'TotalPositions' => $mrf->total_positions,
                    'CandidatesUploaded' => $candidateCount,
                    'LeftCandidates' => $leftCandidates,
                ];
            }

            return response()->json([
                'status' => 'success',
                'data' => $mrfInsights
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to fetch MRF insights',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    public function candidateInsights()
    {
        $year = Carbon::now()->year; // Default to current year

        // Get candidate history data grouped by month
        $candidateHistory = candidate_history::select(
                DB::raw('MONTH(created_at) as month'),
                DB::raw('COUNT(CASE WHEN status_id = 1 THEN 1 END) as applied_count'),
                DB::raw('COUNT(CASE WHEN status_id = 9 THEN 1 END) as onboard_count')
            )
            ->whereYear('created_at', $year)
            ->groupBy(DB::raw('MONTH(created_at)'))
            ->orderBy(DB::raw('MONTH(created_at)'))
            ->get();

        // Initialize the insights array for all months
        $insights = [];
        for ($month = 1; $month <= 12; $month++) {
            $insights[$month] = [
                'month' => Carbon::create()->month($month)->format('F'),
                'applied_count' => 0,
                'onboard_count' => 0,
            ];
        }

        // Fill the insights array with actual data
        foreach ($candidateHistory as $history) {
            $insights[$history->month]['applied_count'] = $history->applied_count;
            $insights[$history->month]['onboard_count'] = $history->onboard_count;
        }

        // Reindex the insights array to remove month keys
        $insights = array_values($insights);

        return response()->json([
            'year' => $year,
            'insights' => $insights
        ]);
    }

}
