<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helper\Reply;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Department;
use Illuminate\Support\Facades\Log;
class DepartmentController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    public function index()
    {
        try {
            // Fetch departments with their head of department details
            $departments = Department::select('departments.*', 'headofdepartment.id as HeadOfDepartmentId', 
                'headofdepartment.Name as HeadOfDepartmentName', 
                'headofdepartment.Email as HeadOfDepartmentEmail', 
                'headofdepartment.MobileNo as HeadOfDepartmentMobileNo')
                ->leftJoin('headofdepartment', 'departments.id', '=', 'headofdepartment.DepartmentId')
                ->orderby('Name','asc')
                ->get();
    
            // Check if departments are found
            if ($departments->isEmpty()) {
                return $this->errorJson('No department details found', 404);
            }
    
            // Map the result to the desired format
            $result = $departments->map(function ($department) {
                return [
                    'DepartmentId' => $department->id,
                    'DepartmentName' => $department->name,
                    'HeadOfDepartment' => $department->HeadOfDepartmentId ? [
                        'Id' => $department->HeadOfDepartmentId,
                        'Name' => $department->HeadOfDepartmentName,
                        'Email' => $department->HeadOfDepartmentEmail,
                        'MobileNo' => $department->HeadOfDepartmentMobileNo,
                    ] : null
                ];
            });
    
            return $this->successJson('Department details retrieved successfully', 200, $result);
    
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred while retrieving department details: ' . $e->getMessage(), 500);
        }
    }
    
   

    public function add(Request $request)
    {
        try {
            // Check if the user has permission to add a department
            if (!auth()->user()->cans('add_department')) {
                return $this->errorJson('Not authenticated to perform this request', 403);
            }

            // Validate the request data
            $validator = Validator::make($request->all(), [
                'name' => 'required|unique:departments',
            ]);

            // Return validation errors if any
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 422);
            }

            // Create the department
            $department = Department::create(['name' => $request->name]);

            // Check if the department was created successfully
            if (!empty($department)) {
                return $this->successJson('Department Added Successfully', 200, $department);
            } else {
                return $this->errorJson('Something went wrong', 500);
            }

        } catch (\Exception $e) {
            // Handle any exceptions that occur
            Log::error('Error adding department', ['message' => $e->getMessage()]);
            return $this->errorJson('An error occurred while adding the department: ' . $e->getMessage(), 500);
        }
    }




    public function get($id)
    {
            try {
                // Validate the department ID (assuming it's an integer)
                if (!is_numeric($id) || $id <= 0) {
                    return $this->errorJson('Invalid Department ID', 400);
                }

                // Fetch the department with its head of department details
                $department = Department::select(
                    'departments.*', 
                    'headofdepartment.id as HeadOfDepartmentId', 
                    'headofdepartment.Name as HeadOfDepartmentName', 
                    'headofdepartment.Email as HeadOfDepartmentEmail', 
                    'headofdepartment.MobileNo as HeadOfDepartmentMobileNo'
                )
                ->leftJoin('headofdepartment', 'departments.id', '=', 'headofdepartment.DepartmentId')
                ->where('departments.id', $id)
                ->first();

                // Check if the department was found
                if ($department) {
                    $result = [
                        'DepartmentId' => $department->id,
                        'DepartmentName' => $department->name,
                        'HeadOfDepartment' => $department->HeadOfDepartmentId ? [
                            'Id' => $department->HeadOfDepartmentId,
                            'Name' => $department->HeadOfDepartmentName,
                            'Email' => $department->HeadOfDepartmentEmail,
                            'MobileNo' => $department->HeadOfDepartmentMobileNo,
                        ] : null
                    ];
                    return $this->successJson('Department Details', 200, $result);
                } else {
                    return $this->errorJson('Department Not Found', 404);
                }
            } catch (\Exception $e) {
                // Handle any exceptions that occur
                return $this->errorJson('An error occurred while retrieving department details: ' . $e->getMessage(), 500);
            }
        }

    
        public function update(Request $request, $id)
        {
            try {
                // Check if the user has permission to edit the department
                if (!auth()->user()->cans('edit_department')) {
                    return $this->errorJson('Not authenticated to perform this request', 403);
                }
        
                // Validate the department ID
                if (!is_numeric($id) || $id <= 0) {
                    return $this->errorJson('Invalid Department ID', 400);
                }
        
                // Find the department
                $department = Department::find($id);
        
                // Check if the department exists
                if (empty($department)) {
                    return $this->errorJson('Department not found', 404);
                }
        
                // Validate the request data
                $validator = Validator::make($request->all(), [
                    'name' => ['required', Rule::unique('departments')->ignore($id)],
                ]);
        
                // Return validation errors if any
                if ($validator->fails()) {
                    return response()->json(['error' => $validator->errors()], 422);
                }
        
                // Update the department
                $department->name = $request->name;
                $department->save();
                Log::info('Department updated successfully', ['department_id' => $id]);
        
                return $this->successJson('Department updated successfully', 200, $department);
        
            } catch (\Exception $e) {
                // Handle any exceptions that occur
                Log::error('Error updating department', ['message' => $e->getMessage()]);
                return $this->errorJson('An error occurred while updating the department: ' . $e->getMessage(), 500);
            }
        }
        
        public function destroy($id)
        {
            try {
                // Check if the user has permission to delete the department
                if (!auth()->user()->cans('delete_department')) {
                    return $this->errorJson('Not authenticated to perform this request', 403);
                }
        
                // Validate the department ID
                if (!is_numeric($id) || $id <= 0) {
                    return $this->errorJson('Invalid Department ID', 400);
                }
        
                // Find the department
                $department = Department::find($id);
        
                // Check if the department exists
                if (empty($department)) {
                    return $this->errorJson('Department not found', 404);
                }
        
                // Delete the department
                $department->delete();
                Log::info('Department deleted successfully', ['department_id' => $id]);
                return $this->successJson('Department deleted successfully', 200);
        
            } catch (\Exception $e) {
                // Handle any exceptions that occur
                Log::error('Error deleting department', ['message' => $e->getMessage()]);
                return $this->errorJson('An error occurred while deleting the department: ' . $e->getMessage(), 500);
            }
        }
        
}
