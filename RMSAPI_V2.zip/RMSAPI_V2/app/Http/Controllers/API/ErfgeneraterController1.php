<?php

namespace App\Http\Controllers\API;
use Illuminate\Support\Facades\Log; 
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Job;
use App\Skill;
use App\Company;
use App\JobType;
use App\JobSkill;
use App\Question;
use App\JobCategory;
use App\JobLocation;
use App\Helper\Reply; 
use App\JobApplication;
use App\WorkExperience;
use App\ApplicationStatus;
use Illuminate\Support\Str; 
use App\Events\JobAlertEvent;
use App\Http\Requests\StoreJob;
use App\Http\Requests\UpdateJob;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB; 
use App\Notifications\NewJobOpening; 
use Illuminate\Support\Facades\Notification; 
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator; 
use App\Mail\Approvedlink;
use App\Mail\SalaryverifyMail;
use App\Replacementemployee;
use App\JobSubqualification;
use App\Jobrecruitment;
use App\EmailLog;
use Illuminate\Support\Facades\View; 
use Mail;
use Auth;
use App\Salarycreation;
use App\Complayer;
use App\Jobcertification;
use App\Jobqualification;
use Illuminate\Support\Facades\Crypt;
use App\User;
use App\Candidate;
use App\candidate_status;
use App\candidate_history;
use App\Role;
use App\RoleUser;

use App\Mail\MRFMail;

class ErfgeneraterController extends Controller
{
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }

    public function index()
    {
        try {
            // Fetch jobs with related department, job recruitment, and job assigned details
            $categories = Job::with(['department', 'jobrecruitment', 'jobassigned'])
                ->where('id', '>', '0')
                ->orderBy('id', 'DESC')
                ->get();

            // Check if jobs are found
            if (!empty($categories)){
                return $this->successJson('Job Details', 200, $categories);
            } else {
                return $this->errorJson('No job details found', 404);
            }
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred while retrieving job details: ' . $e->getMessage(), 500);
        }
    }



    public function Getmrf()
    {
        try {
          
            // $mrf = Jobrecruitment::leftJoin('jobs', 'jobs.id', '=', 'jobrecruitments.job_id')
            // ->select('jobs.*', 'jobrecruitments.*')
            // ->get();

            if(!auth()->user()->cans('view_mrf')){
                return $this->errorJson('Not authenticated to perform this request',403);
            }
            
            $mrf=Jobrecruitment::with(['job','department','jd','category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned'])->get();

            if ($mrf->isEmpty()) {
                return $this->errorJson('No MRF Found', 404);
            }

            return $this->successJson('MRF Details', 200, $mrf);
        } catch (\Exception $e) {
            return $this->errorJson('Failed to fetch MRF', 500, $e->getMessage());
        }
    }

     
    public function GetMrfRecruitmentType(Request $request)
    {
        try {
            if(!auth()->user()->cans('view_mrf')){
                return $this->errorJson('Not authenticated to perform this request',403);
            }
            // Get recruitment_type from the request 
            $recruitmentType = $request->input('recruitment_type');
            $search = $request->input('search');
            $userName = $request->user()->name; 
            $userId = $request->user()->id;
            // Validate  for recruitment_type
            if (!in_array($recruitmentType, ['onsite', 'inhouse'])) {
                return $this->errorJson('Invalid recruitment type', 400);
            }

            // Fetch data with the specified recruitment_type
            // $mrf = Jobrecruitment::with(['job', 'department', 'jd', 'category', 'skills', 'qualification', 'subqualifications', 'replacements', 'anycertification', 'assignBy', 'assigned'])
            //     ->where('recruitment_type', $recruitmentType)
            //     ->get();



            $mrf = Jobrecruitment::with(['job', 'department', 'jd', 'category', 'skills', 'qualification', 'subqualifications', 'replacements', 'anycertification', 'assignBy', 'assigned','projectManagerName','ReportingTeam','assignedUser'])
            ->where('recruitment_type', $recruitmentType)
            ->where(function ($query) use ($userId, $userName) {
                if ($userName === 'Admin') {
                    // Admin sees all records
                    $query->whereRaw('1 = 1');
                }else {
                    // Non-admin users see only records assigned to them
                    $query->whereHas('job', function ($query) use ($userId) {
                        $query->where('assignTo', $userId);
                    });
                }
            })
            ->when($search, function ($query, $search) {
                $query->where(function ($query) use ($search) {
                    $query->orwhere('degination', 'like', "%{$search}%")
                          ->orWhere('start_date', 'like', "%{$search}%")
                          ->orWhere('end_date', 'like', "%{$search}%")
                          ->orWhere('location', 'like', "%{$search}%")
                          ->orWhere('M_id', 'like', "%{$search}%")
                          ->orWhereHas('category', function ($q) use ($search) {
                            $q->where('name', 'like', "%{$search}%");
                        })
                          ->orWhereHas('projectManagerName', function ($q) use ($search) {
                            $q->where('name', 'like', "%{$search}%");
                        })
                          ->orWhereHas('job', function ($q) use ($search) {
                            $q->where('Pid', 'like', "%{$search}%");
                        })
                          ->orWhereHas('ReportingTeam', function ($q) use ($search) {
                            $q->where('name', 'like', "%{$search}%");
                        });
                });
            })
            ->get();

                // Modify each MRF to include full scopeofwork URL
            $mrf->transform(function ($item) {
                // Assuming scopeofwork is a property of $item
                $scopeOfWorkPath = $item->scopeofwork;

                // Remove 'public/' from the path if it exists
                $scopeOfWorkPath = str_replace('public/', '', $scopeOfWorkPath);

                // Generate the full URL
                $scopeOfWorkUrl = url($scopeOfWorkPath);
                $item->scopeofwork_url = $scopeOfWorkUrl;

                return $item;
            });

            if ($mrf->isEmpty()) {
                return $this->errorJson('No MRF Found', 404);
            }

            return $this->successJson('MRF Details', 200, $mrf);
        } catch (\Exception $e) {
            return $this->errorJson('Failed to fetch MRF', 500, $e->getMessage());
        }
    }






    public function GetmrfById($id)
    {
        try {
      
            $mrf=Jobrecruitment::with(['job','department','jd','category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned'])->where('id',$id)->get();

            if ($mrf->isEmpty()) {
                return $this->errorJson('No MRF Found', 404);
            }

            return $this->successJson('MRF Details', 200, $mrf);
        } catch (\Exception $e) {
            return $this->errorJson('Failed to fetch MRF', 500, $e->getMessage());
        }
    }


    // public function Getmrf()
    // {
    //     try {
    //         $mrf = Jobrecruitment::all();
            
    //         if($mrf->isEmpty())
    //         {
    //             return $this->errorJson('No MRF Found', 404);
    //         }
            
    //         return $this->successJson('MRF Details', 200, $mrf);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Failed to fetch MRF', 500, $e->getMessage());
    //     }

    // }
    
    public function view($id)
    {
       
            $categories = Job::with(['skills','user','department','qualification','jobassign','subqualifications','replacements'])->where('id',$id)->get();
            if(!empty($categories)){
                return $this->successJson('ERF Details',200,$categories);
            }else{
                return $this->successJson('not found Details',200);
            }
        
      
    } 


    public function recruitment_type($recruitment_type, Request $request)
    {
        try {
            $search = $request->input('search');
             // Get the ID of the currently logged-in user
            $userId = $request->user()->id;
            $userName = $request->user()->name; 
            $categories = Job::with(['skills', 'user', 'department', 'qualification', 'jobassign', 'subqualifications', 'replacements','jobCategory','assignedUser'])
                ->where('recruitment_type', $recruitment_type)
                ->where(function ($query) use ($userId, $userName) {
                    $query->where('assignTo', $userId)
                          ->orWhere(function ($q) use ($userName) {
                              if ($userName === 'Admin') {
                                  $q->whereRaw('1 = 1'); 
                              }
                          });
                        })
                ->when($search, function ($query, $search) {
                    $query->where(function ($query) use ($search) {
                        $query->orWhere('pid', 'like', "%{$search}%")
                              ->orWhere('project_name', 'like', "%{$search}%")
                              ->orWhere('status', 'like', "%{$search}%")
                              ->orWhereHas('department', function ($q) use ($search) {
                                  $q->where('name', 'like', "%{$search}%");
                              })
                               ->orWhereHas('jobCategory', function ($q) use ($search) {
                                   $q->where('name', 'like', "%{$search}%");
                               });
                    });
                })
                ->get();
              // Include assigned user's name only if the user is an Admin
        $categories->transform(function ($item) use ($userName) {
            if ($userName === 'Admin') {
                $item->assignedUserName = $item->assignedUser ? $item->assignedUser->name : null;
            }
            return $item;
        });
    
            if ($categories->isNotEmpty()) {
                return $this->successJson('ERF Details', 200, $categories);
            } else {
                return $this->successJson('No details found', 200);
            }
        } catch (\Exception $e) {
            return $this->errorJson('Error fetching details', 500, $e->getMessage());
        }
    }
    


    public function generateInhousePid()
    {
        do {
            // Generate a random string with a length of 5 characters
            $pid = 'PID_' . Str::random(5);
        } while (Job::where('pid', $pid)->exists());

        return $pid;
    }


    public function store(Request $request)
    {

      if(!auth()->user()->cans('add_project')){
                return $this->errorJson('Not authenticated to perform this request',403);
            }else{

        $validator = Validator::make($request->all(), [
           
             //'pid' => 'required',
             'pid' => 'unique:jobs,pid'
          
        ]);
        if ($validator->fails()) {
           return response()->json(['error'=>$validator->errors()], 422);
        }
        
        try {
            $jobs = Job::latest()->first();
            $prefix="C".date("y").'I';
            if ($jobs != null)
             {
                $preid =  $jobs->erf_id;
                $preidg = explode($prefix,$preid)[1]; 

                $counter = str_pad((int)$preidg+1, 4 ,"0",STR_PAD_LEFT);
                $new_prefix = $counter;

            }
            else
            {

                $new_prefix = '0001';
            }
          
            \DB::beginTransaction();
            $job = new Job();
            $job->billable_type = $request->billable_type;
           // $job->pid = $request->pid;
          
            // Generate a new pid if recruitment_type is 'inhouse'
            if ($request->recruitment_type == 'inhouse') 
            {
                $job->pid = $this->generateInhousePid();
                $job->recruitment_type=$request->recruitment_type;
                $job->department_id = $request->department_id;
                $job->erf_id=$prefix.$new_prefix;
                $job->project_lead=$request->project_lead;
                $link=$prefix.$new_prefix;
                $job->category_id = $request->category_id;
                $job->user_id=auth()->user()->id; 
                 $job->billable_type='yes';
                 $job->JobStatus= 1; 
                $job->approved=$request->approved; 
                $myEmail = 'utsavtiwari764@gmail.com';
                $url= config('app.AppBaseURL').'erfapproval/'.$link; 
                $details = [
                   'title' => 'Mail from CIPL Project Approval MD',
                   'url' => $url
               ];
                                    
                if($request->approved=='yes')
                {
                    $job->status='waiting for approval';
                    Log::info('Attempting to send approval email', ['job_id' => $job->id, 'recipient_email' => $myEmail]);
                     // Render the view to a string
                     $emailContent = View::make('emails.Approvedlink', ['details' => $details])->render();

                    Mail::to($myEmail)->send(new Approvedlink($details));

                    $SenderEmail = APP_EMAIL;
                    EmailLog::create([
                        'recipient' => $myEmail,
                        'subject' => $details['title'],
                        'body' =>   $emailContent,
                       
                        'Sender'=> $SenderEmail
                    ]);
                    Log::info('Approval email sent successfully', ['job_id' => $job->id, 'recipient_email' => $myEmail]);
    
                }
            }else
            {
                $job->pid = $request->pid;
                $job->recruitment_type=$request->recruitment_type;
                $job->department_id = $request->department_id;
                $job->erf_id=$prefix.$new_prefix;
                $job->project_lead=$request->project_lead;
                $job->project_name=$request->project_name;
                $job->requisition_date=$request->requisition_date;
                $job->title=$request->title;
                $job->target_date=$request->target_date;
                $job->category_id = $request->category_id;
                $job->no_of_possion=$request->no_of_possion;
                $job->budget=$request->budget;
                $job->assignBy=$request->assignBy;
                $job->assignTo=$request->assignTo;
                // $job->numberOfInterviewRound=$request->numberOfInterviewRound;
                // $job->isclientSide=$request->isclientSide;
                $job->jd=$request->jd;
                $job->JobStatus= 1;
                $link=$prefix.$new_prefix;  
                $job->user_id=auth()->user()->id; 
                $job->approved=$request->approved; 
                $job->billable_type=$request->billable_type;
                //fetching the project lead email from users table
                $projectLead = User::find($request->project_lead);
                $projectLeadEmail = $projectLead->email;
               // $myEmail = 'utsavtiwari764@gmail.com';
                $url= config('app.AppBaseURL').'erfapproval/'.$link; 
                $details = [
                   'title' => 'Mail from CIPL Project Approval (Project Lead)',
                   'url' => $url
               ];
                if($request->approved=='yes')
                {
                    $job->status='waiting for approval';
                    $emailContent = View::make('emails.Approvedlink', ['details' => $details])->render();
                   Mail::to($projectLeadEmail)->send(new Approvedlink($details));
                   $SenderEmail = APP_EMAIL;
                   EmailLog::create([
                    'recipient' =>$projectLeadEmail,
                    'subject' => 'Mail from CIPL Project Approval (Project Lead)',
                    'body' =>   $emailContent,
                    'Sender'=> $SenderEmail
                ]);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
    
                }

            }


            // } else {
            //     $job->pid = $request->pid;
            // }
            // $job->recruitment=$request->recruitment;
            // $job->department_id = $request->department_id;
            // $job->recruitment_type=$request->recruitment_type;
            // $job->billable_type=$request->billable_type;
            // $job->project_name=$request->project_name;
            // $job->erf_id=$prefix.$new_prefix;
            // $job->user_id=auth()->user()->id;          
            //  $job->approved=$request->approved;
            // if($request->approved=='yes'){
            //     $job->status='0';
            //    // Mail::to($myEmail)->send(new Approvedlink($details));

            // }elseif($request->recruitment_type=='inhouse'){
            //     $job->status='0';
                
        	// //Mail::to($myEmail)->send(new Approvedlink($details));

            // }else{
            //     $job->status='1';
            // }
            $jobData = $job->save();
    
            \DB::commit();


            $jobdetails = Job::find($job->id);
       
            if(!empty($jobdetails))
            {
               // $myEmail = 'rikrit@gmail.com';
               // $myEmail = 'riyuusingh890@gmail.com';
               // $url='https://ciplcrm.org.in/erfapproval/'.$jobdetails->erf_id; 
             // $url='https://ciplcrm.org.in/erfapproval/'.$jobdetails->erf_id; 

                // $details = [
                //             'title' => 'New ERF for approval',
                //             'url' => $url
                //             ]; 

                // $job->status='2';
                // $job->save();
                //\DB::commit();
                //print_r($jobdetails);die();
                //Mail::to($myEmail)->send(new Approvedlink($details));
            

                return $this->successJson('Send Mail Successfully ',200,$jobdetails);


            }else
            {
                return $this->successJson('not found Details',200);
            }

        } catch (\Exception $th) {
            \DB::rollBack();
            return $this->errorJson('something else wrong',403,$th->getMessage());
        }
            }
    }

   public function mail(){
      $data = array('name'=>"Our Code World");
        // Path or name to the blade template to be rendered
        $template_path = 'hello';

        Mail::send(['text'=> $template_path ], $data, function($message) {
            // Set the receiver and subject of the mail.
            $message->to('utsavtiwari764@gmail.com.com', 'Receiver Name')->subject('Laravel First Mail');
            // Set the sender
            $message->from('omegasp9@gmail.com','Our Code World');
        });

        return "Basic email sent, check your inbox.";

   }



public function mrfApproval($id)
{
    try {                    
        Log::info('Starting MRF approval process', ['encrypted_id' => $id]);

        // Decrypt the id
        $decryptedId = Crypt::decryptString($id);
        Log::info('Decrypted ID', ['decrypted_id' => $decryptedId]);
        //echo  $decryptedId;
        // Find the job recruitment record using the decrypted ID
        $jobRecruitment = Jobrecruitment::find($decryptedId);
        Log::info('JobRecruitment found', ['jobRecruitment' => $jobRecruitment]);

        if (!$jobRecruitment) {
            Log::error('MRF not found', ['decrypted_id' => $decryptedId]);
            return response()->json(['error' => 'MRF not found'], 404);
        }

        if ($jobRecruitment->MrfStatus == 3) {
            Log::warning('MRF already approved', ['jobRecruitment' => $jobRecruitment]);
            return response()->json(['error' => 'MRF already approved'], 400);
        }

        // Update the status to "Approved"

        $jobRecruitment->MrfStatus = 3;
        $jobRecruitment->save();
        Log::info('MRF approved successfully', ['jobRecruitment' => $jobRecruitment]);

        return response()->json(['message' => 'MRF approved successfully'], 200);
    } catch (DecryptException $e) {
        Log::error('Decryption failed', ['error' => $e->getMessage(), 'encrypted_id' => $id]);
        return response()->json(['error' => 'Invalid ID'], 400);
    } catch (\Exception $e) {
        Log::error('An error occurred during the MRF approval process', ['error' => $e->getMessage()]);
        return response()->json(['error' => 'Something went wrong'], 500);
    }
}
public function rejectLink($id)
{
    try {
        Log::info('Starting MRF rejection process', ['encrypted_id' => $id]);

        // Decrypt the id
        $decryptedId = Crypt::decryptString($id);
        Log::info('Decrypted ID', ['decrypted_id' => $decryptedId]);

        // Find the job recruitment record using the decrypted ID
        $jobRecruitment = Jobrecruitment::find($decryptedId);
        Log::info('JobRecruitment found', ['jobRecruitment' => $jobRecruitment]);

        if (!$jobRecruitment) {
            Log::error('MRF not found', ['decrypted_id' => $decryptedId]);
            return response()->json(['error' => 'MRF not found'], 404);
        }

        if ($jobRecruitment->MrfStatus == 4) {
            Log::warning('MRF already rejected', ['jobRecruitment' => $jobRecruitment]);
            return response()->json(['error' => 'MRF already rejected'], 400);
        }

        // Update the status to "Rejected"
        $jobRecruitment->MrfStatus = 4;
        $jobRecruitment->save();
        Log::info('MRF rejected successfully', ['jobRecruitment' => $jobRecruitment]);

        return response()->json(['message' => 'MRF rejected successfully'], 200);
    } catch (DecryptException $e) {
        Log::error('Decryption failed', ['error' => $e->getMessage(), 'encrypted_id' => $id]);
        return response()->json(['error' => 'Invalid ID'], 400);
    } catch (\Exception $e) {
        Log::error('An error occurred during the MRF rejection process', ['error' => $e->getMessage()]);
        return response()->json(['error' => 'Something went wrong'], 500);
    }
}



function Leads(Request $request, $id = null)
{
    if ($id==0) {
        
        $job = new Job(); // Create a new empty Job object
        $job->id = 0; // Set id to 0

       
        $validator = Validator::make($request->all(), [
            'category_id' => 'required',
            'location' => 'required',
           'degination' => 'required',
            'level' => 'required',
            'skills' => 'array',
            'position_budgeted' => 'required',
            'total_positions' => 'required',
            'reporting_team' => 'required',
            'project_manager' => 'required',
            'additionalqualification' => 'array',
            'skill_id.0' => 'required',
            'total_experience' => 'required',
            'relevent_exp' => 'required',
            'responsibility' => 'required',
            'qualification.0' => 'required',
            'additionalqualification.0' => 'required',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        try {
            \DB::beginTransaction();

            $requipment = new Jobrecruitment();
            $requipment->job_id = 0; // Assign job_id
            $requipment->category_id = $request->category_id;
            $requipment->qualification_id = $request->qualification[0];
            $requipment->assign_id = $request->assign_id;
            $requipment->anycertification_id = $request->anycertification_id;
            $requipment->degination = $request->degination;
            $requipment->level = $request->level;
            $requipment->location = $request->location;
            $requipment->start_date = $request->start_date;
            $requipment->end_date = $request->end_date;
            $requipment->project_manager = $request->project_manager;
            $requipment->reporting_team = $request->reporting_team;
            $requipment->position_budgeted = $request->position_budgeted;
            $requipment->relevent_exp = $request->relevent_exp;
            $requipment->responsibility = $request->responsibility;
            $requipment->prerequisite = $request->prerequisite;
            $requipment->total_experience = $request->total_experience;
            $requipment->total_positions = $request->total_positions;
            $requipment->title_id = $request->title_id;
            $requipment->created_by_id = auth()->user()->id;
            $requipment->user_id = $request->user_id;
            $requipment->jd_id = $request->jd_id;
            $requipment->M_id = $request->M_id;
            $requipment->recruitment_type = $request->recruitment_type;
            $requipment->assignBy = $request->assignBy;
            $requipment->assignTo = $request->assignTo;
            $requipment->numberOfInterviewRound = $request->numberOfInterviewRound;
            $requipment->isclientSide = $request->isclientSide;
            $requipment->MrfStatus  = 1 ;

            if ($request->hasFile('scopeofwork')) {
                $path = public_path('Erf/scopeofwork/');
                if (!File::isDirectory($path)) {
                    File::makeDirectory($path, 0777, true, true);
                }
                $image = $request->file('scopeofwork');
                $name = time() . '.' . $image->getClientOriginalExtension();
                $image->move($path, $name);
                $requipment->scopeofwork = 'public/Erf/scopeofwork/' . $name;
            }
            $requipment->save();
            // fetching the project_manager email from users table
             $project_manager = User::find($request->project_manager);
              $projectManagerEmail = $project_manager->email;
        
              // Fetching the project name from the jobs table
            $projectName = Job::where('id', $requipment->job_id)->pluck('project_name')->first();
            //$approvalLink = route('mrf.approve', ['id' => $requipment->id]);

            //encrypt id
            $encryptedId = Crypt::encryptString($requipment->id);
            $approvalLink = config('app.AppBaseURL').'mrfApprovalLink/' . $encryptedId;
            $rejectLink= config('app.AppBaseURL').'mrfRejectedLink/'. $encryptedId;
           
            // Get the authenticated user's role display name
             $roleId = auth()->user()->role;
             $role = Role::find($roleId->role_id);
             $senderRole = $role ? $role->display_name : 'N/A';
              $data = [
                'projectManagerName' => $project_manager->name,
                'requesterName' => auth()->user()->name,
                'position' => $request->degination,
                'project' =>  $projectName,
                'mrfNumber' => $requipment->id,
                'status' => 'Pending Approval',
                'senderName' => auth()->user()->name, 
                'senderPosition' => $senderRole, 
                'companyName' => 'Corporate Infotech Pvt Ltd.',
                'approvalLink' => $approvalLink,
                'rejectLink'=>$rejectLink
               // 'clickHere'=>config('app.AppBaseURL').'forMrfApproval/'.$encryptedId
            ];

            // Render the email content as a string
            $emailContent = View::make('emails.mrfMail', $data)->render();

            Mail::to($projectManagerEmail)->send(new MRFMail($data));
            $SenderEmail = APP_EMAIL;
            EmailLog::create([
                'recipient' => $projectManagerEmail,
                'subject' => 'MRF Approve from ProjectLead Inhouse',
                'body' =>  $emailContent,
               
                'Sender'=> $SenderEmail
            ]);
            

            \DB::commit();
			
            if ($request->skill_id != 'Other') {
                JobSkill::where(['jobrecruitment_id' => $requipment->id])->delete();

                foreach ($request->skill_id as $skill) {
                    $jobSkill = new JobSkill();
                    $jobSkill->skill_id = $skill;
                    $jobSkill->jobrecruitment_id = $requipment->id;
                  
                    $jobSkill->save();
                }
            } else {
                $requipment->other_skill = $request->other_skill;
            }

            if (!is_null($request->qualification)) {
                Jobqualification::where(['jobrecruitment_id' => $requipment->id])->delete();
                foreach ($request->qualification as $qskill) {
                    $qualification = new Jobqualification();
                    $qualification->qualification_id = $qskill;
                    $qualification->jobrecruitment_id = $requipment->id;
                    $qualification->save();
                }
            }

            if (!is_null($request->additionalqualification)) {
                JobSubqualification::where(['jobrecruitment_id' => $requipment->id])->delete();
                foreach ($request->additionalqualification as $qskill) {
                    $qualification = new JobSubqualification();
                    $qualification->subqualification_id = $qskill;
                   
                    $qualification->jobrecruitment_id = $requipment->id;
                    $qualification->save();
                }
            }

            if (!is_null($request->anycertification)) {
                Jobcertification::where(['jobrecruitment_id' => $requipment->id])->delete();
                foreach ($request->anycertification as $qskill) {
                    $certification = new Jobcertification();
                    $certification->anycertification_id = $qskill;
                    $certification->jobrecruitment_id = $requipment->id;
                    $certification->save();
                }
            }

            if ($request->employee[0]['emp_name'] != 'null') {

                Replacementemployee::where(['jobrecruitment_id' => $requipment->id])->delete();
                foreach ($request->employee as $key => $value) {
                    $replacement = new Replacementemployee();
                    $replacement->emp_name = $value['emp_name'];
                    $replacement->emp_code = $value['emp_code'];
                    $replacement->resign_date = Carbon::parse($value['resign_date'])->format('Y-m-d');
                    $replacement->last_working_date = Carbon::parse($value['last_working_date'])->format('Y-m-d');
                    $replacement->jobrecruitment_id = $requipment->id;
                    $replacement->save();
                }
            }

			

            \DB::commit();
            return $this->successJson('MRF Form Generated Successfully', 200, $requipment);
        } catch (\Exception $e) {
            \DB::rollBack();
            return $this->errorJson('Something went wrong', 403, $e->getMessage());
        }
    

    }else {
        $job = Job::findOrFail($id);
        if ($job) {
            $validator = Validator::make($request->all(), [
                'category_id' => 'required',
                'location' => 'required',
                'degination' => 'required',
                'level' => 'required',
                'skills' => 'array',
                'position_budgeted' => 'required',
                'total_positions' => 'required',
                'reporting_team' => 'required',
                'project_manager' => 'required',
                'additionalqualification' => 'array',
                'skill_id.0' => 'required',
                'total_experience' => 'required',
                'relevent_exp' => 'required',
                'responsibility' => 'required',
                'qualification.0' => 'required',
                'additionalqualification.0' => 'required',
                'start_date' => 'required|date',
                'end_date' => 'required|date',
            ]);
    
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 422);
            }
    
            try {
                \DB::beginTransaction();
    
                $requipment = new Jobrecruitment();
                $requipment->job_id = $job->id;
                $requipment->category_id = $request->category_id;
                $requipment->qualification_id = $request->qualification[0];
                $requipment->assign_id = $request->assign_id;
                $requipment->anycertification_id = $request->anycertification_id;
                $requipment->degination = $request->degination;
                $requipment->level = $request->level;
                $requipment->location = $request->location;
                $requipment->start_date = $request->start_date;
                $requipment->end_date = $request->end_date;
                $requipment->project_manager = $request->project_manager;
                $requipment->reporting_team = $request->reporting_team;
                $requipment->position_budgeted = $request->position_budgeted;
                $requipment->relevent_exp = $request->relevent_exp;
                $requipment->responsibility = $request->responsibility;
                $requipment->prerequisite = $request->prerequisite;
                $requipment->total_experience = $request->total_experience;
                $requipment->total_positions = $request->total_positions;
                $requipment->title_id = $request->title_id;
                $requipment->created_by_id = auth()->user()->id;
                $requipment->user_id = $request->user_id;
                $requipment->jd_id = $request->jd_id;
                $requipment->M_id = $request->M_id;
                $requipment->recruitment_type = $request->recruitment_type;
                $requipment->MrfStatus  = 1 ;
                $requipment->assignBy = $request->assignBy;
                $requipment->assignTo = $request->assignTo;
                $requipment->numberOfInterviewRound = $request->numberOfInterviewRound;
                $requipment->isclientSide = $request->isclientSide;
    
                if ($request->hasFile('scopeofwork')) {
                    $path = public_path('Erf/scopeofwork/');
                    if (!File::isDirectory($path)) {
                        File::makeDirectory($path, 0777, true, true);
                    }
                    $image = $request->file('scopeofwork');
                    $name = time() . '.' . $image->getClientOriginalExtension();
                    $image->move($path, $name);
                    $requipment->scopeofwork = 'public/Erf/scopeofwork/' . $name;
                }
                $requipment->save();

                // fetching the project_manager email from users table
             $project_manager = User::find($request->project_manager);
             $projectManagerEmail = $project_manager->email;
       
             // Fetching the project name from the jobs table
           $projectName = Job::where('id', $requipment->job_id)->pluck('project_name')->first();
           //$approvalLink = route('mrf.approve', ['id' => $requipment->id]);
           //encrypt id
           $encryptedId = Crypt::encryptString($requipment->id);
           $approvalLink = config('app.AppBaseURL').'mrfApprovalLink/' .$encryptedId;
           $rejectLink= config('app.AppBaseURL').'mrfRejectedLink/'. $encryptedId;
          
           // Get the authenticated user's role display name
            $roleId = auth()->user()->role;
            $role = Role::find($roleId->role_id);
            $senderRole = $role ? $role->display_name : 'N/A';
             $data = [
               'projectManagerName' => $project_manager->name,
               'requesterName' => auth()->user()->name,
               'position' => $request->degination,
               'project' =>  $projectName,
               'mrfNumber' => $requipment->id,
               'status' => 'Pending Approval',
               'senderName' => auth()->user()->name, 
               'senderPosition' => $senderRole, 
               'companyName' => 'Corporate Infotech Pvt Ltd',
               'approvalLink' => $approvalLink ,
               'rejectLink'=>$rejectLink 
           ];

           $emailContent = View::make('emails.mrfMail', $data)->render();

           Mail::to($projectManagerEmail)->send(new MRFMail($data));

           $SenderEmail = APP_EMAIL;
            EmailLog::create([
                'recipient' => $projectManagerEmail,
                'subject' => 'MRF Approve from ProjectLead',
                'body' =>  $emailContent,
               
                'Sender'=> $SenderEmail
            ]);


                if ($request->skill_id != 'Other') {
                    JobSkill::where(['job_id' => $job->id, 'jobrecruitment_id' => $requipment->id])->delete();
    
                    foreach ($request->skill_id as $skill) {
                        $jobSkill = new JobSkill();
                        $jobSkill->skill_id = $skill;
                        $jobSkill->jobrecruitment_id = $requipment->id;
                        $jobSkill->job_id = $job->id;
                        $jobSkill->save();
                    }
                } else {
                    $requipment->other_skill = $request->other_skill;
                }
    
                if (!is_null($request->qualification)) {
                    Jobqualification::where(['job_id' => $job->id, 'jobrecruitment_id' => $requipment->id])->delete();
                    foreach ($request->qualification as $qskill) {
                        $qualification = new Jobqualification();
                        $qualification->qualification_id = $qskill;
                        $qualification->job_id = $job->id;
                        $qualification->jobrecruitment_id = $requipment->id;
                        $qualification->save();
                    }
                }
    
                if (!is_null($request->additionalqualification)) {
                    JobSubqualification::where(['job_id' => $job->id, 'jobrecruitment_id' => $requipment->id])->delete();
                    foreach ($request->additionalqualification as $qskill) {
                        $qualification = new JobSubqualification();
                        $qualification->subqualification_id = $qskill;
                        $qualification->job_id = $job->id;
                        $qualification->jobrecruitment_id = $requipment->id;
                        $qualification->save();
                    }
                }
    
                if (!is_null($request->anycertification)) {
                    Jobcertification::where(['job_id' => $job->id, 'jobrecruitment_id' => $requipment->id])->delete();
                    foreach ($request->anycertification as $qskill) {
                        $certification = new Jobcertification();
                        $certification->anycertification_id = $qskill;
                        $certification->job_id = $job->id;
                        $certification->jobrecruitment_id = $requipment->id;
                        $certification->save();
                    }
                }
    
                if ($request->employee[0]['emp_name'] != 'null') {
    
                    Replacementemployee::where(['job_id' => $job->id, 'jobrecruitment_id' => $requipment->id])->delete();
                    foreach ($request->employee as $key => $value) {
                        $replacement = new Replacementemployee();
                        $replacement->emp_name = $value['emp_name'];
                        $replacement->emp_code = $value['emp_code'];
                        $replacement->resign_date = Carbon::parse($value['resign_date'])->format('Y-m-d');
                        $replacement->last_working_date = Carbon::parse($value['last_working_date'])->format('Y-m-d');
                        $replacement->job_id = $job->id;
                        $replacement->jobrecruitment_id = $requipment->id;
                        $replacement->save();
                    }
                }
    
                \DB::commit();
                return $this->successJson('ERF Form Generated Successfully', 200, $requipment);
            } catch (\Exception $e) {
                \DB::rollBack();
                return $this->errorJson('Something went wrong', 403, $e->getMessage());
            }
        }
    }
    

   
}



   function Leadsupdate(Request $request,$id,$leadid){
    
    $job=Job::findOrFail($id);
    if($job){
        $validator = Validator::make($request->all(), [           
         'category_id'         => 'required',           
            'location' =>'required',  
           "degination"=> "required",
            "level"=> "required",
 	   "skills"=> "array",
                 "position_budgeted"=>'required',
	 'total_positions'=>'required',
           'reporting_team'=>'required',
          'project_manager'=>'required',
         'additionalqualification'=>'array',
           "skill_id.0"      => "required",
          'total_experience'=>'required',
          'relevent_exp'=>'required',
          'responsibility'=>'required',
          'qualification.0'=>'required',
          'additionalqualification.0'=>'required',
          'start_date' => 'required|date',
             'end_date' => 'required|date',

       ]);
       if ($validator->fails()) {
           return response()->json(['error'=>$validator->errors()], 422);
       }
       try {
       \DB::beginTransaction();
       $requipment=Jobrecruitment::findOrFail($leadid);
       $requipment->job_id = $job->id;
       $requipment->category_id = $request->category_id;
       $requipment->qualification_id = $request->qualification_id;
       $requipment->anycertification_id = $request->anycertification_id;
       $requipment->degination = $request->degination;
       $requipment->assign_id=$request->assign_id;
       $requipment->user_id=$request->user_id;
       $requipment->level = $request->level;
       $requipment->location=$request->location;
       $requipment->start_date = $request->start_date;
       $requipment->end_date = $request->end_date;
       $requipment->project_manager = $request->project_manager;
       $requipment->reporting_team = $request->reporting_team;
       $requipment->position_budgeted = $request->position_budgeted;
       $requipment->relevent_exp = $request->relevent_exp;  
       $requipment->responsibility=$request->responsibility;
       $requipment->prerequisite = $request->prerequisite;
       $requipment->total_experience=$request->total_experience;
      $requipment->total_positions=$request->total_positions;
      $requipment->recruitment_type=$request->recruitment_type;
       $requipment->created_by_id=auth()->user()->id;
       $requipment->jd_id = $request->jd_id;
        if($request->hasFile('scopeofwork')) {
            $path = public_path('Erf/scopeofwork/');
            if(!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }
            $image = $request->file('scopeofwork');
            $name = time().'.'.$image->getClientOriginalExtension();            
            $image->move($path, $name);
            $requipment->scopeofwork='public/Erf/scopeofwork/'.$name;
        }
        $requipment->save();
        if ($request->skill_id !='Other') {
            JobSkill::where(['job_id'=>$job->id,'jobrecruitment_id'=>$requipment->id])->delete();

            foreach ($request->skill_id as $skill) {
                $jobSkill = new JobSkill();
                $jobSkill->skill_id = $skill;
                $jobSkill->jobrecruitment_id=$requipment->id;
                $jobSkill->job_id = $job->id;
                $jobSkill->save();
            }
        }else{
            $requipment->other_skill=$request->other_skill;
        }
          if(!is_null($request->qualification)){
            Jobqualification::where(['job_id'=>$job->id,'jobrecruitment_id'=>$requipment->id])->delete();
            foreach ($request->qualification as $qskill) {
                $qualification = new Jobqualification();
                $qualification->qualification_id = $qskill;
                $qualification->job_id = $job->id;
                $qualification->jobrecruitment_id=$requipment->id;
                $qualification->save();
            }
        }

        if(!is_null($request->additionalqualification)){
            JobSubqualification::where(['job_id'=>$job->id,'jobrecruitment_id'=>$requipment->id])->delete();
            foreach ($request->additionalqualification as $qskill) {
                $qualification = new JobSubqualification();
                $qualification->subqualification_id = $qskill;
                $qualification->job_id = $job->id;
                $qualification->jobrecruitment_id=$requipment->id;
                $qualification->save();
            }
        }
        
     if(!is_null($request->anycertification)){
            Jobcertification::where(['job_id'=>$job->id,'jobrecruitment_id'=>$requipment->id])->delete();
            foreach ($request->anycertification as $qskill) {
                $certification = new Jobcertification();
                $certification->anycertification_id = $qskill;
                $certification->job_id = $job->id;
                $certification->jobrecruitment_id=$requipment->id;
                $certification->save();
            } 
        }

         if($request->employee[0]['emp_name']!='null'){
 
            Replacementemployee::where(['job_id'=>$job->id,'jobrecruitment_id'=>$requipment->id])->delete();
            foreach ($request->employee as $key=>$value) {
                $replacement = new Replacementemployee();
                $replacement->emp_name = $value['emp_name'];
                $replacement->emp_code=$value['emp_code'];
                $replacement->resign_date=Carbon::parse($value['resign_date'])->format('Y-m-d');
                $replacement->last_working_date=Carbon::parse($value['last_working_date'])->format('Y-m-d');
                $replacement->job_id = $job->id;
                $replacement->jobrecruitment_id=$requipment->id;
                $replacement->save();
            }
         }
          \DB::commit();
          Log::info('Lead updated successfully', ['lead_id' => $leadid]);
           return $this->successJson('Erf Form Generated Successfully',200,$requipment);
       }
        catch (\Exception $e) {
        \DB::rollBack();
        return $this->errorJson('something else wrong',403,$e->getMessage());
       }
    }
   }



 public function leaddata(Request $request,$id=null){
    try{
        if(!empty($id)){
            $data=Jobrecruitment::with(['job','department','jd','category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned'])->where('job_id',$id)->get();
        
        }else{
        $data=Jobrecruitment::with(['job','department','jd','category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned'])->get();
        
        }

        return $this->successJson('MRF list Successfully',200,$data);
    } catch (\Exception $e) {
        return $this->errorJson('Error fetching dashboard details', 500, $e->getMessage());
    }
 }

 public function getleaddata(Request $request, $id)
{
    try {
       // Fetch the data with the given id
        $data = Jobrecruitment::with(['job', 'department', 'jd', 'category', 'skills', 'qualification', 'subqualifications', 'replacements', 'anycertification', 'assignBy', 'assigned'])
            ->where('id', $id)
            ->get(); 
        //$data = Jobrecruitment::find($id);
        // Check if data is empty
        if ($data->isEmpty()) {
            return $this->errorJson('No data found', 404);
        } else {
            return $this->successJson('Lead list retrieved successfully', 200, $data);
        }
    } catch (\Exception $e) {
        return $this->errorJson('Something went wrong', 500, $e->getMessage());
    }
}







public function approveallinkold($id){
    try{
        $jobdetails = Job::find($id);
       
            if(!empty($jobdetails)){
                $myEmail = 'utsavtiwari764@gmail.com';
              $url=  config('app.AppBaseURL').'erfapproval/'.$jobdetails->erf_id; 

                $details = [
                            'title' => 'New ERF for approval',
                            'url' => $url
                            ]; 

                $jobdetails->status='2';
                $jobdetails->save();
                //print_r($jobdetails);die();
                Mail::to($myEmail)->send(new Approvedlink($details));
            
                return $this->successJson('Send Mail Successfully',200,$jobdetails);
            }else{
                return $this->successJson('not found Details',200);
            }
        } catch (\Exception $e) {
            return $this->errorJson('Error fetching job details', 500, $e->getMessage());
        }
}

public function approveallink($id){
    try{
        $jobdetails = Job::find($id);
        $detailsposistion = Jobrecruitment::with(['job','jd','department','category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned'])->where('job_id',$id)->get();
              
            if(!empty($jobdetails)){
               // $myEmail = 'akhilesh1.epic@gmail.com';
                 $myEmail = 'utsavtiwari764@gmail.com';
               // $url='https://ciplcrm.org.in/erfapproval/'.$jobdetails->erf_id; 
              $url=config('app.AppBaseURL').'erfapproval/'.$jobdetails->erf_id; 

                $details = [
                            'title' => 'New ERF for approval',
                            'detailsposistion'=>$detailsposistion->toArray(),
                            'jobdetails'=>$jobdetails,
                            'url' => $url
                            ]; 

                $jobdetails->status='2';
                $jobdetails->save();
                //print_r($jobdetails);die();


                Mail::to($myEmail)->send(new Approvedlink($details));
                Log::info('Approval email sent', ['email' => $myEmail, 'job_id' => $id]);

            
                return $this->successJson('Mail Sent Successfully',200,$detailsposistion);
            }else{
                return $this->successJson('not found Details',200);
            }
        } catch (\Exception $e) {
            return $this->errorJson('Something went wrong', 500, $e->getMessage());
        }
}

//    function Salarycreated(Request $request ,$id)
//    {

//     $jobApplications = JobApplication::where('CandidateId', $id)->get();

//         $job=JobApplication::with(['interviewround2'])->findOrFail($jobApplications->$id);
//         // return $this->successJson('Salary Created Successfully',200,$job);
//         if($job){
//           $validator = Validator::make($request->all(), [           
//             'ctc'         => 'required',           
            

//        ]);
//        if ($validator->fails()) {
//            return response()->json(['error'=>$validator->errors()], 422);
//        }

//         try {
//             Log::info('Transaction started', ['job_application_id' =>$jobApplications->$id]);
//        \DB::beginTransaction();
        
       

//         $requipment=new Salarycreation;
//         $requipment->job_application_id  =$jobApplications->$id;
//         $requipment->employeeCode = $request->employeeCode;
//         $requipment->location = $request->location;
//         $requipment->salaryType = $request->salaryType;
//         $requipment->name = $request->name;
//         $requipment->state = $request->state;
//         $requipment->designation=$request->designation;
//         $requipment->effectiveDate = $request->effectiveDate;
//         $requipment->dateOfJoining = $request->dateOfJoining;
//         $requipment->ctc = $request->ctc;
//         $requipment->basicMonthly = $request->basicMonthly;
//         $requipment->basicAnnual=$request->basicAnnual;
//         $requipment->hrmMonthly = $request->hrmMonthly;
//         $requipment->hrmAnnual = $request->hrmAnnual;
//         $requipment->specialMonthly = $request->specialMonthly;
//         $requipment->spciealAnnual=$request->spciealAnnual;
//         $requipment->pfMonthly = $request->pfMonthly;
//         $requipment->pTaxMonthly = $request->pTaxMonthly;
//         $requipment->totalDeductionAnnually = $request->totalDeductionAnnually;
//         $requipment->pfEMonthly=$request->pfEMonthly;
//         $requipment->pfEAnnually = $request->pfEAnnually;
//         $requipment->pfAAnnually = $request->pfAAnnually;
//         $requipment->eStateInsuranceMonthly = $request->eStateInsuranceMonthly;
//         $requipment->eStateInsuranceAnnually=$request->eStateInsuranceAnnually;
//         $requipment->gratuityMonthly = $request->gratuityMonthly;
//         $requipment->gratuityAnnually = $request->gratuityAnnually;
//         $requipment->ltaMonthly = $request->ltaMonthly;
//         $requipment->ltaAnnually=$request->ltaAnnually;
//         $requipment->insuranceMonthly = $request->insuranceMonthly;
//         $requipment->insuranceAnnually = $request->insuranceAnnually;
//         $requipment->fixedCtcMonthly = $request->fixedCtcMonthly;
//         $requipment->fixedCtcAnnually=$request->fixedCtcAnnually;
//         $requipment->totalCTC = $request->totalCTC;
//         $requipment->netTakeHome = $request->netTakeHome;
//         $requipment->grossAmount = $request->grossAmount;
//         $requipment->pTaxAnnually =$request->pTaxAnnually;
//         $requipment->totalDeductionMonthly =$request->totalDeductionMonthly;
//         $requipment->pfAMonthly =$request->pfAMonthly; 
//         $requipment->retension=$request->retension;
//         $requipment->retensionBonus=$request->retensionBonus;
//         $requipment->save();

//         Log::info('Salary record created and saved', ['salary_id' => $requipment->id]);

//          if(!is_null($request->complayers)){
//             foreach ($request->complayers as $key=>$value) {
//                 if($value['email']){

//                 $complayer = new Complayer();
//                 $complayer->email = $value['email'];
//                 $complayer->job_application_id  =$jobApplications->$id;
//                 $complayer->salarycreation_id=$requipment->id;
//                 $complayer->save();
//                 $url= config('app.AppBaseURL').'salaryverification/'.Crypt::encryptString($complayer->id); 
//                 $details = [
//                             'title' => 'Salary verification link',
//                             'url' => $url,	
			     
//                             ]; 
//                 Mail::to($value['email'])->send(new SalaryverifyMail($details,$job));
//                 Log::info('Verification email sent', ['email' => $value['email'], 'complayer_id' => $complayer->id]);
//                 $complayer->save();
//               }
//             }
//         }    
     
//           $requipment->status ='0'; 
//         $requipment->save();          
         
//          $job->status_id=10;
//         //candidate history 
//         candidate_history::create([
//             'remarks' => 'Salary Negotiation',
//             'status_id' => 18,
//             'candidate_id' => $id,
//             'isactive' => 1,
//         ]);
        

//        // Update candidate status_id
//        Candidate::where('id', $id)->update(['status_id' => 18]);
//         $job->save();


//            \DB::commit();
//             return $this->successJson('Salary Created Successfully',200,$requipment);
//         }
//          catch (\Exception $e) {
//          \DB::rollBack();
//          return $this->errorJson('something else wrong',403,$e->getMessage());
//         }
//     }else{
//         return $this->errorJson('Job Application not founds',404);
//     }
      
//     }

//new method 
public function Salarycreated(Request $request, $id)
{
    // Retrieve the job application for the given candidate ID
    $jobApplications = JobApplication::where('CandidateId', $id)->get();

    if ($jobApplications->isEmpty()) {
        return $this->errorJson('Job Application not found', 404);
    }

    // Assuming you want to handle the first job application for the candidate
    $jobApplication = $jobApplications->first();

    // Load the related interview round data for the job application
    $job = JobApplication::with(['interviews'])->findOrFail($jobApplication->id);

    // Validate the request data
    $validator = Validator::make($request->all(), [
        'ctc' => 'required',
        // add other validation rules as needed
    ]);

    if ($validator->fails()) {
        return response()->json(['error' => $validator->errors()], 422);
    }

    try {
        Log::info('Transaction started', ['job_application_id' => $jobApplication->id]);
        \DB::beginTransaction();

        // Create a new Salarycreation record
        $salaryCreation = new Salarycreation();
        $salaryCreation->job_application_id = $jobApplication->id;
        $salaryCreation->employeeCode = $request->employeeCode;
        $salaryCreation->location = $request->location;
        $salaryCreation->salaryType = $request->salaryType;
        $salaryCreation->name = $request->name;
        $salaryCreation->state = $request->state;
        $salaryCreation->designation = $request->designation;
        $salaryCreation->effectiveDate = $request->effectiveDate;
        $salaryCreation->dateOfJoining = $request->dateOfJoining;
        $salaryCreation->ctc = $request->ctc;
        $salaryCreation->basicMonthly = $request->basicMonthly;
        $salaryCreation->basicAnnual = $request->basicAnnual;
        $salaryCreation->hrmMonthly = $request->hrmMonthly;
        $salaryCreation->hrmAnnual = $request->hrmAnnual;
        $salaryCreation->specialMonthly = $request->specialMonthly;
        $salaryCreation->spciealAnnual=$request->spciealAnnual;
        $salaryCreation->pfMonthly = $request->pfMonthly;
        $salaryCreation->pTaxMonthly = $request->pTaxMonthly;
        $salaryCreation->totalDeductionAnnually = $request->totalDeductionAnnually;
        $salaryCreation->pfEMonthly = $request->pfEMonthly;
        $salaryCreation->pfEAnnually = $request->pfEAnnually;
        $salaryCreation->pfAAnnually = $request->pfAAnnually;
        $salaryCreation->eStateInsuranceMonthly = $request->eStateInsuranceMonthly;
        $salaryCreation->eStateInsuranceAnnually = $request->eStateInsuranceAnnually;
        $salaryCreation->gratuityMonthly = $request->gratuityMonthly;
        $salaryCreation->gratuityAnnually = $request->gratuityAnnually;
        $salaryCreation->ltaMonthly = $request->ltaMonthly;
        $salaryCreation->ltaAnnually = $request->ltaAnnually;
        $salaryCreation->insuranceMonthly = $request->insuranceMonthly;
        $salaryCreation->insuranceAnnually = $request->insuranceAnnually;
        $salaryCreation->fixedCtcMonthly = $request->fixedCtcMonthly;
        $salaryCreation->fixedCtcAnnually = $request->fixedCtcAnnually;
        $salaryCreation->totalCTC = $request->totalCTC;
        $salaryCreation->netTakeHome = $request->netTakeHome;
        $salaryCreation->grossAmount = $request->grossAmount;
        $salaryCreation->pTaxAnnually = $request->pTaxAnnually;
        $salaryCreation->totalDeductionMonthly = $request->totalDeductionMonthly;
        $salaryCreation->pfAMonthly = $request->pfAMonthly;
        $salaryCreation->retension = $request->retension;
        $salaryCreation->retensionBonus = $request->retensionBonus;
        $salaryCreation->save();

        Log::info('Salary record created and saved', ['salary_id' => $salaryCreation->id]);

        if (!is_null($request->complayers)) {
            foreach ($request->complayers as $key => $value) {
                if ($value['email']) {
                    $complayer = new Complayer();
                    $complayer->email = $value['email'];
                    $complayer->name=$request->name;
                    $complayer->position=$request->designation;
                //     $complayer->name = $value['name']; 
              
                //    $complayer->position = $value['designation']; 
                    $complayer->job_application_id = $jobApplication->id;
                    $complayer->salarycreation_id = $salaryCreation->id;
                    $complayer->save();
                    $url = config('app.AppBaseURL') . 'salaryverification/' . Crypt::encryptString($complayer->id);
                    $details = [
                        'title' => 'Salary verification link',
                        'url' => $url,
                    ];

                    //render view to string
                    $emailContent = View::make('emails.salaryverifyMail', ['details' => $details, 'job' => $job])->render();

                    Mail::to($value['email'])->send(new SalaryverifyMail($details, $job));
                    $SenderEmail = APP_EMAIL;
                    EmailLog::create([
                        'recipient' =>$value['email'],
                        'subject' => $details['title'],
                        'body' =>  $emailContent,
                        'candidate_id' => $id,
                        'Sender'=> $SenderEmail
                    ]);

                    Log::info('Verification email sent', ['email' => $value['email'], 'complayer_id' => $complayer->id]);
                }
            }
        }

        $salaryCreation->status = '0';
        $salaryCreation->save();

        $job->status_id = 10;

        // Update candidate status_id
        Candidate::where('id', $id)->update(['status_id' => 18]);

        // Candidate history
        candidate_history::create([
            'remarks' => 'Salary Negotiation',
            'status_id' => 18,
            'candidate_id' => $id,
            'isactive' => 1,
        ]);

        $job->save();

        \DB::commit();
        return $this->successJson('Salary Created Successfully', 200, $salaryCreation);
    } catch (\Exception $e) {
        \DB::rollBack();
        return $this->errorJson('Something went wrong', 403, $e->getMessage());
    }
}



    function Salaryget($id){
 
        try{
            $jobapplicationId = JobApplication::where('CandidateId', $id)->pluck('id')->first();

          $jobApplications = Salarycreation::with('jobapplication','complayer')->where('job_application_id',$jobapplicationId)->get();          
            if(!empty($jobApplications)){
                return $this->successJson('Job Applications Details',200,$jobApplications);
            }else{
                return $this->successJson('not found Details',404);
            }
        } catch (\Exception $e) {
            return $this->errorJson('Something went wrong', 500, $e->getMessage());
        }
     }

   function Salarygeturl(Request $request,$id){
     try{
        //echo "utsav".$id;
          $id = Crypt::decryptString($id);  
 
         // echo "decrypt".$id;
            $jobApplications = Complayer::with(['salarycreation','jobapplication'])->where('id',$id)->get();
              //echo  $jobApplications ;
                if(!empty($jobApplications)){
                    return $this->successJson('Job Applications Details',200,$jobApplications);
                }else{
                    return $this->successJson('not found Details',404);
                }
        } 
            catch (\Exception $e) 
            {
                return $this->errorJson('Something went wrong', 500, $e->getMessage());
            }
    }

function SalaryUpdate(Request $request,$id){
    try{
        $requipment=Salarycreation::find($id);
        if($requipment){
            try {
                \DB::beginTransaction();
                 $requipment->job_application_id  = $requipment->job_application_id;
                $requipment->employeeCode = $request->employeeCode;
                $requipment->location = $request->location;
                $requipment->salaryType = $request->salaryType;
                $requipment->name = $request->name;
                $requipment->state = $request->state;
                $requipment->designation=$request->designation;
                $requipment->effectiveDate = $request->effectiveDate;
                $requipment->dateOfJoining = $request->dateOfJoining;
                $requipment->ctc = $request->ctc;
                $requipment->basicMonthly = $request->basicMonthly;
                $requipment->basicAnnual=$request->basicAnnual;
                $requipment->hrmMonthly = $request->hrmMonthly;
                $requipment->hrmAnnual = $request->hrmAnnual;
                $requipment->specialMonthly = $request->specialMonthly;
                $requipment->spciealAnnual=$request->spciealAnnual;
                $requipment->pfMonthly = $request->pfMonthly;
                $requipment->pTaxMonthly = $request->pTaxMonthly;
                $requipment->totalDeductionAnnually = $request->totalDeductionAnnually;
                $requipment->pfEMonthly=$request->pfEMonthly;
                $requipment->pfEAnnually = $request->pfEAnnually;
        
                $requipment->pfAAnnually = $request->pfAAnnually;
                $requipment->eStateInsuranceMonthly = $request->eStateInsuranceMonthly;
                $requipment->eStateInsuranceAnnually=$request->eStateInsuranceAnnually;
                $requipment->gratuityMonthly = $request->gratuityMonthly;
                $requipment->gratuityAnnually = $request->gratuityAnnually;
                $requipment->ltaMonthly = $request->ltaMonthly;
                $requipment->ltaAnnually=$request->ltaAnnually;
                $requipment->insuranceMonthly = $request->insuranceMonthly;
        
                $requipment->insuranceAnnually = $request->insuranceAnnually;
                $requipment->fixedCtcMonthly = $request->fixedCtcMonthly;
                $requipment->fixedCtcAnnually=$request->fixedCtcAnnually;
                $requipment->totalCTC = $request->totalCTC;
                $requipment->netTakeHome = $request->netTakeHome;
                $requipment->grossAmount = $request->grossAmount;
                 $requipment->pTaxAnnually =$request->pTaxAnnually;
                $requipment->totalDeductionMonthly =$request->totalDeductionMonthly;
                $requipment->pfAMonthly =$request->pfAMonthly; 
                $requipment->retension=$request->retension;
                $requipment->retensionBonus=$request->retensionBonus;
                $requipment->save();
                
                $requipment->status ='1'; 
                
                $requipment->save();
                Log::info('Salary record updated and saved', ['salary_id' => $id]);
                //salary update 
                // if (!is_null($request->complayers)) {
                //     foreach ($request->complayers as $key => $value) {
                //         if ($value['email']) {     
                //             $complayer = new Complayer();
                //             $complayer->email = $value['email'];
                //             $complayer->name=$request->name;
                //             $complayer->position=$request->designation;
                //         //     $complayer->name = $value['name']; 
                      
                //         //    $complayer->position = $value['designation']; 
                //             $complayer->job_application_id = $jobApplication->id;
                //             $complayer->salarycreation_id = $salaryCreation->id;
                //             $complayer->save();
                //             $url = config('app.AppBaseURL') . 'salaryverification/' . Crypt::encryptString($complayer->id);
                //             $details = [
                //                 'title' => 'Salary Re verification link',
                //                 'url' => $url,
                //             ];
                //             Mail::to($value['email'])->send(new SalaryverifyMail($details, $job));
                //             Log::info('Re- Verification email sent', ['email' => $value['email'], 'complayer_id' => $complayer->id]);
                //         }
                //     }



                // // }
        

                $job=JobApplication::findOrFail($requipment->job_application_id);
                if($request->status_id == 25){
                 $job->status_id=$request->status_id;
                 $job->cancel_reason=$request->cancel_reason;
                 // Update candidate status_id
                 Candidate::where('Id',  $job->CandidateId)->update(['status_id' => 22]);

                 //  // Candidate history
                  candidate_history::create([
                      'remarks' => 'Salary Disapprove',
                      'status_id' => 22,
                      'candidate_id' => $job->CandidateId,
                      'isactive' => 1,
                  ]);
		}else{
                 $job->status_id=15;
                  //$job->cancel_reason=$request->cancel_reason;
                   // Update candidate status_id
                      Candidate::where('Id',  $job->CandidateId)->update(['status_id' => 21]);

                    //  // Candidate history
                     candidate_history::create([
                         'remarks' => 'Salary Approved',
                         'status_id' => 21,
                         'candidate_id' => $job->CandidateId,
                         'isactive' => 1,
                     ]);
		}
        
       
                    
               
                $job->save();
                 \DB::commit();
                 Log::info('Job application status updated', ['job_application_id' => $requipment->job_application_id]);
                    return $this->successJson('Updated Successful',200,$requipment);
                }
                 catch (\Exception $e) {
                 \DB::rollBack();
                 return $this->errorJson('something else wrong',403,$e->getMessage());
                }

        }else{
            return $this->errorJson('page not found',404);
        }
    } catch (\Exception $e) {
        return $this->errorJson('Something went wrong', 500, $e->getMessage());
    }
       
    }

    // public function updatejobStatus(Request $request,$id)
    // {
    //     try{
    //     $jobdetails = Job::find($id);

    //     $jobdetails->status=$request->status;
    //     $jobdetails->save();
    //     return $this->successJson('Update Successful',200,$jobdetails);
    // } catch (\Exception $e)
    //  {
    //     return $this->errorJson('Something went wrong', 500, $e->getMessage());
    // }
    // }


 public function leaddatasearchold(Request $request){
        try{
        
            $jobApplications=Jobrecruitment::with(['job','category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned','jobapplication']);
            if ($request->pid != '' || $request->pid !=null) {
            $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
            {
                    $query->Where('pid', $request->pid);
            }); 
            }
            if ($request->recruitment_type != '' || $request->recruitment_type !=null) {
            $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
            {
                    $query->Where('recruitment_type', $request->recruitment_type);
            }); 
            }
            if ($request->billable_type != '' || $request->billable_type !=null) {
            $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
            {
                    $query->Where('billable_type', $request->billable_type);
            }); 
            }
          if ($request->qualification_id!= '' || $request->qualification_id !=null) {
            $jobApplications = $jobApplications->whereHas('qualification', function ($query) use ($request)
            {
                    $query->Where('qualification_id', $request->qualification_id);
            }); 
            }

            if ($request->project_name != '' || $request->project_name !=null) {
            $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
            {
                    $query->Where('project_name', $request->project_name);
            }); 
            }
            if ($request->location != '' || $request->location !=null) {
                $jobApplications = $jobApplications->Where('location', $request->location);
            }

            if ($request->department_id != '' || $request->department_id !=null) {
                $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                {
                        $query->Where('department_id', $request->department_id);
                }); 
            }
            if ($request->category_id != '' || $request->category_id !=null) {


                $jobApplications = $jobApplications->Where('category_id', $request->category_id);
            }

            

            if ((!is_null($request->min_budgeted) && !is_null($request->max_budgeted))) {
                // fetch all between min & max values
                $jobApplications = $jobApplications->whereBetween('position_budgeted',[$request->min_budgeted, $request->max_budgeted]);
            }
            // if just min_value is available (is not null)
            elseif (! is_null($request->min_budgeted)) {
                // fetch all greater than or equal to min_value
                $jobApplications = $jobApplications->where('position_budgeted', '>=', $request->min_budgeted);
            }
            // if just max_value is available (is not null)
            elseif (! is_null($request->max_budgeted)) {
                // fetch all lesser than or equal to max_value
                $jobApplications = $jobApplications->where('position_budgeted', '<=', $request->max_budgeted);
            } 
           elseif($request->project_manager != '' || $request->project_manager !=null) {
                   $jobApplications = $jobApplications->where('project_manager', 'like', '%' .$request->project_manager. '%');

            }
            
            if ($request->start_date != '' || $request->start_date !=null) {
                $jobApplications = $jobApplications->whereDate('start_date','>=',$request->start_date);
            }

            if ($request->end_date != '' || $request->end_date !=null) {
                 $jobApplications = $jobApplications->whereDate('end_date','<=',$request->end_date);

                
            }
            if ($request->user_id != '' || $request->user_id !=null) {
                $jobApplications = $jobApplications->whereHas('assigned', function ($query) use ($request)
                {
                         $query->where('user_id', '<=', $request->user_id);
                      

                }); 
            }
            if (! is_null($request->status)) {
                // fetch all lesser than or equal to max_value
                $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                {
                         $query->where('erfstatus',  $request->status);
                      

                }); 
                 
            }

           // $date = Carbon::parse($request->start_date)->format('Y-m-d H:i:s');
            $jobApplications=$jobApplications->get();
            
          return $this->successJson('ERF Form list Successfully',200,$jobApplications);
        } catch (\Exception $e) {
            return $this->errorJson('Something went wrong', 500, $e->getMessage());
        }
        }



    public function leaddatasearch(Request $request)
    {
            try{
                $jobApplications=Jobrecruitment::with(['job','category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned','jobapplication']);
                if ($request->pid != '' || $request->pid !=null) {
                $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                {
                        $query->Where('pid', $request->pid);
                }); 
                }
                if ($request->recruitment_type != '' || $request->recruitment_type !=null) {
                $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                {
                        $query->Where('recruitment_type', $request->recruitment_type);
                }); 
                }
                if ($request->billable_type != '' || $request->billable_type !=null) {
                $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                {
                        $query->Where('billable_type', $request->billable_type);
                }); 
                }
            if ($request->qualification_id!= '' || $request->qualification_id !=null) {
                $jobApplications = $jobApplications->whereHas('qualification', function ($query) use ($request)
                {
                        $query->Where('qualification_id', $request->qualification_id);
                }); 
                }

                if ($request->project_name != '' || $request->project_name !=null) {
                $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                {
                        $query->Where('project_name', 'like', '%' .$request->project_name. '%');
                }); 
                }
                if ($request->location != '' || $request->location !=null) {
                    $jobApplications = $jobApplications->Where('location', $request->location);
                }

                if ($request->department_id != '' || $request->department_id !=null) {
                    $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                    {
                            $query->Where('department_id', $request->department_id);
                    }); 
                }
                if ($request->category_id != '' || $request->category_id !=null) {


                    $jobApplications = $jobApplications->Where('category_id', $request->category_id);
                }

                

            if ($request->max_budgeted !='' || $request->max_budgeted !=null) {
                    
                    $jobApplications = $jobApplications->where('position_budgeted', '<=', $request->max_budgeted);
                }
            elseif($request->project_manager != '' || $request->project_manager !=null) {
                    $jobApplications = $jobApplications->where('project_manager', 'like', '%' .$request->project_manager. '%');
                }
                
                if ($request->start_date != '' || $request->start_date !=null) {
            $jobApplications = $jobApplications->whereDate('start_date','>=',$request->start_date);
                    }

                if ($request->end_date != '' || $request->end_date !=null) {
                $jobApplications = $jobApplications->whereDate('end_date','<=',$request->end_date);

                }
                if ($request->user_id != '' || $request->user_id !=null) {
                    $jobApplications = $jobApplications->whereHas('assigned', function ($query) use ($request)
                    {
                            $query->where('user_id', '<=', $request->user_id);
                        

                    }); 
                }
                if (! is_null($request->status)) {
                    // fetch all lesser than or equal to max_value
                    $jobApplications = $jobApplications->whereHas('job', function ($query) use ($request)
                    {
                            $query->where('erfstatus',  $request->status);
                        

                    }); 
                    
                }

            // $date = Carbon::parse($request->start_date)->format('Y-m-d H:i:s');
                $jobApplications=$jobApplications->get();
                
            return $this->successJson('ERF Form list Successfully',200,$jobApplications);
            } catch (\Exception $e) {
             
                return $this->errorJson('Something went wrong', 500, $e->getMessage());
            }


    }

     public function updateMrfStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'MrfStatus' => 'required|integer|in:1,2,3,4',
            ]);

            // Find the job recruitment record by ID
            $jobrecruitment = Jobrecruitment::find($id);

            if (!$jobrecruitment) {
                return $this->errorJson('MRF record not found', 400);
            }

            // Update the MrfStatus
            $jobrecruitment->MrfStatus = $request->MrfStatus;
            $jobrecruitment->save();

           
            return $this->successJson('MrfStatus updated successfully',200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            
            return $this->errorJson('Validation error', 422, $e->getMessage());
            
        } catch (\Exception $e) {
            // Log the exception
            Log::error('Failed to update MrfStatus', ['error' => $e->getMessage()]);

            return $this->errorJson('Something went wrong', 500, $e->getMessage());
        }
    }

    public function updateJobStatus(Request $request, $id)
    {
        try {
            // Validate the request
            $request->validate([
                'JobStatus' => 'required|integer|in:1,2,3,4',
            ]);

            // Find the job recruitment record by ID
            $JobStatus = Job::find($id);

            if (!$JobStatus) {
                return $this->errorJson('Project record not found', 400);
            }

            // Update the MrfStatus
            $JobStatus->JobStatus = $request->JobStatus;
            $JobStatus->save();

           
            return $this->successJson('JobStatus updated successfully',200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            
            return $this->errorJson('Validation error', 422, $e->getMessage());
            
        } catch (\Exception $e) {
            // Log the exception
            Log::error('Failed to update MrfStatus', ['error' => $e->getMessage()]);

            return $this->errorJson('Something went wrong', 500, $e->getMessage());
        }
    }

    public function getJobsByProjectLead($id = null)
    {
        try {
            if ($id) {
                // Fetch jobs where project_lead matches the given ID
                $jobs = Job::select('id', 'project_name', 'pid')
                ->where('project_lead', $id)
                ->get();
            } else {
                // Fetch all jobs if no ID is provided
                $jobs = Job::select('id', 'project_name', 'pid')
                    ->get();
            }
             
            return $this->successJson('JobStatus updated successfully',200,$jobs);
           
        } catch (\Exception $e) {
            return $this->errorJson('Something went wrong', 500, $e->getMessage());
        }
    }  
    
    public function getJobRecruitments($jobId)
{
    try {
        // Initialize the query
        $query = Jobrecruitment::query();

        // // If projectLeadId is provided, join with the jobs table to filter by project lead
        // if ($projectLeadId !== null) {
        //     $query->whereHas('job', function($q) use ($projectLeadId) {
        //         $q->where('project_lead', $projectLeadId);
        //     });
        // }

        // Filter by job_id
        $query->where('job_id', $jobId);

        // Fetch the required data
        $jobRecruitments = $query->select('id', 'M_id')
                                  ->get();

        // Return the response
        if ($jobRecruitments->isEmpty()) {
            return response()->json(['message' => 'No job recruitments found'], 404);
        }

        return response()->json(['jobRecruitments' => $jobRecruitments], 200);

    } catch (\Exception $e) {
        return response()->json(['message' => 'Failed to fetch job recruitments', 'error' => $e->getMessage()], 500);
    }
}

public function getUsersWithMRFPermissions()
{
    

   
    $users = User::with('role.role.permissions')->get();

    $requiredPermissions = [79, 80]; 
    $MRFPermission = [];


    foreach ($users as $user) {
        // Check if the user's role has any of the required permissions
        $hasPermission = collect($user['role']['role']['permissions'])
            ->whereIn('permission_id', $requiredPermissions)
            ->isNotEmpty(); 

        // If the user has the required permission, add their ID or name to the result
        if ($hasPermission) {
            $MRFPermission[] = [
                'id' => $user['id'],
                'name' => $user['name']
            ];
        }
    }

// Return users who have any of the required permissions
        return response()->json([
            'MRFPermission' => $MRFPermission
        ]);
    
}
       
    
   
            


}
  