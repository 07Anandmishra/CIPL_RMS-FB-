<?php

namespace App\Http\Controllers\Api;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Feedback;
use Illuminate\Support\Facades\Validator;
use App\InterviewSchedule;
use App\JobApplication;
use App\candidate_status;
use App\candidate_history;
use App\Candidate;


class FeedbackController extends Controller
{
   
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,  
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    } 

    // public function store(Request $request)
    // {
    //     try {
    //         // Check if the user has permission to add a schedule
    //         if (!auth()->user()->cans('add_schedule')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }

    //         // Validate the request data
    //         $validator = Validator::make($request->all(), [
    //             'job_application_id' => 'required|exists:job_applications,id',
    //             'interview_schedule_id' => 'required|exists:interview_schedules,id',
    //             'remark' => 'nullable|string',
    //             'status' => 'nullable|string',
    //         ]);

    // if ($validator->fails()) {
    //     return response()->json(['error' => $validator->errors()], 422);
    // }

    // $feedback = Feedback::where('job_application_id', $request->job_application_id)
    //                     ->where('interview_schedule_id', $request->interview_schedule_id)
    //                     ->first();

    //         if ($feedback) {
    //             // Update existing feedback
    //             $feedback->update([
    //                 'remark' => $request->remark,
    //                 'status' => $request->status,
    //             ]);

    //             // Find the interview schedule
    //             $interviewSchedule = InterviewSchedule::find($request->interview_schedule_id);
    //             if (!$interviewSchedule) {
    //                 return $this->errorJson('Interview schedule not found', 404);
    //             }

    //             // Update interview schedule status
    //             $interviewSchedule->status = $request->status;
    //             $interviewSchedule->save();
    //              // Find the job application
    //              $jobApplication = JobApplication::findOrFail($request->job_application_id);
    //               // Find the status from candidate_status table
    //                $candidateStatus = candidate_status::where('name', $request->status)->first();

    //                  // Create a new entry in candidate_history table
    //         $candidateHistory = candidate_history::create([
    //         'candidate_id' => $jobApplication->CandidateId,
    //         'status_id' => $candidateStatus->id,
    //         'remark' => $request->remark,
    //     ]);

    //             return $this->successJson('Feedback updated successfully', 200, $feedback);
    //         } else {
    //             // Return error if no existing feedback found
    //             return $this->errorJson('Feedback not found for the given candidate and interview schedule.', 404);
    //         }

    //     } catch (\Exception $e) {
    //         // Handle any exceptions that occur
    //         return $this->errorJson('An error occurred while processing the feedback: ' . $e->getMessage(), 500);
    //     }
    // }


    public function store(Request $request)
    {
        //echo $request;
        try {
            Log::info('Store method called. for giving interview feedback.......');
    
            // Check if the user has permission to add a schedule
            if (!auth()->user()->cans('add_schedule')) {
                Log::warning('User does not have permission to add a schedule.', ['user_id' => auth()->user()->id]);
                return $this->errorJson('Not authenticated to perform this request', 403);
            }
            Log::info('User is authenticated to add a schedule.', ['user_id' => auth()->user()->id]);
    
            // Validate the request data
            $validator = Validator::make($request->all(), [
                'job_application_id' => 'required|exists:job_applications,id',
                'interview_schedule_id' => 'required|exists:interview_schedules,id',
                'remark' => 'nullable|string',
                'status' => 'nullable|string',
            ]);

    if ($validator->fails()) {
        return response()->json(['error' => $validator->errors()], 422);
    }

    $feedback = Feedback::where('job_application_id', $request->job_application_id)
                        ->where('interview_schedule_id', $request->interview_schedule_id)
                        ->first();
                       // echo $feedback;

            if ($feedback) {
                Log::info('Existing feedback found.', ['feedback_id' => $feedback->id]);
    
                // Update existing feedback
                $feedback->update([
                    'remark' => $request->remark,
                    'status' => $request->status,
                ]);
                Log::info('Feedback updated.', ['feedback_id' => $feedback->id]);
    
                // Find the interview schedule
                $interviewSchedule = InterviewSchedule::find($request->interview_schedule_id);
                if (!$interviewSchedule) {
                    Log::error('Interview schedule not found.', ['interview_schedule_id' => $request->interview_schedule_id]);
                    return $this->errorJson('Interview schedule not found', 404);
                }
                Log::info('Interview schedule found.', ['interview_schedule_id' => $interviewSchedule->id]);
    
                // Update interview schedule status
                $interviewSchedule->status = $request->status;
                $interviewSchedule->save();
                 // Find the job application
                 $jobApplication = JobApplication::findOrFail($request->job_application_id);
                 // Get the CandidateId from the job application
                 $candidateId = $jobApplication->CandidateId;

                    // Find the candidate in the candidate table using the CandidateId
                    $candidate = Candidate::findOrFail($candidateId);

                    // Find the status from candidate_status table
                   $candidateStatus = candidate_status::where('name', $request->status)->first();

                     // Create a new entry in candidate_history table
                    $candidateHistory = candidate_history::create([
                    'candidate_id' => $jobApplication->CandidateId,
                    'status_id' => $candidateStatus->id,
                    'remarks' => $request->remark,
                    'isactive'=>1
                ]);
               // $candidate->status_id = 1; // or use $request->input('status_id') for dynamic values
                $candidate->status_id = $candidateStatus->id; // or use $request->input('status_id') for dynamic values
                $candidate->save();
            
                return $this->successJson('Feedback updated successfully', 200, $feedback);
            } else {
                Log::warning('Feedback not found for the given candidate and interview schedule.', ['job_application_id' => $request->job_application_id, 'interview_schedule_id' => $request->interview_schedule_id]);
                return $this->errorJson('Feedback not found for the given candidate and interview schedule.', 404);
            }
    
        } catch (\Exception $e) {
            Log::error('An error occurred while processing the feedback.', ['exception' => $e->getMessage()]);
            return $this->errorJson('An error occurred while processing the feedback: ' . $e->getMessage(), 500);
        }
    }

//     public function getApplicationsWithFeedback($MRFId)
// {
//     try {
//         // Perform the query
//         $applications = JobApplication::leftJoin('feedback', 'job_applications.id', '=', 'feedback.job_application_id')
//             ->where('job_applications.MRFId', $MRFId)
//             ->select(
//                 'job_applications.full_name as JobApplicationName',
//                 'feedback.status as FeedbackStatus',
//                 'feedback.remark as FeedbackRemarks'
//             )
//             ->get();
//             $filteredApplications = $applications->map(function($application) {
//                 return [
//                     'JobApplicationName' => $application->JobApplicationName,
//                     'FeedbackStatus' => $application->FeedbackStatus,
//                     'FeedbackRemarks' => $application->FeedbackRemarks,
//                 ];
//             });
//         // Check if the query returned any results
//         if ($applications->isEmpty()) {
//             return response()->json(['message' => 'No applications found for the given MRFId'], 404);
//         }

//         // Return the results
//         return $this->successJson('Feedback get successfully', 200, $filteredApplications);

//     } catch (\Exception $e) {
//         // Handle any errors that may occur
//         return $this->errorJson('An error occurred while processing the feedback: ' . $e->getMessage(), 500);
//     }
// }

public function getApplicationsWithFeedback($MRFId)
{
    try {
        Log::info('Started processing getApplicationsWithFeedback', ['MRFId' => $MRFId]);

        // Perform the query with a left join
        $applications = JobApplication::leftJoin('feedback', 'job_applications.id', '=', 'feedback.job_application_id')
            ->where('job_applications.MRFId', $MRFId)
            ->select(
                'job_applications.id as JobApplicationId',
                'job_applications.Name as JobApplicationName',
                'feedback.job_application_id',
                'feedback.interview_schedule_id',
                'feedback.status as FeedbackStatus',
                'feedback.remark as FeedbackRemarks'
            )
            ->orderBy('job_applications.id')
            ->get();

        Log::info('Fetched applications with feedback', ['applications_count' => $applications->count()]);

        // Group feedbacks by Job Application ID
        $groupedApplications = $applications->groupBy('JobApplicationId');

        Log::info('Grouped applications by JobApplicationId', ['grouped_count' => $groupedApplications->count()]);

        // Format the response
        $filteredApplications = $groupedApplications->map(function ($feedbacks, $applicationId) {
            Log::info('Processing application', ['applicationId' => $applicationId, 'feedback_count' => $feedbacks->count()]);

            return [
                'JobApplicationId' => $applicationId,
                'JobApplicationName' => $feedbacks->first()->JobApplicationName,
                'Feedback' => $feedbacks->map(function ($feedback) {
                   
                    Log::info('Processing feedback', [
                        'FeedbackStatus' => $feedback->FeedbackStatus,
                        'FeedbackRemarks' => $feedback->FeedbackRemarks,
                        'job_application_id' => $feedback->job_application_id,
                        'interview_schedule_id' => $feedback->interview_schedule_id
                    ]);

                    return [
                        // 'job_application_id' => $feedback->job_application_id,
                        'interview_schedule_id' => $feedback->interview_schedule_id,
                        'FeedbackStatus' => $feedback->FeedbackStatus,
                        'FeedbackRemarks' => $feedback->FeedbackRemarks,
                    ];
                })
            ];
        });

        // Check if the query returned any results
        if ($filteredApplications->isEmpty()) {
            Log::info('No applications found for the given MRFId', ['MRFId' => $MRFId]);
            return response()->json(['message' => 'No applications found for the given MRFId'], 404);
        }

        // Return the results
        Log::info('Feedback retrieved successfully', ['filtered_applications_count' => $filteredApplications->count()]);
        return $this->successJson('Feedback retrieved successfully', 200, $filteredApplications->values());

    } catch (\Exception $e) {
        // Handle any errors that may occur
        Log::error('An error occurred while processing the feedback', ['MRFId' => $MRFId, 'error' => $e->getMessage()]);
        return $this->errorJson('An error occurred while processing the feedback: ' . $e->getMessage(), 500);
    }
}

public function FeedbackbyCandidate($id)
{
    try {
       

        // Perform the query with a left join
        $applications = JobApplication::leftJoin('feedback', 'job_applications.id', '=', 'feedback.job_application_id')
            ->where('job_applications.CandidateId', $id)
            ->select(
                'job_applications.id as JobApplicationId',
                'job_applications.Name as JobApplicationName',
                'feedback.status as FeedbackStatus',
                'feedback.remark as FeedbackRemarks'
            )
            ->orderBy('job_applications.id')
            ->get();

        Log::info('Fetched applications with feedback', ['applications_count' => $applications->count()]);

        // Group feedbacks by Job Application ID
        $groupedApplications = $applications->groupBy('JobApplicationId');

        Log::info('Grouped applications by JobApplicationId', ['grouped_count' => $groupedApplications->count()]);

        // Format the response
        $filteredApplications = $groupedApplications->map(function ($feedbacks, $applicationId) {
            Log::info('Processing application', ['applicationId' => $applicationId, 'feedback_count' => $feedbacks->count()]);

            return [
                'JobApplicationName' => $feedbacks->first()->JobApplicationName,
                'Feedback' => $feedbacks->map(function ($feedback) {
                    Log::info('Processing feedback', ['FeedbackStatus' => $feedback->FeedbackStatus, 'FeedbackRemarks' => $feedback->FeedbackRemarks]);

                    return [
                        'FeedbackStatus' => $feedback->FeedbackStatus,
                        'FeedbackRemarks' => $feedback->FeedbackRemarks,
                    ];
                })
            ];
        });

        // Check if the query returned any results
        if ($filteredApplications->isEmpty()) {
          
            return response()->json(['message' => 'No applications found for the given CandidateId'], 404);
        }

        // Return the results
        Log::info('Feedback retrieved successfully', ['filtered_applications_count' => $filteredApplications->count()]);
        return $this->successJson('Feedback retrieved successfully', 200, $filteredApplications->values());

    } catch (\Exception $e) {
        // Handle any errors that may occur
       
        return $this->errorJson('An error occurred while processing the feedback: ' . $e->getMessage(), 500);
    }
}


    //assign candidate for document verification

    public function assign(Request $request)
    {
        try {
            // Ensure that interview_schedule_id is an array if multiple IDs are passed
            $interviewScheduleIds = is_array($request->interview_schedule_id) ? $request->interview_schedule_id : [$request->interview_schedule_id];
               // Query for multiple interview_schedule_id values using whereIn
            $candidateData = Feedback::where('job_application_id', $request->job_application_id)
<<<<<<< HEAD
            ->whereIn('interview_schedule_id', $interviewScheduleIds) // Use whereIn for multiple IDs
            ->get();
=======
                ->where('interview_schedule_id', $request->interview_schedule_id)
                ->get();
    
>>>>>>> 6152f6fe385187a1f0b9df339d534933330b3313
            if (!$candidateData) {
                return $this->errorJson('Candidate data not found', 404);
            }
    
            // Check if assignBy and assignTo have already been set
            if ($candidateData->assignBy == $request->assignBy && $candidateData->assignTo == $request->assignTo) {
                return $this->errorJson('No changes were made. AssignBy and AssignTo are already set to these values.', 200);
            }
    
            // Log the current data before updating
            Log::info('Before update', [ 
                'assignBy' => $candidateData->assignBy,
                'assignTo' => $candidateData->assignTo,
            ]);
    
            // Update the assignBy and assignTo fields
            $candidateData->update([
                'assignBy' => $request->assignBy,
                'assignTo' => $request->assignTo,
            ]);
    
            // Log the updated data
            Log::info('After update', [
                'assignBy' => $candidateData->assignBy,
                'assignTo' => $candidateData->assignTo,
            ]);
    
            return $this->successJson('Assignment updated successfully', 200, $candidateData);
    
        } catch (\Exception $e) {
            // Handle any errors that may occur
            Log::error('An error occurred while processing the assignment', ['error' => $e->getMessage()]);
            return $this->errorJson('An error occurred while processing the feedback: ' . $e->getMessage(), 500);
        }
    }
    

}
