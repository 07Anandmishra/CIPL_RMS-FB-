<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\HeadOfDepartment;
use Illuminate\Support\Facades\Log;

class HeadOfDepartmentController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    // public function index()    
    // {
    //     try {
    //         $heads = HeadOfDepartment::all();
            
    //         if($heads->isEmpty())
    //         {
    //             return $this->errorJson('No Hod Found', 404);
    //         }
            
    //         return $this->successJson('hod  Details', 200, $heads);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Failed to fetch hod', 500, $e->getMessage());
    //     }
    // }

    public function index()
{
    try {
        Log::info('Fetching all heads of department.');

        $heads = HeadOfDepartment::all();

        if ($heads->isEmpty()) {
            Log::warning('No heads of department found.');
            return $this->errorJson('No Hod Found', 404);
        }

        Log::info('Heads of department fetched successfully.', ['count' => $heads->count()]);
        return $this->successJson('HOD Details', 200, $heads);
    } catch (\Exception $e) {
        Log::error('Failed to fetch heads of department.', ['exception' => $e->getMessage()]);
        return $this->errorJson('Failed to fetch HOD', 500, $e->getMessage());
    }
}
    
    // public function store(Request $request)
    // {
    //     try {
    //         $request->validate([
    //             'Name' => 'required|string|max:255',
    //             'Email' => 'required|email|max:255',
    //             'MobileNo' => 'required|string|max:20',
    //             'DepartmentId' => 'required|exists:departments,id',
    //         ]);
            

    //         $head = HeadOfDepartment::create($request->all());

    //         return $this->successJson('HOD Created Successfully', 201, $head);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Failed to create HOD', 500, $e->getMessage());
    //     }
    // }

    public function store(Request $request)
{
    try {
        Log::info('Validating request data for creating a new HOD.');

        $validatedData = $request->validate([
            'Name' => 'required|string|max:255',
            'Email' => 'required|email|max:255',
            'MobileNo' => 'required|string|max:20',
            'DepartmentId' => 'required|exists:departments,id',
        ]);

        Log::info('Request data validated successfully.', ['validatedData' => $validatedData]);

        $head = HeadOfDepartment::create($validatedData);

        Log::info('HOD created successfully.', ['head' => $head]);

        return $this->successJson('HOD Created Successfully', 201, $head);
    } catch (\Exception $e) {
        Log::error('Failed to create HOD.', ['exception' => $e->getMessage()]);
        return $this->errorJson('Failed to create HOD', 500, $e->getMessage());
    }
}

    // public function show($id)
    // {
    //     try {
    //         $head = HeadOfDepartment::find($id);

    //         if (!$head) {
    //             return $this->errorJson('HOD Not Found', 404, null);
    //         }

    //         return $this->successJson('HOD Retrieved Successfully', 200, $head);
    //     }catch (\Exception $e) {
    //         return $this->errorJson('Failed to retrieve HOD', 500, $e->getMessage());
    //     }
    // }
    
    public function show($id)
{
    try {
        Log::info('Attempting to retrieve HOD.', ['hod_id' => $id]);

        $head = HeadOfDepartment::find($id);

        if (!$head) {
            Log::warning('HOD Not Found.', ['hod_id' => $id]);
            return $this->errorJson('HOD Not Found', 404, null);
        }

        Log::info('HOD Retrieved Successfully.', ['head' => $head]);

        return $this->successJson('HOD Retrieved Successfully', 200, $head);
    } catch (\Exception $e) {
        Log::error('Failed to retrieve HOD.', ['exception' => $e->getMessage(), 'hod_id' => $id]);
        return $this->errorJson('Failed to retrieve HOD', 500, $e->getMessage());
    }
}

   
    
    // public function update(Request $request, $id)
    // {
    //     try {
        
    //         $request->validate([
    //             'Name' => 'string|max:255',
    //             'Email' => 'email|max:255',
    //             'MobileNo' => 'string|max:20',
    //             'DepartmentId' => 'exists:departments,id',
    //         ]);
    //         $head = HeadOfDepartment::find($id);
    //         if (!$head) {
    //             return $this->errorJson('Hod not found', 404);
    //         }

    //         $head->update($request->all());

    //         return $this->successJson('Hod Updated Successfully', 200, $head);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Failed to update Hod', 500, $e->getMessage());
    //     }
    // }

    public function update(Request $request, $id)
{
    try {
        Log::info('User attempting to update HOD.', ['user_id' => auth()->id(), 'hod_id' => $id, 'request_data' => $request->all()]);

        $request->validate([
            'Name' => 'string|max:255',
            'Email' => 'email|max:255',
            'MobileNo' => 'string|max:20',
            'DepartmentId' => 'exists:departments,id',
        ]);

        $head = HeadOfDepartment::find($id);
        if (!$head) {
            Log::warning('HOD not found for update.', ['user_id' => auth()->id(), 'hod_id' => $id]);
            return $this->errorJson('HOD not found', 404);
        }

        $head->update($request->all());
        Log::info('HOD updated successfully.', ['user_id' => auth()->id(), 'hod_id' => $id, 'updated_data' => $head]);

        return $this->successJson('HOD Updated Successfully', 200, $head);
    } catch (\Exception $e) {
        Log::error('Failed to update HOD.', ['exception' => $e->getMessage(), 'user_id' => auth()->id(), 'hod_id' => $id, 'request_data' => $request->all()]);
        return $this->errorJson('Failed to update HOD', 500, $e->getMessage());
    }
}
    
     // Remove the specified resource from storage.
     
    // public function destroy($id)
    // {

    //     try {
    //         $head = HeadOfDepartment::find($id);

    //         if (!$head) {
    //             return $this->errorJson('HOD Not Found', 404, null);
    //         }

    //         $head->delete();

    //         return $this->successJson('HOD Deleted Successfully', 200, null);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Failed to delete HOD', 500, $e->getMessage());
    //     }


        
    // }

    public function destroy($id)
     {
    try {
        Log::info('User attempting to delete HOD.', ['user_id' => auth()->id(), 'hod_id' => $id]);

        $head = HeadOfDepartment::find($id);

        if (!$head) {
            Log::warning('HOD not found for deletion.', ['user_id' => auth()->id(), 'hod_id' => $id]);
            return $this->errorJson('HOD Not Found', 404, null);
        }

        $head->delete();
        Log::info('HOD deleted successfully.', ['user_id' => auth()->id(), 'hod_id' => $id]);

        return $this->successJson('HOD Deleted Successfully', 200, null);
    } catch (\Exception $e) {
        Log::error('Failed to delete HOD.', ['exception' => $e->getMessage(), 'user_id' => auth()->id(), 'hod_id' => $id]);
        return $this->errorJson('Failed to delete HOD', 500, $e->getMessage());
    }
}
}
