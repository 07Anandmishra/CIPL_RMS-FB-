<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Providers\SmsService;
use App\ApplicationStatus;
use App\Helper\Reply;
use App\EmailLog;
use Illuminate\Support\Facades\View; 
use App\Http\Requests\InterviewSchedule\StoreRequest;
use App\Http\Requests\InterviewSchedule\UpdateRequest;
use App\InterviewSchedule;
use App\InterviewScheduleEmployee;
use App\JobApplication;
use App\Candidate;
use App\Job;
use App\JobRecruitment;
use App\Notifications\CandidateNotify;
use App\Notifications\CandidateReminder;
use App\Notifications\CandidateScheduleInterview;
use App\Notifications\EmployeeResponse;
use App\Notifications\ScheduleInterview;
use App\Notifications\ScheduleInterviewStatus;
use App\Notifications\ScheduleStatusCandidate;
use App\Traits\ZoomSettings;
use MacsiDigital\Zoom\Facades\Zoom;
use App\ScheduleComments;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use App\Mail\CandidateScheduleInterviewMail;
use Mail;
use App\EmailSetting;
use App\SmtpSetting; 
use App\Notifications\MyFirstNotification;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;
use App\candidate_status;
use App\candidate_history;
use Illuminate\Support\Facades\Log;
use App\Mail\InterviewScheduled;
use App\Notifications\InterviewRatingNotification;
class InterviewScheduleController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    } 

    
    //     public function view(Request $request)
    // {
        
    //     if(!auth()->user()->cans('add_schedule')){
    //         return $this->errorJson('Not authenticated to perform this request',403);
    //     }else{
    //     $data['candidates'] = JobApplication::all();
    //     $data['users'] = User::all();
        
    //     return $this->successJson('Details',200,$data);
    //     }
    // }

    public function view(Request $request)
{
    try {
        Log::info('User attempting to view candidates and users.', ['user_id' => auth()->id()]);

        // Check if the user has the necessary permission
        if (!auth()->user()->cans('add_schedule')) {
            Log::warning('User not authenticated to perform this request.', ['user_id' => auth()->id()]);
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        // Fetch all candidates and users
        $data['candidates'] = JobApplication::all();
        $data['users'] = User::all();

        Log::info('Successfully retrieved candidates and users.', ['user_id' => auth()->id()]);
        return $this->successJson('Details', 200, $data);
    } catch (\Exception $e) {
        Log::error('Failed to retrieve candidates and users.', [
            'exception' => $e->getMessage(),
            'user_id' => auth()->id()
        ]);
        return $this->errorJson('Failed to retrieve details', 500, $e->getMessage());
    }
}

    // public function recruitment_type($recruitmentType)
    // {
    //     try {
           
    
    //         // Query the interview schedules based on the recruitment type
    //         $interviewSchedules = InterviewSchedule::select(
    //                 'interview_schedules.id',
    //                 'interview_schedules.schedule_date',
    //                 'interview_schedules.status',
    //                 'interview_schedules.interview_type',
    //                 'interview_schedules.user_accept_status',
    //                 'interview_schedules.meeting_id',
    //                 'job_applications.Name',
    //                 'jobs.erf_id',
    //                 'jobrecruitments.location',
    //                 'application_status.status'
    //             )
    //             ->join('job_applications', 'job_applications.id', '=', 'interview_schedules.job_application_id')
    //             ->leftJoin('jobs', 'jobs.id', '=', 'job_applications.job_id')
    //             ->leftJoin('application_status','job_applications.status_id','=','application_status.id')
    //             ->where('jobs.recruitment_type', $recruitmentType)
    //             ->leftJoin('jobrecruitments', 'jobrecruitments.id', '=', 'job_applications.jobrecruitment_id')
    //             ->get();
    
    //         return $this->successJson('Interview schedules retrieved successfully', 200, $interviewSchedules);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Error retrieving interview schedules', 500, $e->getMessage());
    //     }
    // }
//     public function recruitment_type($recruitmentType)
// {
//     try {
//         // Query the interview schedules based on the recruitment type
//         $interviewSchedules = InterviewSchedule::select(
//                 'interview_schedules.id',
//                 'interview_schedules.schedule_date',
//                 'interview_schedules.status',
//                 'interview_schedules.interview_type',
//                 'interview_schedules.user_accept_status',
//                 'interview_schedules.meeting_id',
//                 'job_applications.Name',
//                 'jobs.erf_id',
//                 'jobs.user_id',
//                 'jobrecruitments.location',
//                 'application_status.status'
//             )
//             ->join('job_applications', 'job_applications.id', '=    ', 'interview_schedules.job_application_id')
//             ->leftJoin('jobs', 'jobs.id', '=', 'job_applications.job_id')
//             ->leftJoin('application_status', 'job_applications.status_id', '=', 'application_status.id')
//             ->leftJoin('jobrecruitments', 'jobrecruitments.id', '=', 'job_applications.jobrecruitment_id')
//             ->where('jobs.recruitment_type', $recruitmentType)
//             // ->where(function ($query) {    
//             //     $query->where('application_status.status', 'interview round 1')
//             //           ->orWhere('application_status.status', 'interview round 2');
//             // })
//             ->get();

//         return $this->successJson('Interview schedules retrieved successfully', 200, $interviewSchedules);
//     } catch (\Exception $e) {
//         return $this->errorJson('Error retrieving interview schedules', 500, $e->getMessage());
//     }
// }

public function recruitment_type($recruitmentType)
{
    try {
        Log::info('Attempting to retrieve interview schedules.', ['recruitment_type' => $recruitmentType]);

        // Query the interview schedules based on the recruitment type
        $interviewSchedules = InterviewSchedule::select(
                'interview_schedules.id',
                'interview_schedules.schedule_date',
                'interview_schedules.status',
                'interview_schedules.interview_type',
                'interview_schedules.user_accept_status',
                'interview_schedules.meeting_id',
                'job_applications.Name',
                'jobs.erf_id',
                'jobs.user_id',
                'jobrecruitments.location',
                'application_status.status'
            )
            ->join('job_applications', 'job_applications.id', '=', 'interview_schedules.job_application_id')
            ->leftJoin('jobs', 'jobs.id', '=', 'job_applications.job_id')
            ->leftJoin('application_status', 'job_applications.status_id', '=', 'application_status.id')
            ->leftJoin('jobrecruitments', 'jobrecruitments.id', '=', 'job_applications.jobrecruitment_id')
            ->where('jobs.recruitment_type', $recruitmentType)
            // ->where(function ($query) {    
            //     $query->where('application_status.status', 'interview round 1')
            //           ->orWhere('application_status.status', 'interview round 2');
            // })
            ->get();

        Log::info('Interview schedules retrieved successfully.', ['recruitment_type' => $recruitmentType, 'count' => $interviewSchedules->count()]);
        return $this->successJson('Interview schedules retrieved successfully', 200, $interviewSchedules);
    } catch (\Exception $e) {
        Log::error('Error retrieving interview schedules.', [
            'recruitment_type' => $recruitmentType,
            'exception' => $e->getMessage()
        ]);
        return $this->errorJson('Error retrieving interview schedules', 500, $e->getMessage());
    }
}
    


    // public function store(Request $request)
    // {
    //     if(!auth()->user()->cans('add_schedule')){
    //         return $this->errorJson('Not authenticated to perform this request',403);
    //     }else
    //     {

    //      $validator = Validator::make($request->all(), [ 
    //               "candidates"    => "required",
    //             "employees.0"      => "required",
    //             "scheduleDate"    => "required",
    //             "scheduleTime"    => "required",            
    //         ]);
    //         if ($validator->fails()) { 
    //             return response()->json(['error'=>$validator->errors()], 422);            
    //         }
    //      try{
    //        \DB::beginTransaction();
    //     $dateTime =  $request->scheduleDate . ' ' . $request->scheduleTime;
    //     $dateTime = Carbon::createFromFormat('Y-m-d H:i', $dateTime);
        
    //         if($request->interview_type == 'online'){
    //         $data = $request->all();
    //          $data['meeting_name'] = $request->meeting_title;
    //         $data['start_date_time'] = $dateTime;
    //         $data['meetingurl']=$request->meetingurl;
    //        // $meetings = $meeting->create($data);
           
    //        $data['interview_type']=$request->status;
    //         $meetings = $data;
 
    //     } 
    //     else{
             
    //        $data['start_date_time'] = $dateTime; 
    //        $data['meetingurl']='null';
    //        $data['interview_type']=$request->status;
    //        // $meetings = $data;
    //       //  $meetings ->save();

    //     }  

    //     $jobapplicationId = JobApplication::where('CandidateId', $request-> candidates)->pluck('id')->first();
    //         // store Schedule
    //         $interviewSchedule = new InterviewSchedule();
    //         $interviewSchedule->job_application_id =$jobapplicationId;
    //         $interviewSchedule->schedule_date = $dateTime;
    //         $interviewSchedule->status = $request->status;
    //         //$interviewSchedule->meetingurl = $request->meetingurl;
    //         $interviewSchedule->meeting_title = $request->meeting_title;
    //        // $interviewSchedule->interview_type = ($request->has('interview_type')) ? $request->interview_type : 'offline';
    //          $interviewSchedule->interview_type = $request->interview_type;
    //          $interviewSchedule->user_accept_status='accept';
    //         $interviewSchedule->meeting_id = ($request->meeting_id!= '') ? $request->meeting_id: null;
    //         //$interviewSchedule->meetingurl = ($request->meetingurl!= '') ? $request->meetingurl: null;
            
           
    //         $interviewSchedule->save();

    //         // Update Schedule Status
    //         $jobApplication = $interviewSchedule->jobApplication;
    //         $candidateId = $jobApplication->CandidateId;

    //         // Find the candidate in the candidate table using the CandidateId
    //         $candidate = Candidate::findOrFail($candidateId);

    //         if($request->status=='interview round 1'){
    //             $interviewSchedule->status=$request->status;
    //             candidate_history::create([
    //                 'remarks' => 'interview round 1',
    //                 'status_id' =>3,
    //                 //'status_id' => $request->input('status_id'),// for dynamic
    //                 'candidate_id' => $jobApplication->CandidateId,
    //                 'isactive' => 1,
    //             ]);
    //             $candidate->status_id = 3; // or use $request->input('status_id') for dynamic values
    //             $candidate->save();
    //         $jobApplication->status_id = 3;
    //        }else if($request->status=='interview round 2'){
    //         $interviewSchedule->status=$request->status;
    //           $jobApplication->status_id = 4;
    //           candidate_history::create([
    //             'remarks' => 'interview round 2',
    //             'status_id' =>4,
    //             //'status_id' => $request->input('status_id'),// for dynamic
    //             'candidate_id' => $jobApplication->CandidateId,
    //             'isactive' => 1,
    //         ]);
    //         $candidate->status_id = 4; // or use $request->input('status_id') for dynamic values
    //             $candidate->save();
    //         }
        
    //         $jobApplication->save();

    //         if ($request->comment) {
    //             $scheduleComment = [
    //                 'interview_schedule_id' => $interviewSchedule->id,
    //                 'user_id' =>  auth()->user()->id,
    //                 'comment' => $request->comment
    //             ];

    //             $interviewSchedule->comments()->create($scheduleComment);
    //         }

            
    //         \DB::commit();

    //         $userId = $meetings['employees'][0]['user_id'];
    //         $user = User::find($userId);
    //         $interviewer=$user->name;
            
    //         $mode="Virtual";
    //         $meetingUrl = $meetings['meetingurl'];
    //         $IvStatus = $meetings['status'];
           
    //         $position= $candidate->JobTitle;

    //         if (!empty($request->employees)) {
    //              $interviewSchedule->employees()->attach($request->employees);
   
    //             // // // Mail to employee for informing interview schedule
    //             //  Notification::send($interviewSchedule->employees, new ScheduleInterview($jobApplication, $interviewSchedule, $meetings,$candidate));
              
    //             $emailContent = View::make('emails.interview_scheduled', [
    //                 'candidate' => $candidate,
    //                 'interviewer' => $interviewer,
    //                 'position' => $position,
    //                 'date' => $dateTime->format('Y-m-d'),
    //                 'time' => $dateTime->format('H:i'),
    //                 'mode' => $mode,
    //                 'meetingUrl' => $meetingUrl,
    //                 'IvStatus' => $IvStatus
                   
    //                  ])->render();
                   
    //              Mail::to($user->email)
    //              ->send(new InterviewScheduled($candidate, $interviewer, $position, $dateTime->format('Y-m-d'), $dateTime->format('H:i'), $mode,$meetingUrl,$IvStatus));

    //                 // Storing email details in the database
    //                 $SenderEmail = APP_EMAIL;
    //                 EmailLog::create([
    //                     'recipient' => $user->email,
    //                     'subject' => $IvStatus . " interviewer",
    //                     'body' => $emailContent,
    //                     'candidate_id' => $candidate->Id,
    //                     'Sender'=> $SenderEmail
    //                 ]);
    //         }
          
          
    //        $emailContent = View::make('emails.interview_scheduled', [
    //         'candidate' => $candidate,
    //         'interviewer' => $interviewer,
    //         'position' => $position,
    //         'date' => $dateTime->format('Y-m-d'),
    //         'time' => $dateTime->format('H:i'),
    //         'mode' => $mode,
    //         'meetingUrl' => $meetingUrl,
    //         'IvStatus' => $IvStatus
    //          ])->render();

           
    //        Mail::to($candidate->EmailId)
    //        ->cc($interviewSchedule->email)
    //        ->send(new InterviewScheduled($candidate, $interviewer, $position, $dateTime->format('Y-m-d'), $dateTime->format('H:i'), $mode,$meetingUrl,$IvStatus));


    //        // Storing email details in the database
    //        $SenderEmail = APP_EMAIL;
    //        EmailLog::create([
    //            'recipient' => $candidate->EmailId,
    //            'subject' => $IvStatus,
    //            'body' => $emailContent,
    //            'candidate_id' => $candidate->Id,
    //            'Sender'=> $SenderEmail
    //        ]);
    
    //         // Insert record into feedback table
    //         \DB::table('feedback')->insert([
    //             'job_application_id' => $jobApplication->id,
    //             'interview_schedule_id' => $interviewSchedule->id,
    //             'remark' => null,
    //             'status' => null,
    //             'created_at' => now(),
    //             'updated_at' => now(),
    //         ]);
    
    //         return $this->successJson('Interview Schedule Created Successfully', 200, $interviewSchedule);
    //     } catch (\Throwable $th) {
    //         \DB::rollBack();
    //         return $this->errorJson('Something went wrong', 403, $th->getMessage());
    //     }
    //     }
    // }
    
    public function store(Request $request)
    {
        if (!auth()->user()->cans('add_schedule')) {
            return $this->errorJson('Not authenticated to perform this request', 403);
        }
    
        $validator = Validator::make($request->all(), [
            "candidates"    => "required",
            "employees.0"   => "required",
            "scheduleDate"  => "required",
            "scheduleTime"  => "required",
        ]);
    
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
    
        try {
            \DB::beginTransaction();
    
            $dateTime = $request->scheduleDate . ' ' . $request->scheduleTime;
            $dateTime = Carbon::createFromFormat('Y-m-d H:i', $dateTime);
    
            $data = $request->all();
            $data['start_date_time'] = $dateTime;
            $data['interview_type'] = $request->status;
    
            if ($request->interview_type == 'online') {
                $data['meeting_name'] = $request->meeting_title;
                $data['meetingurl'] = $request->meetingurl;
            } else {
                $data['meetingurl'] = 'null';
            }
    
            $jobApplicationId = JobApplication::where('CandidateId', $request->candidates)->pluck('id')->first();
    
            // Store Schedule
            $interviewSchedule = new InterviewSchedule();
            $interviewSchedule->job_application_id = $jobApplicationId;
            $interviewSchedule->schedule_date = $dateTime;
            $interviewSchedule->status = $request->status;
            $interviewSchedule->meeting_title = $request->meeting_title;
            $interviewSchedule->meetingurl = $request->meetingurl;
            $interviewSchedule->interview_type = $request->interview_type;
            $interviewSchedule->user_accept_status = 'accept';
            $interviewSchedule->meeting_id = $request->meeting_id ?: null;
            $interviewSchedule->save();
    
            // Update Schedule Status
            $jobApplication = $interviewSchedule->jobApplication;
            $candidateId = $jobApplication->CandidateId;
            $candidate = Candidate::findOrFail($candidateId);
    
            if ($request->status == 'interview round 1') {
                candidate_history::create([
                    'remarks' => 'interview round 1',
                    'status_id' => 3,
                    'candidate_id' => $jobApplication->CandidateId,
                    'isactive' => 1,
                ]);
                $candidate->status_id = 3;
                $candidate->save();
                $jobApplication->status_id = 3;
            } elseif ($request->status == 'interview round 2') {
                candidate_history::create([
                    'remarks' => 'interview round 2',
                    'status_id' => 4,
                    'candidate_id' => $jobApplication->CandidateId,
                    'isactive' => 1,
                ]);
                $candidate->status_id = 4;
                $candidate->save();
                $jobApplication->status_id = 4;
            }
    
            $jobApplication->save();
    
            if ($request->comment) {
                $interviewSchedule->comments()->create([
                    'interview_schedule_id' => $interviewSchedule->id,
                    'user_id' => auth()->user()->id,
                    'comment' => $request->comment,
                ]);
            }
    
            \DB::commit();
    
            if (!empty($request->employees)) {
                $interviewSchedule->employees()->attach($request->employees);
    
                $userId = $request->employees[0]['user_id'];
                $user = User::find($userId);
                $interviewer = $user->name;
                $mode = $request->interview_type == 'online' ? 'Virtual' : 'Offline';
                $meetingUrl = $request->meetingurl;
                $IvStatus = $request->status;
                $position = $candidate->JobTitle;
    
                $emailContent = View::make('emails.interview_scheduled', [
                    'candidate' => $candidate,
                    'interviewer' => $interviewer,
                    'position' => $position,
                    'date' => $dateTime->format('Y-m-d'),
                    'time' => $dateTime->format('H:i'),
                    'mode' => $mode,
                    'meetingUrl' => $meetingUrl,
                    'IvStatus' => $IvStatus
                ])->render();
    
                Mail::to($user->email)
                    ->send(new InterviewScheduled($candidate, $interviewer, $position, $dateTime->format('Y-m-d'), $dateTime->format('H:i'), $mode, $meetingUrl, $IvStatus));
                    $SenderEmail = APP_EMAIL;
                EmailLog::create([
                    'recipient' => $user->email,
                    'subject' => $IvStatus . " interviewer",
                    'body' => $emailContent,
                    'candidate_id' => $candidate->Id,
                    'Sender' => $SenderEmail
                ]);
            }
    
            $emailContent = View::make('emails.interview_scheduled', [
                'candidate' => $candidate,
                'interviewer' => $interviewer,
                'position' => $position,
                'date' => $dateTime->format('Y-m-d'),
                'time' => $dateTime->format('H:i'),
                'mode' => $mode,
                'meetingUrl' => $meetingUrl,
                'IvStatus' => $IvStatus
            ])->render();
    
            Mail::to($candidate->Email)
                ->cc($interviewSchedule->email)
                ->send(new InterviewScheduled($candidate, $interviewer, $position, $dateTime->format('Y-m-d'), $dateTime->format('H:i'), $mode, $meetingUrl, $IvStatus));
                $SenderEmail = APP_EMAIL;
            EmailLog::create([
                'recipient' => $candidate->Email,
                'subject' => $IvStatus,
                'body' => $emailContent,
                'candidate_id' => $candidate->Id,
                'Sender' => $SenderEmail
            ]);

             // Send SMS notification to the candidate
             $smsService = new SmsService();
             $smsVariables = [
                 'var1' => $candidate->Name,
                 'var2' => $candidate->JobTitle,
                 'var3' => $dateTime->format('Y-m-d'),
                 'var4' => $dateTime->format('H:i'),

             ];
 
             $smsResponse = $smsService->sendSms([$candidate->ContactNo], 'Interview', $smsVariables);
    
            \DB::table('feedback')->insert([
                'job_application_id' => $jobApplication->id,
                'interview_schedule_id' => $interviewSchedule->id,
                'remark' => null,
                'status' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
    
            return $this->successJson('Interview Schedule Created Successfully', 200, $interviewSchedule);
        } catch (\Throwable $th) {
            \DB::rollBack();
            return $this->errorJson('Something went wrong', 403, $th->getMessage());
        }
    }


    public function storeurl(StoreRequest $request)
    {
        if(!auth()->user()->cans('add_schedule')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }else{
        $dateTime =  $request->scheduleDate . ' ' . $request->scheduleTime;
        $dateTime = Carbon::createFromFormat('Y-m-d H:i', $dateTime);
        
            if($request->interview_type == 'online'){
            $data = $request->all();
         
            $data['meeting_name'] = $request->meeting_title;
            $data['start_date_time'] = $dateTime;
            $data['meetingurl']=$request->meetingurl;
            //$meeting = $meeting->create($data);
          
            $meetings = $data;
        } 
        else{
            $meetings = '';
        }  
            // store Schedule
            $interviewSchedule = new InterviewSchedule();
            $interviewSchedule->job_application_id = $request->candidates;
            $interviewSchedule->schedule_date = $dateTime;
            $interviewSchedule->interview_type = ($request->has('interview_type')) ? $request->interview_type : 'offline';
            // $interviewSchedule->interview_type = $request->interview_type;
            $interviewSchedule->meeting_id = ($request->meeting_id!= '') ? $request->meeting_id: null;
            $interviewSchedule->meetingurl = ($request->meetingurl!= '') ? $request->meetingurl: null;
            $interviewSchedule->user_accept_status='accept';

            $interviewSchedule->save();

            // Update Schedule Status
            $jobApplication = $interviewSchedule->jobApplication;
             $jobApplication->status_id = 5;
             $jobApplication->save();

            if($request->status=='interview round 1'){
                $jobApplication->status_id = 3;
               }else if($request->status=='interview round 2'){
                  $jobApplication->status_id = 4;
    
              }else if($request->status=='salary Negotiation'){
               $jobApplication->status_id = 10;
               }

            // echo $jobApplication;
             $jobApplication->save();

            if ($request->comment) {
                $scheduleComment = [
                    'interview_schedule_id' => $interviewSchedule->id,
                    'user_id' => auth()->user()->id,
                    'comment' => $request->comment
                ];

                $interviewSchedule->comments()->create($scheduleComment);
            }

            if (!empty($request->employees)) {
                $interviewSchedule->employees()->attach($request->employees);
                Notification::send($interviewSchedule->employees, new ScheduleInterview($jobApplication,$interviewSchedule,$meetings));

                // Mail to employee for inform interview schedule
                Notification::send($interviewSchedule->employees, new ScheduleInterview($jobApplication,$meetings));
            }

            // mail to candidate for inform interview schedule
           Notification::send($jobApplication, new CandidateScheduleInterview($jobApplication, $interviewSchedule,$meetings));
           
  
 

            return $this->successJson('Interview Schedule Created Successfully',200,$jobApplication);
       }
    }

    // public function recruitment_type($recruitmentType)
    // {
    //     try {

    //         // Query the interview schedules based on the recruitment type
    //         $interviewSchedules = InterviewSchedule::select(
    //                 'interview_schedules.id',
    //                 'interview_schedules.schedule_date',
    //                 'interview_schedules.status',
    //                 'interview_schedules.interview_type',
    //                 'interview_schedules.user_accept_status',
    //                 'interview_schedules.meeting_id',
    //                 'job_applications.Name',
    //                 'jobs.erf_id',
    //                 'jobrecruitments.location'
    //             )
    //             ->join('job_applications', 'job_applications.id', '=', 'interview_schedules.job_application_id')
    //             ->leftJoin('jobs', 'jobs.id', '=', 'job_applications.job_id')
    //             ->where('jobs.recruitment_type', $recruitmentType)
    //             ->leftJoin('jobrecruitments', 'jobrecruitments.id', '=', 'job_applications.jobrecruitment_id')
                
    //             ->get();
    
    //         return $this->successJson('Interview schedules retrieved successfully', 200, $interviewSchedules);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Error retrieving interview schedules', 500, $e->getMessage());
    //     }
    // }

public function data(Request $request)
    {
        if(!auth()->user()->cans('view_schedule')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }else{
        $shedule = InterviewSchedule::select('interview_schedules.id','interview_schedules.interview_type', 'interview_schedule_employees.user_id as employee_id','job_applications.id as candidate_id','job_applications.Name','users.name as interviewer_name', 'interview_schedules.status','interview_schedules.schedule_date','interview_schedules.meetingurl')
            ->leftjoin('job_applications', 'job_applications.id', 'interview_schedules.job_application_id')
            ->leftjoin('interview_schedule_employees', 'interview_schedule_employees.interview_schedule_id', 'interview_schedules.id')
 
            ->leftJoin('users', 'interview_schedule_employees.user_id', 'users.id')

            ->whereNull('job_applications.deleted_at');
            
    
            $shedule = $shedule->orderBy('id', 'DESC')->get();
        if($shedule){
            return $this->successJson('Details',200,$shedule);
        }else{
            return $this->successJson('data not found',404);
        }
        
        }
       
    }

    public function update(UpdateRequest $request, $id)
    {
        if(!auth()->user()->cans('add_schedule')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }
        else{
            
            try{
            \DB::beginTransaction();
                $dateTime =  $request->scheduleDate . ' ' . $request->scheduleTime;
                $dateTime = Carbon::createFromFormat('Y-m-d H:i', $dateTime);

                // Update interview Schedule
                $interviewSchedule = InterviewSchedule::select('id', 'job_application_id','interview_type', 'schedule_date', 'status')
                    ->with([
                        'jobApplication:id,Name,Email,job_id,status_id',
                        'employees',
                        'comments'
                    ])
                    ->where('id', $id)->first();
                $interviewSchedule->schedule_date = $dateTime;
                if(!is_null($request->interview_type)){
                     $interviewSchedule->interview_type = $request->interview_type;

                    $interviewSchedule->meetingurl  = $request->meetingurl;
			

                }else{
                    $interviewSchedule->interview_type =  $interviewSchedule->interview_type;
            
                }
            
                if($request->interview_type == 'offline' ){
                    $interviewSchedule->meeting_id = null;
                    $interviewSchedule->meetingurl = null;
                    $meetings ='';
                }
                $interviewSchedule->save();

                if ($request->comment) {
                    $scheduleComment = [
                        'comment' => $request->comment
                    ];

                    $interviewSchedule->comments()->updateOrCreate([
                        'interview_schedule_id' => $interviewSchedule->id,
                        'user_id' => $this->user->id
                    ], $scheduleComment);
                }

                $jobApplication = $interviewSchedule->jobApplication;
                    //zoom meeting update
            
                if($request->interview_type == 'online'){
                
                    $data = $request->all();
                    //$data['meeting_name'] = $request->meeting_title;
                    $data['start_date_time'] = $dateTime;
                    $data['meetingurl']=$request->meetingurl;
			
                    $meetings = $data;
                    $interviewSchedule->save();
                }
                if (!empty($request->employee)) {
                    $interviewSchedule->employees()->sync($request->employee);
                    if(!($request->interview_type)){
                        $meeting = '';
                    }
                    // Mail to employee for inform interview schedule



                    Notification::send($interviewSchedule->employees, new ScheduleInterview($jobApplication,$interviewSchedule,$meetings));

                }
                \DB::commit();
                    return $this->successJson('Interview Schedule Updated Successfully',200,$interviewSchedule);
            }
            catch (\Throwable $th) {
                \DB::rollBack();
                return $this->errorJson('something else wrong',403,$th->getMessage());
            }
        } 
    }

    public function destroy($id)
    {
       if(!auth()->user()->cans('delete_schedule')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }
        else{
       InterviewSchedule::destroy($id);
        return $this->successJson('Interview Schedule  Deleted Successfully',200);
        }
    }

    //old method foe interview sedule get by job application 

    // public function show($id)
    // {
    //     try {
    //         // Check if the user has permission to view the schedule
    //         if (!auth()->user()->cans('view_schedule')) {
    //             return $this->errorJson('Not authenticated to perform this request',403);
    //         }

    //         $schedule = InterviewSchedule::with(['jobApplication', 'user'])->find($id);
    //         if (!$schedule) {
    //             return $this->errorJson('Interview schedule not found', 404);
    //         }

    //         $schedule['statuslist'] = ApplicationStatus::select('id', 'status')->get();
    //         return $this->successJson('Interview schedule list',200,$schedule);
    //     } catch (\Exception $e) {
    //         // Handle any exceptions that occur
    //         return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
    //     }
    // }

    //new method.
    

    public function show($id)
    { 
        try {
            // Check if the user has permission to view the schedule
            if (!auth()->user()->cans('view_schedule')) {
                return $this->errorJson('Not authenticated to perform this request',403);
            }

           // $schedule = InterviewSchedule::with(['jobApplication', 'user'])->where('job_application_id', $id)->find();
            $schedule = InterviewSchedule::with(['jobApplication', 'user'])
            ->where('job_application_id', $id)
            ->get();
            if (!$schedule) {
                return $this->errorJson('Interview schedule not found', 404);
            }

           // $schedule['statuslist'] = ApplicationStatus::select('id', 'status')->get();
            return $this->successJson('Interview schedule list',200,$schedule);
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }

    public function getInterview($id)
    { 
        try {
            // Check if the user has permission to view the schedule
            if (!auth()->user()->cans('view_schedule')) {
                return $this->errorJson('Not authenticated to perform this request',403);
            }
            $jobId = JobApplication::where('CandidateId', $id)->value('id');


            $schedule = InterviewSchedule::select('meeting_title', 'interview_type', 'meetingurl', 'schedule_date', 'job_application_id', 'id')
            ->with([
                'jobApplication' => function ($query) {
                    $query->select('id', 'Name as name', 'job_id', 'MRFId');
                },
                'comments' => function ($query) {
                    $query->select('id', 'interview_schedule_id', 'user_id', 'comment', 'created_at', 'updated_at')
                          ->with('user:id,name');
                },
                'employee'=>function($query)
                {
                    $query->select('id','interview_schedule_id','user_id','user_accept_status','created_at','updated_at')
                    ->with('user:id,name');
                }
            ])
            ->where('job_application_id', $jobId)
            ->first();

             
                 $jobId = $schedule->jobApplication->job_id;
             // Get pid from jobs table
             $jobDetails = Job::select('pid', 'recruitment_type')->where('id', $jobId)->first();
        
            $MRFId = $schedule->jobApplication->MRFId;
            
            // Get M_id from jobrecruitments table
            $mId = JobRecruitment::where('id',$MRFId)->value('M_id');

            
            $schedule->pid =$jobDetails->pid;
            $schedule->M_id = $mId;
            $schedule->recruitment_type = $jobDetails->recruitment_type;
            if (!$schedule) {
                return $this->errorJson('Interview schedule not found', 404);
            }

           // $schedule['statuslist'] = ApplicationStatus::select('id', 'status')->get();
            return $this->successJson('Interview schedule list',200,$schedule);
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
   
    public function changeStatus(Request $request)
    {        
        if(!auth()->user()->cans('add_schedule')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }
        else{
        $this->commonChangeStatusFunction($request->id, $request);

        //return Reply::success(__('messages.interviewScheduleStatus'));
        return $this->successJson('Update Successfull !',200);
        }
    }

    public function commonChangeStatusFunction($id, $request)
    {
        // store Schedule
        $interviewSchedule = InterviewSchedule::select('id', 'job_application_id', 'status')
            ->with([
                'jobApplication:id,Name,Email,job_id,status_id',
                'employees'
            ])
            ->where('id', $id)->first();
        $interviewSchedule->status = $request->status;
        $interviewSchedule->save();

        $application = $interviewSchedule->jobApplication;
        $status = ApplicationStatus::select('id', 'status');

        if (in_array($request->status, ['rejected', 'canceled'])) {
            $applicationStatus = $status->status('rejected');
        }
        if ($request->status === 'hired') {
            $applicationStatus = $status->status('hired');
        }
        if ($request->status === 'pending') {
            $applicationStatus = $status->status('interview round 1');
        }
        if ($request->status === 'interview round 1') {
            $applicationStatus = $status->status('interview round 1');
        }
        if ($request->status === 'salary Negotiation') {
            $applicationStatus = $status->status('salary Negotiation');
        }

        if ($request->status === 'interview round 2') {
            $applicationStatus = $status->status('interview round 2');
        }



        $application->status_id = $applicationStatus->id;

        $application->save();

        $employees = $interviewSchedule->employees;
        $admins = User::allAdmins();

        $users = $employees->merge($admins);

        if ($users && $request->mailToCandidate ==  'yes') {
            // Mail to employee for inform interview schedule
            Notification::send($users, new ScheduleInterviewStatus($application));
        }

        if ($request->mailToCandidate ==  'yes') {
            // mail to candidate for inform interview schedule status
            Notification::send($application, new ScheduleStatusCandidate($application, $interviewSchedule));
        }

        return;
    }
    public function sendratinglink(Request $request,$id,$employeeid){
       
         
        $shedule = InterviewSchedule::find($id);
       
       $users = User::find($employeeid);
       $candidates = JobApplication::find($shedule->job_application_id);
       $interviewDate=$shedule->schedule_date->format('d-m-Y H:i:s');
       $interviewLink=config('app.AppBaseURL').$request->url_name.'/'.Crypt::encryptString($id);
       $round=$request->round;

       
       Notification::send($users, new InterviewRatingNotification($interviewDate, $candidates->Name, $interviewLink,$round));
       
        return $this->successJson('Link Sent Successfully',200);
    }

public function getratinglink($id){
        $id=Crypt::decryptString($id);  

        $shedule = InterviewSchedule::find($id);
    $jobApplications = JobApplication::select('job_applications.id', 'job_applications.job_id','job_applications.relevent_exp','job_applications.total_exp','job_applications.qualification_id' ,'job_applications.jobrecruitment_id', 'status_id', 'Name','Email','ContactNo','CurrentLocation')
        ->with([ 
        'job',
        'recruitment',
        'salarydetails',
        'qualification',
        'subqualifications',
        'status:id,status',
        'interviews', 
        'totalrating',                    
        ])->where('id',$shedule->job_application_id)->get();
    if($jobApplications->isNotEmpty()){
        return $this->successJson('Job Applications Details',200,$jobApplications);
    }else{
        return $this->successJson('not found Details',404);
    }
}

// inter view
    public function getUsersWithInterviewPermission()
    {

        $users = User::with('role.role.permissions')->get();

        $requiredPermissions = [70]; 
        $InterviewPermission = [];


        foreach ($users as $user) {
            // Check if the user's role has any of the required permissions
            $hasPermission = collect($user['role']['role']['permissions'])
                ->whereIn('permission_id', $requiredPermissions)
                ->isNotEmpty(); 

            // If the user has the required permission, add their ID or name to the result
            if ($hasPermission) {
                $InterviewPermission[] = [
                    'id' => $user['id'],
                    'name' => $user['name']
                ];
            }
        }


            return response()->json([
                'InterviewPermission' => $InterviewPermission
            ]);

    }

    
}
