<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Jdstore;
use DB;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Log;
class JdController extends Controller

{

    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    // public function index($id = null)
    // {
    //     try {
    //         if ($id) {
    //             $jd = Jdstore::where('id', $id)->get();
    //         } else {
    //             $jd = Jdstore::get();
    //         }

    //         if ($jd) {
    //             return $this->successJson('Job Description List', 200, $jd);
    //         } else {
    //             return $this->errorJson('Data not found', 404);
    //         }
    //     } catch (\Exception $e) {
    //         // Handle any exceptions that occur
    //         return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
    //     }
    // }

    public function index($id = null)
{
    try {
        \Log::info('Attempting to fetch job descriptions.');

        if ($id) {
            \Log::info("Fetching job description with ID: $id");
            $jd = Jdstore::where('id', $id)->orderby('designation','asc')->get();
        } else {
            \Log::info('Fetching all job descriptions.');
            $jd = Jdstore::orderby('designation','asc')->get();
        }

        if ($jd->isEmpty()) {
            \Log::warning('No job descriptions found.');
            return $this->errorJson('Data not found', 404);
        }

        \Log::info('Job descriptions retrieved successfully.');
        return $this->successJson('Job Description List', 200, $jd);
    } catch (\Exception $e) {
        \Log::error('Error occurred while fetching job descriptions.', ['message' => $e->getMessage()]);
        return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
    }
}



    //  public function store(Request $request){
    //     $validator = Validator::make($request->all(), [
    //         'designation' => 'required|unique:jdstores',
    //         'job_type' => 'required',
    //         'job_description' => 'required',
    //         'responsibilities' => 'required',
    //         'requirements' => 'required',
            
    //     ]);
    //     if ($validator->fails()) {
    //         return response()->json(['error'=>$validator->errors()], 422);
    //     }
    //     try{
    //         \DB::beginTransaction();
    //         $jd=new Jdstore;
    //         $jd->designation=$request->designation;
    //         $jd->job_type=$request->job_type;
    //         $jd->job_description=$request->job_description;
    //         $jd->responsibilities=$request->responsibilities;
    //         $jd->requirements=$request->requirements;
    //         $jd->save();
                          
    //         \DB::commit();
    //           return $this->successJson('Job Description Saved Successfully',200,$jd);
    //     }
    //     catch (\Exception $e) {
    //         \DB::rollBack();
    //         return $this->errorJson('oops something went wrong please try again',500,$e->getMessage());
    //     }
    //  }

    public function store(Request $request)
{
    try {
        // Validate incoming request data
        $validator = Validator::make($request->all(), [
            'designation' => 'required|unique:jdstores',
            'job_type' => 'required',
            'job_description' => 'required',
            'responsibilities' => 'required',
            'requirements' => 'required',
        ]);

        // Check if validation fails
        if ($validator->fails()) {
            \Log::error('Validation failed while storing job description.', ['errors' => $validator->errors()->toArray()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        // Start database transaction
        \DB::beginTransaction();
        \Log::info('Transaction started for storing job description.');

        // Create new instance of Jdstore and save
        $jd = new Jdstore;
        $jd->designation = $request->designation;
        $jd->job_type = $request->job_type;
        $jd->job_description = $request->job_description;
        $jd->responsibilities = $request->responsibilities;
        $jd->requirements = $request->requirements;
        $jd->save();
        \Log::info('Job description saved successfully.', ['jdstore_id' => $jd->id]);

        // Commit transaction
        \DB::commit();
        \Log::info('Transaction committed.');

        // Return success response
        return $this->successJson('Job Description Saved Successfully', 200, $jd);
    } catch (\Exception $e) {
        // Rollback transaction in case of exception
        \DB::rollBack();
        \Log::error('Error occurred while storing job description.', ['message' => $e->getMessage()]);
        return $this->errorJson('Oops! Something went wrong. Please try again.', 500, $e->getMessage());
    }
}

    public function update(Request $request,$id){
        $validator = Validator::make($request->all(), [
            'designation' => ['required',Rule::unique('jdstores')->ignore($id)],
            'job_type' => 'required',
            'job_description' => 'required',
            'responsibilities' => 'required',
            'requirements' => 'required',
            ]);
        if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 422);
        }
        try{
            \DB::beginTransaction();
            $jd=Jdstore::find($id);

            if(empty($jd)){
                return $this->errorJson('not found Details',404);
            }else{

                $jd->designation=$request->designation;
                $jd->job_type=$request->job_type;
                $jd->job_description=$request->job_description;
                $jd->responsibilities=$request->responsibilities;
                $jd->requirements=$request->requirements;
                $jd->save();                          
                \DB::commit();
                return $this->successJson('Job Description Updated Successfully',200,$jd);
            }
        }
        catch (\Exception $e) {
            \DB::rollBack();
            return $this->errorJson('oops something went wrong please try again',500,$e->getMessage());
        }
    }

    public function delete($id)
    {
        try {
            // Validate the ID
            if (!is_numeric($id) || $id <= 0) {
                return $this->errorJson('Invalid ID', 400);
            }

            Jdstore::destroy($id);

            return $this->successJson('Job Description Deleted Successfully', 200);
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }

}
