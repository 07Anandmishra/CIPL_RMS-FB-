<?php
namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use App\Job;
use App\User;
use App\Skill;
use App\Question;
use Carbon\Carbon;
use App\JobLocation;
use App\ZoomMeeting;
use App\ZoomSetting;
use App\Helper\Files;
use App\Helper\Reply;
use App\JobApplication;
use App\ApplicationStatus;
use App\InterviewSchedule;
use App\ApplicationSetting;
use Illuminate\Support\Arr;
use App\Traits\ZoomSettings;
use Illuminate\Http\Request;
use App\JobApplicationAnswer;
use Illuminate\Support\Facades\DB;
use MacsiDigital\Zoom\Facades\Zoom;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\JobApplicationExport;
use Illuminate\Support\Facades\Storage;
use App\Notifications\ScheduleInterview;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Requests\StoreJobApplication;
use Maatwebsite\Excel\Excel as ExcelExcel;
use App\Http\Requests\UpdateJobApplication;
use App\Notifications\CandidateStatusChange;
use Illuminate\Support\Facades\Notification;
use App\Notifications\CandidateScheduleInterview;
use App\Http\Requests\InterviewSchedule\StoreRequest;
use App\JobApplicationsubqualification;
use App\Notifications\RatingNotification;
use App\Exports\ExportJobApplication; 
use App\Imports\ImportJobApplication; 
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use App\Mail\DocumentUploadMail;
use App\Mail\RatingMail;
use App\EmailLog;
use Illuminate\Support\Facades\View; 
use App\Mail\PccUploadMail;
use App\Document;
use App\Ratingdetail;
use Illuminate\Validation\Rule;
use App\Notifications\HiredNotification;
use App\Notifications\HoldNotification;
use App\Notifications\RejectNotification;
use App\Notifications\SelectedApplication;
// use App\Notifications\CandidateStatusDocument;
// use App\Notifications\AdminStatusDocument;
use App\Mail\CandidateStatusDocument;
use App\Mail\AdminStatusDocument;
use Illuminate\Support\Facades\Log;
use App\Candidate;
use App\candidate_status;
use App\candidate_history;



class JobApplicationController extends Controller
{
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }
   
    public function store(StoreJobApplication $request)
    {
        if(!auth()->user()->cans('add_candidate')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }else{
           
            try {
               \DB::beginTransaction();
            $jobApplication = new JobApplication();
            $jobApplication->full_name = $request->full_name;
            $jobApplication->lastname =$request->lastname;
	    $jobApplication->fatherfirst =$request->fatherfirst;
            $jobApplication->fatherlast =$request->fatherlast;
            $jobApplication->job_id = $request->job_id;
            $jobApplication->status_id = 1; //applied status id
            $jobApplication->jobrecruitment_id = $request->jobrecruitment_id;
            //,$jobApplication->crated_by=auth()->user()->id;
            $jobApplication->email = $request->email;
            $jobApplication->phone = $request->phone;
            $jobApplication->address = $request->address;
            $jobApplication->column_priority = 0;
            $jobApplication->relevent_exp=$request->relevent_exp;
	    $jobApplication->skills=$request->skills;
            $jobApplication->total_exp=$request->total_exp;
            $jobApplication->qualifications_id=$request->qualification_id;
            $jobApplication->added_by=auth()->user()->id;
            if ($request->has('gender')) {
                $jobApplication->gender = $request->gender;
            }
            if ($request->has('dob')) {
                $jobApplication->dob = $request->dob;
            }
	   $jobApplication->save();
	    if(!is_null($request->subqualification_id)){
                JobApplicationsubqualification::where('jobapplication_id', $jobApplication->id)->delete();
                foreach ($request->subqualification_id as $value) {
                    $jobapplicationqualification = new JobApplicationsubqualification();
                    $jobapplicationqualification->jobapplication_id = $jobApplication->id;
                    $jobapplicationqualification->status='1';
                    $jobapplicationqualification->subqualifications_id = $value;
                  
                    $jobapplicationqualification->save();
                }
             }
            if ($request->hasFile('resume')){
                $hashname = Files::uploadLocalOrS3($request->resume, 'documents/'.$jobApplication->id, null, null, false);
                    $jobApplication->documents()->create([
                    'name' => 'Resume',
                    'hashname' => $hashname
                ]);
            }

             if ($request->hasFile('document')){
                $hashname = Files::uploadLocalOrS3($request->document, 'documents/'.$jobApplication->id, null, null, false);
                    $jobApplication->documents()->create([
                    'name' => 'Document',
                    'hashname' => $hashname
                ]);
            }

              \DB::commit();
            if(!empty($jobApplication)){
                 $messagedata="Dear $request->full_name, Congratulations!!! your CV has been shortlisted for job opening at Corporate Infotech Private Limited.  If you want to proceed with further process please reply YES or reply NO to stop the process.Thank you.Team CIPL";

                Files::smssend($request->phone,$messagedata);

                return $this->successJson('Job Application Added Successfully',200,$jobApplication);
            }else{
                return $this->successJson('not found Details',200);
            }
          }catch (\Exception $th) {
            \DB::rollBack();
            return $this->errorJson('something else wrong',403,$th->getMessage());
        }
     }
    }

    public function applicationlist(Request $request)
    {
        
        // Get the recruitment type from the query parameters
        $recruitmentType = $request->query('type');

        try {
           

            $jobApplications = JobApplication::select(
                'job_applications.id',
                'job_applications.full_name',
                'job_applications.email',
                'job_applications.phone',
                'job_applications.address',
                'job_applications.job_id',
                'job_applications.relevent_exp',
                'job_applications.total_exp',
                'job_applications.status_id',
                'job_applications.qualifications_id',
                'jobs.pid',
                'jobs.project_name',
                'jobs.erf_id',
                'salarycreations.employeeCode',
                'salarycreations.ctc',
                'application_status.color',
                'qualifications.name as qualification_name'
                
            )
            ->join('jobs', 'job_applications.job_id', '=', 'jobs.id')
            ->leftJoin('qualifications', 'job_applications.qualifications_id', '=', 'qualifications.id')
            ->leftJoin('salarycreations', 'job_applications.id', '=', 'salarycreations.job_application_id')
            ->leftJoin('application_status', 'job_applications.status_id', '=', 'application_status.id')
            ->where('jobs.recruitment_type', $recruitmentType)
            ->whereNull('job_applications.deleted_at') // Check for soft deletes
            ->get();
            if ($jobApplications->isEmpty()) {
                return response()->json(['message' => 'No job applications found for the specified recruitment type'], 404);
            }

            // Return success response with job applications
            return response()->json(['message' => 'Job applications filtered by recruitment type successfully retrieved', 'data' => $jobApplications], 200);
        } catch (\Exception $e) {
            // Return error response in case of exception
            return response()->json(['message' => 'Error retrieving job applications', 'error' => $e->getMessage()], 500);
        }
    }



    public function get(Request $request, $id = null)
    {
        try {
            $jobApplications = JobApplication::select(
                'job_applications.id', 
                'job_applications.job_id',
                'job_applications.cancel_reason',
                'job_applications.relevent_exp',
                'job_applications.total_exp',
                'job_applications.qualifications_id',
                'job_applications.jobrecruitment_id', 
                'full_name',
                'email',
                'phone',
                'address',
                'skills',
                'added_by',
                'application_status.status',
                'application_status.color',
                'jobs.erf_id',
                'jobs.project_name',
                'salarycreations.employeeCode',
                'salarycreations.ctc'
            )
            ->leftJoin('jobs', 'job_applications.job_id', '=', 'jobs.id')
            ->leftJoin('application_status','job_applications.status_id','=','application_status.id')
            ->leftJoin('qualifications', 'job_applications.qualifications_id', '=', 'qualifications.id')
            ->leftJoin('salarycreations', 'job_applications.id', '=', 'salarycreations.job_application_id');

            if ($id) {
                $jobApplications = $jobApplications->where('jobs.pid', $id);
            }

            // if ($request->has('project_manager')) {            
            //     $jobApplications = $jobApplications->whereHas('recruitment', function ($query) use ($request) {
            //         $query->where('project_manager', $request->project_manager);
            //     });
            // }

            // if ($request->has('location')) {            
            //     $jobApplications = $jobApplications->whereHas('recruitment', function ($query) use ($request) {
            //         $query->where('location', $request->location);
            //     });
            // }

            $jobApplications = $jobApplications->get();

            if ($jobApplications->isNotEmpty()) {
                return $this->successJson('Job Applications Details', 200, $jobApplications);
            } else {
                return $this->successJson('No Details Found', 404);
            }
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }

    

    public function getlist()
    {
        try {
            $jobApplications = JobApplication::select('job_applications.id', 'job_applications.job_id','job_applications.relevent_exp','job_applications.total_exp','job_applications.qualifications_id' ,'job_applications.jobrecruitment_id', 'job_applications.status_id', 'job_applications.full_name','job_applications.email','job_applications.phone','job_applications.address', 'job_applications.skills')
                ->with([ 
                    'job',
                    'recruitment',
                    'salarydetails',
                    'qualification',
                    'subqualifications',
                    'status:id,status',
                    'interview', 
                ])->whereIn('status_id', ['3','4'])->get();
    
            if ($jobApplications->isNotEmpty()) {
                return $this->successJson('Job Applications Details',200,$jobApplications);
            } else {
                return $this->successJson('Not found Details',404);
            }
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
    
    public function getlistbyid()
    {
        try {
            $jobApplications = JobApplication::select('job_applications.id', 'job_applications.job_id','job_applications.rating','job_applications.relevent_exp','job_applications.total_exp','job_applications.qualifications_id' ,'job_applications.jobrecruitment_id', 'status_id', 'full_name','email','phone','address', 'skills')
                ->with([ 
                    'job',
                    'recruitment',
                    'salarydetails',
                    'qualification',
                    'subqualifications',
                    'status:id,status',
                    'interviews', 
                    'totalrating',                    
                ])->whereNotNull('job_applications.rating')->get();

            if ($jobApplications->isNotEmpty()) {
                return $this->successJson('Job Applications Details',200,$jobApplications);
            } else {
                return $this->successJson('Not found Details',404);
            }
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }

    public function edit($id)
    {
        try {
            if (!auth()->user()->cans('edit_candidate')) {
                return $this->errorJson('Not authenticated to perform this request', 403);
            }
    
            $data['statuses'] = ApplicationStatus::all();
            $data['application'] = JobApplication::find($id);
    
            if ($data) {
                return $this->successJson('Job Application Details', 200, $data);
            }
    
            return $this->errorJson('Job Application id not found', 404);
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
    
  
    // public function update(UpdateJobApplication $request, $id)
    // {
    //     if(!auth()->user()->cans('edit_job_applications')){
    //         return $this->errorJson('Not authenticated to perform this request',403);
    //     }else{
    //        try {
    //         \DB::beginTransaction();
    //        // $mailSetting = ApplicationSetting::select('id', 'mail_setting')->first()->mail_setting;
    //         $jobApplication = JobApplication::with(['documents'])->findOrFail($id);
            
    //         $jobApplication->full_name = $request->full_name;
    //         $jobApplication->job_id = $request->job_id;
    //         $jobApplication->status_id = $request->status_id; //applied status id
    //         $jobApplication->email = $request->email;
    //         $jobApplication->phone = $request->phone;
    //         $jobApplication->address = $request->address;
    //         //$jobApplication->column_priority = 0;
    //         $jobApplication->relevent_exp=$request->relevent_exp;
    //         $jobApplication->total_exp=$request->total_exp;
    //         $jobApplication->qualifications_id=$request->qualifications_id;
    //         $jobApplication->subqualification_id=$request->subqualification_id;
    //         if ($request->has('gender')) {
    //             $jobApplication->gender = $request->gender;
    //         }
    //         if ($request->has('dob')) {
    //             $jobApplication->dob = $request->dob;
    //         }
    //         $isStatusDirty = $jobApplication->isDirty('status_id');
    //         $jobApplication->save();
           
    //         if($request->subqualification_id[0] !="undefined"){
    //             JobApplicationsubqualification::where('jobapplication_id', $jobApplication->id)->delete();
    //             foreach ($request->subqualification_id as $value) {
    //                 $jobapplicationqualification = new JobApplicationsubqualification();
    //                 $jobapplicationqualification->jobapplication_id = $jobApplication->id;
    //                 $jobapplicationqualification->status='1';
    //                 $jobapplicationqualification->subqualifications_id = $value;
                  
    //                 $jobapplicationqualification->save();
    //             }
    //          }
    //         if ($request->hasFile('resume')) {
    //             $hashname = Files::uploadLocalOrS3($request->resume, 'documents/'.$jobApplication->id, null, null, false);
    //                 $jobApplication->documents()->create([
    //                 'name' => 'Resume',
    //                 'hashname' => $hashname
    //             ]);
    //         }
    //         \DB::commit(); 
    //          if ($request->status_id) {
    //        // Notification::send($jobApplication, new CandidateStatusChange($jobApplication));
    //          }
    //         if(!empty($jobApplication)){
    //             return $this->successJson('Job Application Updated Successfully',200,$jobApplication);
    //         }else{
    //             return $this->successJson('Not Found Details',200);
    //         }
    //     }catch (\Throwable $th) {
    //             \DB::rollBack();
    //             return $this->errorJson('Something Else Wrong',403,$th->getMessage());
    //         }
           
    //     }
    // }

    public function update(UpdateJobApplication $request, $id)
    {
        if (!auth()->user()->cans('edit_candidate')) {
            return $this->errorJson('Not authenticated to perform this request', 403);
        } else {
            try {
                \DB::beginTransaction();
                $jobApplication = JobApplication::with(['documents'])->findOrFail($id);

                $jobApplication->full_name = $request->full_name;
                $jobApplication->job_id = $request->job_id;
                $jobApplication->status_id = $request->status_id;
                $jobApplication->email = $request->email;
                $jobApplication->phone = $request->phone;
                $jobApplication->address = $request->address;
                $jobApplication->relevent_exp = $request->relevent_exp;
                $jobApplication->total_exp = $request->total_exp;
                $jobApplication->qualifications_id = $request->qualification_id; // Ensure this field is set correctly
                // Remove this line: $jobApplication->subqualification_id = $request->subqualification_id; 

                if ($request->has('gender')) {
                    $jobApplication->gender = $request->gender;
                }
                if ($request->has('dob')) {
                    $jobApplication->dob = $request->dob;
                }

                $isStatusDirty = $jobApplication->isDirty('status_id');
                $jobApplication->save();

                // Handle subqualifications
                if (!empty($request->subqualification_id)) {
                    JobApplicationsubqualification::where('jobapplication_id', $jobApplication->id)->delete();
                    foreach ($request->subqualification_id as $value) {
                        $jobapplicationqualification = new JobApplicationsubqualification();
                        $jobapplicationqualification->jobapplication_id = $jobApplication->id;
                        $jobapplicationqualification->status = '1';
                        $jobapplicationqualification->subqualifications_id = $value;
                        $jobapplicationqualification->save();
                    }
                }

                if ($request->hasFile('resume')) {
                    $hashname = Files::uploadLocalOrS3($request->resume, 'documents/' . $jobApplication->id, null, null, false);
                    $jobApplication->documents()->create([
                        'name' => 'Resume',
                        'hashname' => $hashname
                    ]);
                }

                \DB::commit();

                if ($request->status_id) {
                    Notification::send($jobApplication, new CandidateStatusChange($jobApplication));
                }

                return $this->successJson('Job Application Updated Successfully', 200, $jobApplication);
            } catch (\Throwable $th) {
                \DB::rollBack();
                return $this->errorJson('Something Else Wrong', 403, $th->getMessage());
            }
        }
    }

    public function destroy($id)
    {
        if(!auth()->user()->cans('edit_candidate')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }else{
           
            try {
                \DB::beginTransaction();
                
                $jobApplication = JobApplication::findOrFail($id);
                 JobApplicationsubqualification::where('jobapplication_id', $id)->delete();
                   
                if ($jobApplication->photo) {
                    Storage::delete('candidate-photos/'.$jobApplication->photo);
                }

                $jobApplication->forceDelete();
                \DB::commit();
                return $this->successJson('jobApplication Delete Successfully',200);
            }
            catch (\Throwable $th) {
                \DB::rollBack();
                return $this->errorJson('something else wrong',403,$th);
            }
        }
    }

    public function ratingSave(Request $request, $id)
    {
         
		 $validator = Validator::make($request->all(), [
                 
                'interviewround' => Rule::unique('ratingdetails')->where(fn ($query) => $query->where(['interviewround'=>$request->interviewround,'job_application_id'=>$id]))
             ]); 
             //$validator->setMessage('unique', 'The Feedback has already been taken');
 	 	$validator->setCustomMessages([
       	 	'interviewround.unique' => 'The Feedback has already been taken',
  		  ]);

             if ($validator->fails()) {
                 return $this->errorJson( $validator->messages(),422);
             }
            try {
                \DB::beginTransaction();
                
                    $application = JobApplication::withTrashed()->findOrFail($id);
                   
                    $application->rating = $request->tottal_rating;
                    
                    $application->save();
                    
                    $ratingdetail=new Ratingdetail();
                    $ratingdetail->job_application_id=$id;
                    $ratingdetail->overall_personality=$request->overall_personality;
                    $ratingdetail->mobility=$request->mobility;
                    $ratingdetail->self_concept=$request->self_concept;
                    $ratingdetail->openness_to_feedback=$request->openness_to_feedback;
                    $ratingdetail->drive=$request->drive;
                    $ratingdetail->leadership_potential=$request->leadership_potential;
                    $ratingdetail->personal_efficacy=$request->personal_efficacy;
                    $ratingdetail->maturity_understanding=$request->maturity_understanding;
                    $ratingdetail->comprehensibility_eloquence=$request->comprehensibility_eloquence;
                    $ratingdetail->knowledge_of_subject_job_product=$request->knowledge_of_subject_job_product;
                    $ratingdetail->poise_mannerism=$request->poise_mannerism;
                    $ratingdetail->tottal_rating=$request->tottal_rating;
                    $ratingdetail->interviewround=$request->interviewround;
		    $ratingdetail->comments=$request->comments;
                    $ratingdetail->save();
                    \DB::commit(); 
                     $admins = User::allAdmins();
                      
                 \Mail::to('omegasp9@gmail.com')->send(new RatingMail($ratingdetail));
                    //Notification::send($admins, new RatingNotification($application,$ratingdetail));
                    return $this->successJson('Thank you for valuable feedback',200);
            }
            catch (\Throwable $th) {
                \DB::rollBack();
                return $this->errorJson('something else wrong',403,$th->getMessage());
            }
         
        
    }

    public function show($id)
    {
        try {
            $application = JobApplication::with(['schedule', 'notes', 'onboard', 'status', 'schedule.employee', 'schedule.comments.user'])->find($id);
            if ($application) {
                return $this->successJson('Job Application with rating', 200, $application);
            } else {
                return $this->errorJson('Job Application not found', 404);
            }
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
    

    public function archiveJobApplication(Request $request, JobApplication $application)
    {
        try {
            if (!auth()->user()->cans('delete_candidate')) {
                return $this->errorJson('Not authenticated to perform this request', 403);
            }

            $application->delete();
            return $this->successJson('Application Archived Successfully', 200);
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }


 public function unarchiveJobApplication(Request $request, $application_id)
    {
        if(!auth()->user()->cans('delete_candidate')){
            return $this->errorJson('Not authenticated to perform this request',403);
        }else{
                $application = JobApplication::select('id', 'deleted_at')->withTrashed()->where('id', $application_id)->first();
                $application->restore(); 
                return $this->successJson('Application Unarchived Successfully',200); 
            }
    }


    public function exportJobApplication(Request $request)
    {
        try {
            return Excel::download(new ExportJobApplication, 'Candidate Bulk Upload' . time() . '.xlsx');
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }


    // public function JobApplicationimport(Request $request){
       
    //     $validator = Validator::make($request->all(), [           
    //         'import_file' => 'required|mimes:csv,xlsx',
    //         'job_id'=>'nullable',
    //         'jobrecruitment_id'=>'required',    
    //    ]);
    //     if ($validator->fails()) {
    //         return response()->json(['error'=>$validator->errors()], 422);
    
    //        }
    //     try{
    //        \DB::beginTransaction();
    //        session()->forget('jobrecruitment_id');
    //        session()->forget('job_id');
    //        session(['job_id'=>$request->job_id , 'jobrecruitment_id'=>$request->jobrecruitment_id]);
    //        Excel::import(new ImportJobApplication,$request->file('import_file'));
    //        \DB::commit();
    //        return $this->successJson('Candidate Added Successfully',200);
    //     }catch ( \Exception $e){
    //     \DB::rollBack();
    //     return $this->errorJson('oops something went wrong please try again',404,$e->getMessage());
    //     }            
       
    // }
 

    public function JobApplicationimport(Request $request)
    {
    Log::info('Job application import process started');

    // Validate the request
    $validator = Validator::make($request->all(), [
        'import_file' => 'required|mimes:csv,xlsx',
        'job_id' => 'nullable',
        'jobrecruitment_id' => 'nullable',
    ]);

    if ($validator->fails()) {
        Log::error('Validation failed', ['errors' => $validator->errors()]);
        return response()->json(['error' => $validator->errors()], 422);
    }

    try {
        \DB::beginTransaction();
        Log::info('Database transaction started');

        // Clear previous session data
        session()->forget('jobrecruitment_id');
        Log::info('Session jobrecruitment_id cleared');
        
        session()->forget('job_id');
        Log::info('Session job_id cleared');

        // Set new session data
        session(['job_id' => $request->job_id, 'jobrecruitment_id' => $request->jobrecruitment_id]);
        Log::info('Session data set', ['job_id' => $request->job_id, 'jobrecruitment_id' => $request->jobrecruitment_id]);

        // Import the Excel file
        try {
            Excel::import(new ImportJobApplication, $request->file('import_file'));
            Log::info('Excel file imported successfully');
        } catch (\Exception $e) {
            Log::error('Failed to import Excel file', ['error' => $e->getMessage()]);
            throw $e; // Rethrow the exception to be caught by the outer catch block
        }

        \DB::commit();
        Log::info('Database transaction committed successfully');

        return $this->successJson('Candidate Added Successfully', 200);
    } catch (\Exception $e) {
        \DB::rollBack();
        Log::error('Failed to import job application', ['error' => $e->getMessage()]);
        return $this->errorJson('Oops, something went wrong. Please try again.', 404, $e->getMessage());
    }
    }


    public function statusJobApplication(Request $request, $application_id)
    {
        try {
            if (!auth()->user()->cans('view_candidate')) {
                return $this->errorJson('Not authenticated to perform this request', 403);
            }
    
            $application = JobApplication::find($application_id);
    
            if ($application) {
                $application->status_id = $request->status;
                $application->save();
    
                if ($request->status == '14') {
                    Notification::send($application, new HoldNotification($application));
                }
                if ($request->status == '9') {
                    Notification::send($application, new RejectNotification($application));
                    $application->delete();
                }
    
                return $this->successJson('Status Updated Successfully', 200);
            } else {
                return $this->successJson('Job Application Not Found', 404);
            }
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
    


    public function documentuploadlink($id){
       

          // Find the job application by candidate ID
          $jobApplication = JobApplication::where('CandidateId', $id)->first();

        $application = JobApplication::find($jobApplication->id);

        //echo $application;
      // return $this->successJson('Application successfull update',200,$application->email); 
        if($application){
            try{
                \DB::beginTransaction();
                $application->status_id=13;
                $application->save();
                $url= config('app.AppBaseURL').'documentsupload/'.Crypt::encryptString($application->id); 
                $details = [
                            'title' => 'Documents Upload link',
                            'url' => $url,
                             'position'=>@$application->recruitment->degination,
                            ]; 
                
                $application->save();
                   // Update candidate status_id
        Candidate::where('id', $id)->update(['status_id' => 23]);

        // Candidate history
        candidate_history::create([
            'remarks' => 'Document verification link send',
            'status_id' => 23,
            'candidate_id' => $id,
            'isactive' => 1,
        ]);
           \DB::commit();
          
            //save the mail content in table
            $emailContent = View::make('emails.DocumentUploadMail', ['details' => $details])->render();
       
                Mail::to($application->Email)->send(new DocumentUploadMail($details));
               $SenderEmail = APP_EMAIL;
              // $SenderEmail = config('mail.from.address');
                EmailLog::create([
                    'recipient' =>$application->Email,
                    'subject' => 'Mail from CIPL Condidate Upload Documents',
                    'body' =>   $emailContent,
                    'candidate_id'=>$application->CandidateId,
                    'Sender'=> $SenderEmail
                ]);      
                return $this->successJson('Link Sent Successfully For Documents Uploading',200);
            }
            catch ( \Exception $e){
                \DB::rollBack();
                return $this->errorJson('oops something went wrong please try again',404,$e->getMessage());
                } 
        }else{
            return $this->errorJson('Page Not Found',404);
        }
    }

//==================Document upload for PCC=================//

    public function PCClink($id){
        $jobApplication = JobApplication::where('CandidateId', $id)->first();
        $application = JobApplication::findOrFail( $jobApplication->id);
        //return $this->successJson('Application successfull update',200,$application->email); 
         if($application){
             try{
                 \DB::beginTransaction();
                 //uncomment for managing status in job application 
                //  $application->status_id=19;
                //  $application->save();
                 $url= config('app.AppBaseURL').'pccupload/'.Crypt::encryptString($jobApplication->id); 
                 $details = [
                             'title' => 'Pcc Upload link',
                             'url' => $url
                             ]; 
                 
                 $application->save();
                 \DB::commit();
                 // Render the view to a string
                $emailContent = View::make('emails.PccUploadMail', ['details' => $details])->render();
                Mail::to($application->Email)->send(new PccUploadMail($details));
                    $SenderEmail = APP_EMAIL;
                   EmailLog::create([
                    'recipient' =>$application->Email,// email address,
                    'subject' => $details['title'],
                    'body' =>   $emailContent,
                    'candidate_id' => $id,
                    'Sender'=> $SenderEmail
                ]);
                //update the candidate status
        Candidate::where('id',$application->CandidateId)->update(['status_id' => 27]);

        // Candidate history
        candidate_history::create([
            'remarks' => 'PCC Document Link Send',
            'status_id' => 27,
            'candidate_id' => $application->CandidateId,
            'isactive' => 1,
        ]);

                 return $this->successJson('Send link successfully for Pcc upload',200,$application);
             }
             catch ( \Exception $e){
                 \DB::rollBack();
                 return $this->errorJson('oops something went wrong please try again',404,$e->getMessage());
                 } 
         }else{
             return $this->errorJson('page no founds',404);
         }
    }


   public function uploadpcc(Request $request,$id){
        $id=Crypt::decryptString($id);        
        $application = JobApplication::with(['documents'])->findOrFail($id);
        if($application){
            try {
               \DB::beginTransaction();
               if($request->hasFile('pcc')) {
                Document::where(['name'=>'pcc','documentable_id'=>$id])->delete();
                $hashname = Files::uploadLocalOrS3($request->pcc, 'documents/'.$application->id, null, null, false);
                    $application->documents()->create([
                    'name' => 'pcc',
                    'hashname' => $hashname
                ]);
            }
                $application->status_id=20;
                $application->save();

                     //update the candidate status
        Candidate::where('id',$application->CandidateId)->update(['status_id' => 28]);

        // Candidate history
        candidate_history::create([
            'remarks' => 'PCC Document Upload',
            'status_id' => 28,
            'candidate_id' => $application->CandidateId,
            'isactive' => 1,
        ]);
               \DB::commit();
               return $this->successJson('Pcc uploaded successfully',200,$application);
            } catch (\Throwable $e) {
               \DB::rollBack();
               return $this->errorJson('oops something went wrong please try again',403,$e->getMessage());
       }
           //return $this->successJson('Application successfull update',200,$application); 
       }else{
           return $this->errorJson('page no founds',404);
       }
    }


    

    public function getlistbyidfilter($id)
    {
        try {
            $jobApplications = JobApplication::select('job_applications.id', 'job_applications.job_id', 'job_applications.relevent_exp', 'job_applications.total_exp', 'job_applications.qualifications_id', 'job_applications.jobrecruitment_id', 'status_id', 'full_name', 'email', 'phone', 'address', 'skills')
                ->with([
                    'job',
                    'recruitment',
                    'salarydetails',
                    'qualification',
                    'subqualifications',
                    'status:id,status',
                    'interviews',
                    'totalrating',
                ])->where('id', $id)->get();
    
            if ($jobApplications->isNotEmpty()) {
                return $this->successJson('Job Applications Details', 200, $jobApplications);
            } else {
                return $this->successJson('Not found Details', 404);
            }
        } catch (\Exception $e) {
            // Handle any exceptions that occur
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }

    function uploadDocument(Request $request,$id)
    {
        $id=Crypt::decryptString($id);  
        $mailSetting = ApplicationSetting::select('id', 'mail_setting')->first()->mail_setting;
        $applications = JobApplication::with(['documents'])->where('status_id','13')->find($id);
            
  
        if(!empty($applications)){
            try {
            $application = JobApplication::with(['documents'])->find($id);
           
            Log::info("Starting document upload process for Job Application ID: {$id}");
               \DB::beginTransaction();
               if($request->hasFile('aadharfront')) {
                   Document::where(['name'=>'aadharfront','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->aadharfront, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'aadharfront',
                       'hashname' => $hashname
                   ]);
                   Log::info("Aadhar  document uploaded for Job Application ID: {$id}");
                   
               }
               
               if($request->hasFile('aadharback')) {
                   Document::where(['name'=>'aadharback','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->aadharback, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'aadharback',
                       'hashname' => $hashname
                   ]);
                   Log::info("Aadhar Back document uploaded for Job Application ID: {$id}");
                   
               }
               if($request->hasFile('passport')) {
                   Document::where(['name'=>'passport','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->passport, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'passport',
                       'hashname' => $hashname
                   ]);
                   Log::info("PassPort document uploaded for Job Application ID: {$id}");
               }

               if($request->hasFile('pancard')) {
                   Document::where(['name'=>'pancard','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->pancard, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'pancard',
                       'hashname' => $hashname
                   ]);
                   Log::info("PanCard document uploaded for Job Application ID: {$id}");
               }

               if($request->hasFile('voterid')) {
                   Document::where(['name'=>'voterid','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->voterid, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'voterid',
                       'hashname' => $hashname
                   ]);
                   Log::info("Voterid document uploaded for Job Application ID: {$id}");
               }
               
               if($request->hasFile('offerletter')) {
                   Document::where(['name'=>'offerletter','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->offerletter, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'offerletter',
                       'hashname' => $hashname
                   ]);
                   Log::info("Offerletter document uploaded for Job Application ID: {$id}");
               }

               if($request->hasFile('appointmentletter')) {
                   Document::where(['name'=>'appointmentletter','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->appointmentletter, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'appointmentletter',
                       'hashname' => $hashname
                   ]);
                   Log::info("appointmentletter document uploaded for Job Application ID: {$id}");
               }

               if($request->hasFile('salaryslip')) {
                   Document::where(['name'=>'salaryslip','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->salaryslip, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'salaryslip',
                       'hashname' => $hashname
                   ]);
                   Log::info("salaryslip document uploaded for Job Application ID: {$id}");
                   
               }

               if($request->hasFile('bankstatement')) {
                   Document::where(['name'=>'bankstatement','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->bankstatement, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'bankstatement',
                       'hashname' => $hashname
                   ]);
                   Log::info("bankstatement document uploaded for Job Application ID: {$id}");
               }
               if($request->hasFile('cancelcheque')) {
                   Document::where(['name'=>'cancelcheque','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->cancelcheque, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'cancelcheque',
                       'hashname' => $hashname
                   ]);
                   Log::info("cancelcheque document uploaded for Job Application ID: {$id}");
               }

               if($request->hasFile('other')) {
                   Document::where(['name'=>'other','documentable_id'=>$id])->delete();
                   $hashname = Files::uploadLocalOrS3($request->other, 'documents/'.$application->id, null, null, false);
                       $application->documents()->create([
                       'name' => 'other',
                       'hashname' => $hashname
                   ]);
                   Log::info("other document uploaded for Job Application ID: {$id}");
               }

                $application->status_id=16;
                $application->save();

                 // Update candidate status_id
       Candidate::where('id',$application->CandidateId)->update(['status_id' => 24]);

        // Candidate history
        candidate_history::create([
            'remarks' => 'Document Upload',
            'status_id' => 24,
            'candidate_id' => $application->CandidateId,
            'isactive' => 1,
        ]);

                 
                \DB::commit();
                 //  $admins = User::allAdmins();
                   //save the mail content in table
                    // Prepare email details
                    
            $details = [
                'title' => 'Documents Uploaded',
                'candidate_name' => ucwords($application->Name),
                'application_id' => $application->id,
                'job_title' => $application->JobTitle,
                'created_at'=>$application->created_at
            ];
         // Log email content
         $emailContent = View::make('emails.CandidateStatusDocument', ['details' => $details])->render();
          
            // Send email to candidate
            Mail::to($application->Email)->send(new CandidateStatusDocument($details));

            $SenderEmail = APP_EMAIL;
            EmailLog::create([
                'recipient' => $application->Email,
                'subject' => $details['title'],
                'body' => $emailContent,
                'candidate_id' => $application->CandidateId,
                'Sender' =>  $SenderEmail
            ]);

                 // Notification::send($application, new CandidateStatusDocument($application));
                // Notification::send($admins, new AdminStatusDocument($application)); 

             // Send email to admins
             $admins = User::allAdmins();
             
             foreach ($admins as $admin) {
               
                // Log email content
                $adminEmailContent = View::make('emails.AdminStatusDocument', ['details' => $details])->render();
                 
                Mail::to($admin->email)->send(new AdminStatusDocument($details));
                
                 $SenderEmail = APP_EMAIL;
                 EmailLog::create([
                     'recipient' => $admin->email,
                     'subject' => $details['title'],
                     'body' => $adminEmailContent,
                     'candidate_id' => $application->CandidateId,
                     //'Sender' => config('mail.from.address')
                     'Sender'=> $SenderEmail
                 ]);
             }

                return $this->successJson('Documents Uploaded Successfully',200,$application);

             } catch (\Throwable $e) {
                Log::error("Error occurred during document upload process for Job Application ID: {$id}", ['exception' => $e]);
                \DB::rollBack();
                return $this->errorJson('oops something went wrong please try again',403,$e->getMessage());
        }
            //return $this->successJson('Application successfull update',200,$application); 
        }else{
            return $this->errorJson('Documents already uploaded !',404,$applications);
        }
    }

    
    
    public function getDocuments($id)
    {
        try {
            // Decrypt candidate ID if it's encrypted
            // $candidateId = \Crypt::decryptString($id);

            // Fetch job application using candidate ID
            $jobApplication = JobApplication::where('CandidateId', $id)->first();

            if (!$jobApplication) {
                return response()->json([
                    'message' => 'Job Application not found',
                    'status' => 404
                ], 404);
            }

            // Fetch documents related to the job application
            $documents = Document::where('documentable_id', $jobApplication->id)
                                  ->where('documentable_type', JobApplication::class)
                                 ->get();

            // Retrieve the document details based on the job application ID
                // $documents = Document::where('documentable_id', $jobApplication->id)
                // ->where('documentable_type', 'App\JobApplication')
                // ->get();

            if ($documents->isEmpty()) {
                return response()->json([
                    'message' => 'No documents found for the candidate',
                    'status' => 404
                ], 404);
            }

            // for s3 bucket or local
            // Prepare the response data
            // $responseData = $documents->map(function ($document) {
            //     return [
            //         'name' => $document->name,
            //         'url' => Storage::disk('s3')->url('documents/' . $document->documentable_id . '/' . $document->hashname),
            //         'uploaded_at' => $document->created_at
            //     ];
            // });

            // Prepare the response with document details
                $documentDetails = $documents->map(function ($document) {
                    return [
                        'id'=>$document->id,
                        'name' => $document->name,
                        'hashname' => $document->hashname,
                        'url' => url('user-uploads/documents/' . $document->documentable_id . '/' . $document->hashname),
                        'is_verified'=>$document->is_verified,
                        'created_at' => $document->created_at,
                        'updated_at' => $document->updated_at,
                    ];
                });

            return response()->json([
                'message' => 'Documents retrieved successfully',
                'status' => 200,
                'data' => $documentDetails
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to retrieve documents',
                'status' => 500,
                'error' => $e->getMessage()
            ], 500);
        }
    }
  
  //update the document verified or not verified
public function updateDocumentVerificationStatus(Request $request, $id,$docId)
{
    try {
        
             // Find the job application by candidate ID
          $jobApplication = JobApplication::where('CandidateId', $id)->first();

        Log::info('Starting document verification status update', ['documentable_id' =>$jobApplication->id ]);

        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'is_verified' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed for document verification update', ['errors' => $validator->errors()->toArray()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        \DB::beginTransaction();

        // Find the document by documentable_id
        $document = Document::where('documentable_id', $jobApplication->id)
                     ->where('id', $docId)
                     ->first();
        if (empty($document)) {
            Log::warning('Document not found', ['document_id' => $jobApplication->id]);
            return $this->errorJson('Document not found', 404);
        }

        Log::info('Document found', ['document_id' => $jobApplication->id]);

        // Update the verification status
        $document->is_verified = $request->is_verified;
        $document->save();

        // Update candidate status based on verification
        $application = JobApplication::find($document->documentable_id);

        if ($application) {
            if ($request->is_verified == 1) {
                $application->status_id = 21;  // Document Verified
                // Update candidate status in Candidate table
                Candidate::where('id', $application->CandidateId)->update(['status_id' => 25]);

                // Candidate history
                candidate_history::create([
                    'remarks' => 'Document Verified',
                    'status_id' => 25,
                    'candidate_id' => $application->CandidateId,
                    'isactive' => 1,
                ]);

                Log::info('Document verified successfully', ['document_id' => $jobApplication->id]);
                Log::info('Application status updated to Document Verified', ['application_id' => $application->id, 'status_id' =>21]);

                $message = 'Document verified successfully';

            } else {
                $application->status_id = 22;  // Document Not Verified
                // Update candidate status in Candidate table
                Candidate::where('id', $application->CandidateId)->update(['status_id' => 26]);

                // Candidate history
                candidate_history::create([
                    'remarks' => 'Document Not Verified',
                    'status_id' => 26,
                    'candidate_id' => $application->CandidateId,
                    'isactive' => 1,
                ]);

                Log::info('Document not verified', ['document_id' => $jobApplication->id]);
                Log::info('Application status updated to Document Not Verified', ['application_id' => $application->id, 'status_id' =>22]);

                $message = 'Document not verified';

            }

            $application->save();

        } else {
            Log::warning('Associated job application not found', ['documentable_id' => $document->documentable_id]);
            return $this->errorJson('Associated job application not found', 404);
        }

        \DB::commit();
        return $this->successJson($message, 200, $document);

    } catch (\Throwable $e) {
        \DB::rollBack();
        Log::error('Error during document verification status update', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred while updating the document verification status', 500, $e->getMessage());
    }
}

//update the pcc varified or not verified

public function updatePccVerificationStatus(Request $request, $id,$docId)
{
    try {
        
             // Find the job application by candidate ID
          $jobApplication = JobApplication::where('CandidateId', $id)->first();

        Log::info('Starting document verification status update', ['documentable_id' =>$jobApplication->id ]);

        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'is_verified' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed for document verification update', ['errors' => $validator->errors()->toArray()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        \DB::beginTransaction();

        // Find the document by documentable_id
        $document = Document::where('documentable_id', $jobApplication->id)
                     ->where('id', $docId)
                     ->first();
        if (empty($document)) {
            Log::warning('Document not found', ['document_id' => $jobApplication->id]);
            return $this->errorJson('Document not found', 404);
        }

        Log::info('Document found', ['document_id' => $jobApplication->id]);

        // Update the verification status
        $document->is_verified = $request->is_verified;
        $document->save();

        // Update candidate status based on verification
        $application = JobApplication::find($document->documentable_id);

        if ($application) {
            if ($request->is_verified == 1) {
                $application->status_id = 24;  // Document Verified
                // Update candidate status in Candidate table
                Candidate::where('id', $application->CandidateId)->update(['status_id' => 29]);

                // Candidate history
                candidate_history::create([
                    'remarks' => 'PCC Document Verified',
                    'status_id' => 29,
                    'candidate_id' => $application->CandidateId,
                    'isactive' => 1,
                ]);

                Log::info('Document verified successfully', ['document_id' => $jobApplication->id]);
                Log::info('Application status updated to Document Verified', ['application_id' => $application->id, 'status_id' =>21]);

                $message = 'PCC Document verified successfully';

            } else {
                $application->status_id = 26;  // Document Not Verified
                // Update candidate status in Candidate table
                Candidate::where('id', $application->CandidateId)->update(['status_id' => 30]);

                // Candidate history
                candidate_history::create([
                    'remarks' => 'PCC Document Not Verified',
                    'status_id' => 30,
                    'candidate_id' => $application->CandidateId,
                    'isactive' => 1,
                ]);

                Log::info('Document not verified', ['document_id' => $jobApplication->id]);
                Log::info('Application status updated to Document Not Verified', ['application_id' => $application->id, 'status_id' =>22]);

                $message = 'PCC Document not verified';

            }

            $application->save();

        } else {
            Log::warning('Associated job application not found', ['documentable_id' => $document->documentable_id]);
            return $this->errorJson('Associated job application not found', 404);
        }

        \DB::commit();
        return $this->successJson($message, 200, $document);

    } catch (\Throwable $e) {
        \DB::rollBack();
        Log::error('Error during document verification status update', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred while updating the document verification status', 500, $e->getMessage());
    }
}


    public function hired(Request $request,$id){

        $application = JobApplication::with([ 
                            'job',
                            'recruitment',
                            'salarydetails',
                            'qualification',
                            'subqualifications',
                            'status:id,status',
                            'interviews', 
                            'totalrating',                    
                            ])->find($id);
        if($application){
           $application->status_id=$request->status;
           $application->save();      
  	Notification::send($application, new HiredNotification($application));
	return $this->successJson('Email Sent Successfully',200,$application); 
        }else{
            return $this->successJson('Application not founds',404); 
        } 
        
    }

     public function uploadresult(Request $request,$id){
        $application = JobApplication::findOrFail($id);
        if($application){
            try{
                 $validator = Validator::make($request->all(), [
                 
                'status_id' =>'required',
                'file'=>'required' 
              ]); 
             if ($validator->fails()) {
                 return $this->errorJson( $validator->messages(),422);
             }


                \DB::beginTransaction();
                $application->status_id=$request->status_id;
                $application->save();
                if ($request->hasFile('file')){
                        Document::where(['name'=>'result','documentable_id'=>$id])->delete();

                    $hashname = Files::uploadLocalOrS3($request->file, 'result/'.$application->id, null, null, false);
                        $application->documents()->create([
                        'name' => 'result',
                        'hashname' => $hashname
                    ]);
                }
  	\DB::commit();
                return $this->successJson('Result Uploaded Successfully',200,$application);
              
            }catch (\Throwable $e) {
                \DB::rollBack();
                return $this->errorJson('oops something went wrong please try again',403,$e->getMessage());
            }
        }else{
            return $this->errorJson('page no founds',404);
        }
    }  

    public function reject(Request $request, JobApplication $application)
    {
        if($application){
                $validator = Validator::make($request->all(), [           
                    'status' => 'required',             
            ]);
            if ($validator->fails()) {
                return response()->json(['error'=>$validator->errors()], 422);    
            }
          $application->status_id=$request->status;
          $application->cancel_reason=$request->cancel_reason; 
 
          $application->save();       
     
            if($request->status=='9' || $request->status=='17' || $request->status=='18'){
                    Notification::send($application, new RejectNotification($application));
                    $application->delete();  
                    return $this->successJson('Application Archived Successfully',200); 
            }
        }   
    }

    public function selectionupdate(Request $request, JobApplication $application)
    { 
        try {
            if ($application) {
                $validator = Validator::make($request->all(), [
                    'status' => 'required',
                ]);
                if ($validator->fails()) {
                    return response()->json(['error' => $validator->errors()], 422);
                }

                $application->status_id = $request->status;
                $application->save();
                if ($request->status == '5' || $request->status == '21' || $request->status == '22') {
                    Notification::send($application, new SelectedApplication($application));
                    return $this->successJson('Application Status Update Successfully', 200);
                }
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while updating application status.', 500);
        }
    }


//rating round 1

    public function ratinginterviewone($type = null)
    {
        try {
            $rating = Ratingdetail::select('job_applications.id as jobapplication_id', 'job_applications.full_name', 'ratingdetails.*')
                ->leftJoin('job_applications', 'job_applications.id', 'ratingdetails.job_application_id')
                //->where('ratingdetails.interviewround',$type)
                ->whereNull('job_applications.deleted_at')
                ->get();

            if ($rating) {
                return $this->successJson('Rating Details', 200, $rating);
            } else {
                return $this->errorJson('Data not found', 404);
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while fetching rating details.', 500);
        }
    }


    public function ratinginterviewoneold($type = null)
    {
        try {
            $rating = Ratingdetail::select('job_applications.id as jobapplication_id', 'job_applications.full_name', 'jobrecruitments.degination', 'jobrecruitments.location', 'ratingdetails.*')
                ->leftJoin('job_applications', 'job_applications.id', '=', 'ratingdetails.job_application_id')
                ->leftJoin('jobrecruitments', 'jobrecruitments.id', '=', 'job_applications.jobrecruitment_id')
                //->where('ratingdetails.interviewround',$type)
                ->whereNull('job_applications.deleted_at')
                ->orderBy('ratingdetails.updated_at', 'desc')
                ->get();
    
            if ($rating) {
                return $this->successJson('Rating Details', 200, $rating);
            } else {
                return $this->errorJson('Data not found', 404);
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while fetching rating details.', 500);
        }
    }


    public function getUsersWithJobPermissions()
    {
        

       
        $users = User::with('role.role.permissions')->get();

        $requiredPermissions = [79]; 
        $ProjectPermission = [];

    
        foreach ($users as $user) {
            // Check if the user's role has any of the required permissions
            $hasPermission = collect($user['role']['role']['permissions'])
                ->whereIn('permission_id', $requiredPermissions)
                ->isNotEmpty(); 

            // If the user has the required permission, add their ID or name to the result
            if ($hasPermission) {
                $ProjectPermission[] = [
                    'id' => $user['id'],
                    'name' => $user['name']
                ];
            }
        }

    // Return users who have any of the required permissions
            return response()->json([
                'ProjectPermission' => $ProjectPermission
            ]);
        //for all user with permission code
        //         $users = User::with(['role.role.permissions'])
        //     ->get()
        //     ->filter(function($user) {
        //         return $user->role->role->permissions->contains(function($permission) {
        //             return in_array($permission->permission_id, [75, 76]);
        //         });
        //     });

        // // Return the filtered users
        // return response()->json($users);
    }

    
    public function getUsersWithDoxPermissions()
    {
        $users = User::with('role.role.permissions')->get();
        $requiredPermissions = [88,89,91,92]; 
        $DoxPermissions = [];
        foreach ($users as $user) {
            // Check if the user's role has any of the required permissions
            $hasPermission = collect($user['role']['role']['permissions'])
                ->whereIn('permission_id', $requiredPermissions)
                ->isNotEmpty(); 
                
            if ($hasPermission) {
                $DoxPermissions[] = [
                    'id' => $user['id'],
                    'name' => $user['name']
                ];
            }
        }

            return response()->json([
                'DoxPermissions' => $DoxPermissions
            ]);
        
    }
    

//end
}
