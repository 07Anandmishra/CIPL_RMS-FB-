<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helper\Reply;
use App\Http\Requests\StoreJobCategory;
use App\JobCategory;
use App\Skill;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log; 

class JobCategoryController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    // public function index()
    // {
    //     try {
    //         $categories = JobCategory::all();

    //         if ($categories->isEmpty()) {
    //             return $this->successJson('List not found', 404);
    //         }

    //         return $this->successJson('Job Category Details', 200, $categories);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred while fetching job categories.', 500);
    //     }
    // }

    public function index()
{
    Log::info('JobCategoryController@index: Method execution started.');

    try {
        Log::info('JobCategoryController@index: Attempting to retrieve all job categories.');
        $categories = JobCategory::orderBy('name', 'asc')->get();
        Log::info('JobCategoryController@index: Job categories retrieved successfully.', ['categories' => $categories]);

        if ($categories->isEmpty()) {
            Log::warning('JobCategoryController@index: No job categories found.');
            return $this->successJson('List not found', 404);
        }

        Log::info('JobCategoryController@index: Job categories found, preparing success response.');
        return $this->successJson('Job Category Details', 200, $categories);
    } catch (\Exception $e) {
        Log::error('JobCategoryController@index: An error occurred while fetching job categories.', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return $this->errorJson('An error occurred while fetching job categories.', 500);
    }
}


//  public function index1(){
        
//         $categories = JobCategory::all();
//         if(!empty($categories)){
//             return $this->successJson('Job Category Details',200,$categories);
//         }else{
//             return $this->successJson('List not founds',404);
//         }
       

//     }

//     public function addold(StoreJobCategory $request){
//         if(!auth()->user()->cans('add_category')){
//             return $this->errorJson('Not authenticated to perform this request',403);
//         }else{
//         $category=JobCategory::create(['name' => $request->name]);
//         if(!empty($category)){
//             return $this->successJson('Job Category Added Successfully',200,$category);
//         }else{
//             return $this->successJson('something else wrong',500);
//         }
//        }
//     }

//     public function add(Request $request)
//     {
//         try {
//             if (!auth()->user()->cans('add_category')) {
//                 return $this->errorJson('Not authenticated to perform this request', 403);
//             }
    
//             $validator = Validator::make($request->all(), [
//                 'name' => 'required|unique:job_categories,name',
//             ]);
            
//             if ($validator->fails()) {
//                 return response()->json(['error' => $validator->errors()], 422);
//             }
    
//             $category = JobCategory::create(['name' => $request->name]);
    
//             if (!empty($category)) {
//                 return $this->successJson('Job Category Added Successfully', 200, $category);
//             } else {
//                 return $this->errorJson('Failed to add job category', 500);
//             }
//         } catch (\Exception $e) {
//             return $this->errorJson('An error occurred while adding the job category.', 500);
//         }
//     }
    

//     public function edit(StoreJobCategory $request, $id = null)
//     {
//         try {
//             if (!auth()->user()->cans('edit_category')) {
//                 return $this->errorJson('Not authenticated to perform this request', 403);
//             }
    
//             $category = JobCategory::find($id);
    
//             if (!empty($category)) {
//                 return $this->successJson('Details', 200, $category);
//             } else {
//                 return $this->successJson('Category not found', 404);
//             }
//         } catch (\Exception $e) {
//             return $this->errorJson('An error occurred while fetching the job category details.', 500);
//         }
//     }
    
//     public function update(StoreJobCategory $request, $id = null)
//     {
//         try {
//             if (!auth()->user()->cans('edit_category')) {
//                 return $this->errorJson('Not authenticated to perform this request', 403);
//             }

//             if (!empty($id)) {
//                 $category = JobCategory::find($id);
//                 if ($category) {
//                     $category->name = $request->name;
//                     $category->save();
//                     return $this->successJson('Job Category Updated Successfully', 200, $category);
//                 } else {
//                     return $this->errorJson('Category not found', 404);
//                 }
//             } else {
//                 return $this->errorJson('Data not found', 404);
//             }
//         } catch (\Exception $e) {
//             return $this->errorJson('An error occurred while updating the job category.', 500);
//         }
//     }

//     public function destroy($id)
//     {
//         try {
//             if (!auth()->user()->cans('delete_category')) {
//                 return $this->errorJson('Not authenticated to perform this request', 403);
//             }
    
//             if (empty($id)) {
//                 return $this->errorJson('Category ID is required', 422);
//             }
    
//             JobCategory::destroy($id);
//             return $this->successJson('Job Category Deleted Successfully', 200);
//         } catch (\Exception $e) {
//             return $this->errorJson('An error occurred while deleting the job category.', 500);
//         }
//     }
    
// }


public function index1()
{
    Log::info('JobCategoryController@index1: Method execution started.');

    $categories = JobCategory::all();
    Log::info('JobCategoryController@index1: Retrieved all job categories.', ['categories' => $categories]);

    if (!empty($categories)) {
        Log::info('JobCategoryController@index1: Job categories found.');
        return $this->successJson('Job Category Details', 200, $categories);
    } else {
        Log::warning('JobCategoryController@index1: No job categories found.');
        return $this->successJson('List not founds', 404);
    }
}

public function addold(StoreJobCategory $request)
{
    Log::info('JobCategoryController@addold: Method execution started.');

    if (!auth()->user()->cans('add_category')) {
        Log::warning('JobCategoryController@addold: User not authenticated to perform this request.');
        return $this->errorJson('Not authenticated to perform this request', 403);
    } else {
        $category = JobCategory::create(['name' => $request->name]);
        Log::info('JobCategoryController@addold: Created job category.', ['category' => $category]);

        if (!empty($category)) {
            Log::info('JobCategoryController@addold: Job category added successfully.');
            return $this->successJson('Job Category Added Successfully', 200, $category);
        } else {
            Log::error('JobCategoryController@addold: Failed to add job category.');
            return $this->successJson('something else wrong', 500);
        }
    }
}

public function add(Request $request)
{
    Log::info('JobCategoryController@add: Method execution started.');

    try {
        if (!auth()->user()->cans('add_category')) {
            Log::warning('JobCategoryController@add: User not authenticated to perform this request.');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:job_categories,name',
        ]);
        Log::info('JobCategoryController@add: Validation completed.', ['validator' => $validator]);

        if ($validator->fails()) {
            Log::warning('JobCategoryController@add: Validation failed.', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        $category = JobCategory::create(['name' => $request->name]);
        Log::info('JobCategoryController@add: Created job category.', ['category' => $category]);

        if (!empty($category)) {
            Log::info('JobCategoryController@add: Job category added successfully.');
            return $this->successJson('Job Category Added Successfully', 200, $category);
        } else {
            Log::error('JobCategoryController@add: Failed to add job category.');
            return $this->errorJson('Failed to add job category', 500);
        }
    } catch (\Exception $e) {
        Log::error('JobCategoryController@add: An error occurred while adding the job category.', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return $this->errorJson('An error occurred while adding the job category.', 500);
    }
}

public function edit(StoreJobCategory $request, $id = null)
{
    Log::info('JobCategoryController@edit: Method execution started.');

    try {
        if (!auth()->user()->cans('edit_category')) {
            Log::warning('JobCategoryController@edit: User not authenticated to perform this request.');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        $category = JobCategory::find($id);
        Log::info('JobCategoryController@edit: Retrieved job category.', ['category' => $category]);

        if (!empty($category)) {
            Log::info('JobCategoryController@edit: Job category found.');
            return $this->successJson('Details', 200, $category);
        } else {
            Log::warning('JobCategoryController@edit: Job category not found.');
            return $this->successJson('Category not found', 404);
        }
    } catch (\Exception $e) {
        Log::error('JobCategoryController@edit: An error occurred while fetching the job category details.', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return $this->errorJson('An error occurred while fetching the job category details.', 500);
    }
}

public function update(StoreJobCategory $request, $id = null)
{
    Log::info('JobCategoryController@update: Method execution started.');

    try {
        if (!auth()->user()->cans('edit_category')) {
            Log::warning('JobCategoryController@update: User not authenticated to perform this request.');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        if (!empty($id)) {
            $category = JobCategory::find($id);
            Log::info('JobCategoryController@update: Retrieved job category.', ['category' => $category]);

            if ($category) {
                $category->name = $request->name;
                $category->save();
                Log::info('JobCategoryController@update: Job category updated successfully.', ['category' => $category]);
                return $this->successJson('Job Category Updated Successfully', 200, $category);
            } else {
                Log::warning('JobCategoryController@update: Job category not found.');
                return $this->errorJson('Category not found', 404);
            }
        } else {
            Log::warning('JobCategoryController@update: Job category ID not provided.');
            return $this->errorJson('Data not found', 404);
        }
    } catch (\Exception $e) {
        Log::error('JobCategoryController@update: An error occurred while updating the job category.', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return $this->errorJson('An error occurred while updating the job category.', 500);
    }
}

public function destroy($id)
{
    try {
        Log::info('Attempting to delete job category', ['id' => $id]);
        
        if (!auth()->user()->cans('delete_category')) {
            Log::warning('User not authorized to delete category', ['user_id' => auth()->user()->id]);
            return $this->errorJson('Not authenticated to perform this request', 403);
        }
        
        if (empty($id)) {
            Log::error('Category ID is required');
            return $this->errorJson('Category ID is required', 422);
        }
        
        $deleted = JobCategory::destroy($id);
        if ($deleted) {
            Log::info('Job category deleted successfully', ['id' => $id]);
            return $this->successJson('Job Category Deleted Successfully', 200);
        } else {
            Log::warning('Job category could not be deleted', ['id' => $id]);
            return $this->errorJson('Job category could not be deleted', 500);
        }
    } catch (\Exception $e) {
        Log::error('An error occurred while deleting the job category', [
            'exception' => $e->getMessage(),
            'id' => $id
        ]);
        return $this->errorJson('An error occurred while deleting the job category.', 500);
    }
}

}