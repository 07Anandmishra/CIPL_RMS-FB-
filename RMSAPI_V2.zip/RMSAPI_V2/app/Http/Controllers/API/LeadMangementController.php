<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Role;
use App\RoleUser;
use App\User; 
use App\Jobassign; 
use Illuminate\Support\Facades\DB; 
use App\Mail\AssignLeadMail;
use Mail;
use App\Job; 
use App\Jobrecruitment;
use Illuminate\Support\Facades\Log; 

class LeadMangementController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    } 
 
    // public function leadDetails($id)
    // {
    //     try {
    //         $datalist = Jobassign::with(['leadassigned', 'transfer'])->where('jobrecruitment_id', $id)->get();
    //         return $this->successJson('Lead Details', 200, $datalist);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred while fetching lead details.', 500);
    //     }
    // }

    public function leadDetails($id)
{
    Log::info('JobCategoryController@leadDetails: Method execution started.', ['jobrecruitment_id' => $id]);

    try {
        $datalist = Jobassign::with(['leadassigned', 'transfer'])
            ->where('jobrecruitment_id', $id)
            ->get();
        Log::info('JobCategoryController@leadDetails: Retrieved lead details.', ['datalist' => $datalist]);

        return $this->successJson('Lead Details', 200, $datalist);
    } catch (\Exception $e) {
        Log::error('JobCategoryController@leadDetails: An error occurred while fetching lead details.', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return $this->errorJson('An error occurred while fetching lead details.', 500);
    }
}

    
    // public function assign(Request $request)
    // {

    //     $validator = Validator::make($request->all(), [
    //         'jobassigns'=>'required|array',
    //          'job_id'=>'required',
    //        'jobrecruitment_id'=>'required',
    //        ]);
    //     if ($validator->fails()) {
    //         return response()->json(['error'=>$validator->errors()], 422);
    //     }else{
    //           try {
    //             \DB::beginTransaction();   
    //             if(!is_null($request->jobassigns)){
    //                  $jobrecruitment = Jobrecruitment::where(['job_id'=>$request->job_id,'id'=>$request->jobrecruitment_id])->first();
  

    //                 $jobrecruitment->status = 1;
    //                 $jobrecruitment->assign_id = auth()->user()->id;	
    //                 $jobrecruitment->save();
    //                  foreach($request->jobassigns as $key=>$value) {  
                   
    //                     $jobassign=new Jobassign;
    //                      $jobassign->job_id=$request->job_id; 
    //                     $jobassign->jobrecruitment_id=$request->jobrecruitment_id;
    //                     $jobassign->assign_id = auth()->user()->id;	
    //                     $jobassign->position = $value['no_of_possition'];	
    //                     $jobassign->status = 'Fresh Lead';
    //                     $jobassign->user_id=$value['user_id'];	
    //                     $jobassign->save();
    //                     $user=User::where('id',$value['user_id'])->first();
    //                     $myEmail = $user->email;
    //                     $details = [
    //                         'title' => 'Lead assign',
    //                         'url' => config('app.AppBaseURL')
    //                     ];   
    //                    Mail::to($myEmail)->send(new AssignLeadMail($details));
          
    //                 }
    //             }
    //              \DB::commit();
    //           // $jobrecruitment = Jobrecruitment::with(['category','skills','qualification','subqualifications','replacements','anycertification','assignedetails'])->where(['job_id'=>$request->job_id,'id'=>$request->Jobrecruitment_id])->first();
    //             return $this->successJson('Lead Assigned Successfully',200);
    //         }catch (Exception $e) {
    //             \DB::rollBack();
    //             return $this->errorJson('something else wrong',403,$e);
    //         }

    //     }
    //  }

    public function assign(Request $request)
    {
        Log::info('JobCategoryController@assign: Method execution started.', ['request' => $request->all()]);
    
        $validator = Validator::make($request->all(), [
            'jobassigns' => 'required|array',
            'job_id' => 'required',
            'jobrecruitment_id' => 'required',
        ]);
    
        if ($validator->fails()) {
            Log::warning('JobCategoryController@assign: Validation failed.', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 422);
        }
    
        try {
            \DB::beginTransaction();
            Log::info('JobCategoryController@assign: Transaction started.');
    
            if (!is_null($request->jobassigns)) {
                Log::info('JobCategoryController@assign: Processing job assignments.', ['jobassigns' => $request->jobassigns]);
    
                $jobrecruitment = Jobrecruitment::where(['job_id' => $request->job_id, 'id' => $request->jobrecruitment_id])->first();
                Log::info('JobCategoryController@assign: Jobrecruitment fetched.', ['jobrecruitment' => $jobrecruitment]);
    
                $jobrecruitment->status = 1;
                $jobrecruitment->assign_id = auth()->user()->id;
                $jobrecruitment->save();
                Log::info('JobCategoryController@assign: Jobrecruitment updated and saved.', ['jobrecruitment' => $jobrecruitment]);
    
                foreach ($request->jobassigns as $key => $value) {
                    Log::info('JobCategoryController@assign: Processing job assign.', ['jobassign' => $value]);
    
                    $jobassign = new Jobassign;
                    $jobassign->job_id = $request->job_id;
                    $jobassign->jobrecruitment_id = $request->jobrecruitment_id;
                    $jobassign->assign_id = auth()->user()->id;
                    $jobassign->position = $value['no_of_possition'];
                    $jobassign->status = 'Fresh Lead';
                    $jobassign->user_id = $value['user_id'];
                    $jobassign->save();
                    Log::info('JobCategoryController@assign: Jobassign saved.', ['jobassign' => $jobassign]);
    
                    $user = User::where('id', $value['user_id'])->first();
                    $myEmail = $user->email;
                    $details = [
                        'title' => 'Lead assign',
                        'url' => config('app.AppBaseURL')
                    ];
                    Mail::to($myEmail)->send(new AssignLeadMail($details));
                    Log::info('JobCategoryController@assign: Email sent to user.', ['email' => $myEmail, 'details' => $details]);
                }
            }
    
            \DB::commit();
            Log::info('JobCategoryController@assign: Transaction committed.');
            return $this->successJson('Lead Assigned Successfully', 200);
        } catch (Exception $e) {
            \DB::rollBack();
            Log::error('JobCategoryController@assign: An error occurred.', ['exception' => $e]);
            return $this->errorJson('something else wrong', 403, $e);
        }
    }
    

    //  public function transfer(Request $request, $id)
    //  {
    //      try {
    //          $validator = Validator::make($request->all(), [
    //              'user_id' => 'required',
    //              'no_of_possition' => 'required'
    //          ]);
    //          if ($validator->fails()) {
    //              return response()->json(['error' => $validator->errors()], 422);
    //          } else {
    //              $datalist = Jobassign::find($id);
    //              $totallead = $datalist->position;
    //              //update lead 
    //              if ($totallead >= $request->no_of_possition) {
    //                  $datalist->position = $totallead - $request->no_of_possition;
    //                  $datalist->status = 'Transfer Lead';
    //                  $datalist->transfer = $request->user_id;
    //                  $datalist->save();
    //              } else {
    //                  // Handle case where requested number of positions exceeds total lead positions
    //              }
     
    //              $jobassign = new Jobassign;
    //              $jobassign->job_id = $datalist->job_id;
    //              $jobassign->jobrecruitment_id = $datalist->jobrecruitment_id;
    //              $jobassign->assign_id = auth()->user()->id;
    //              $jobassign->position = $request->no_of_possition;
    //              $jobassign->status = 'Fresh Lead';
    //              $jobassign->user_id = $request->user_id;
    //              $jobassign->save();
     
    //              $user = User::where('id', $request->user_id)->first();
    //              $myEmail = $user->email;
    //              $details = [
    //                  'title' => 'Lead assign',
    //                  'url' => config('app.AppBaseURL')
    //              ];
    //              Mail::to($myEmail)->send(new AssignLeadMail($details));
     
    //              return $this->successJson('Lead Transfer successfully', 200, $datalist);
    //          }
    //      } catch (\Exception $e) {
    //          return $this->errorJson('An error occurred while transferring the lead.', 500);
    //      }
    //  }

    public function transfer(Request $request, $id)
{
    Log::info('JobCategoryController@transfer: Method execution started.', ['request' => $request->all(), 'id' => $id]);

    try {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
            'no_of_possition' => 'required'
        ]);
        Log::info('JobCategoryController@transfer: Validation completed.', ['validation' => $validator->passes()]);

        if ($validator->fails()) {
            Log::warning('JobCategoryController@transfer: Validation failed.', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        $datalist = Jobassign::find($id);
        Log::info('JobCategoryController@transfer: Jobassign fetched.', ['datalist' => $datalist]);

        if (!$datalist) {
            Log::error('JobCategoryController@transfer: Jobassign not found.', ['id' => $id]);
            return $this->errorJson('Jobassign not found', 404);
        }

        $totallead = $datalist->position;
        Log::info('JobCategoryController@transfer: Total lead positions.', ['totallead' => $totallead]);

        // Update lead
        if ($totallead >= $request->no_of_possition) {
            $datalist->position = $totallead - $request->no_of_possition;
            $datalist->status = 'Transfer Lead';
            $datalist->transfer = $request->user_id;
            $datalist->save();
            Log::info('JobCategoryController@transfer: Updated Jobassign.', ['datalist' => $datalist]);
        } else {
            Log::warning('JobCategoryController@transfer: Requested positions exceed total lead positions.', [
                'requested' => $request->no_of_possition,
                'totallead' => $totallead
            ]);
            return $this->errorJson('Requested number of positions exceeds total lead positions', 422);
        }

        $jobassign = new Jobassign;
        $jobassign->job_id = $datalist->job_id;
        $jobassign->jobrecruitment_id = $datalist->jobrecruitment_id;
        $jobassign->assign_id = auth()->user()->id;
        $jobassign->position = $request->no_of_possition;
        $jobassign->status = 'Fresh Lead';
        $jobassign->user_id = $request->user_id;
        $jobassign->save();
        Log::info('JobCategoryController@transfer: New Jobassign saved.', ['jobassign' => $jobassign]);

        $user = User::where('id', $request->user_id)->first();
        $myEmail = $user->email;
        $details = [
            'title' => 'Lead assign',
            'url' => config('app.AppBaseURL')
        ];
        Mail::to($myEmail)->send(new AssignLeadMail($details));
        Log::info('JobCategoryController@transfer: Email sent to user.', ['email' => $myEmail, 'details' => $details]);

        return $this->successJson('Lead Transfer successfully', 200, $datalist);
    } catch (\Exception $e) {
        Log::error('JobCategoryController@transfer: An error occurred.', ['exception' => $e]);
        return $this->errorJson('An error occurred while transferring the lead.', 500);
    }
}

     

// public function assign1(Request $request)
// {
//         $validator = Validator::make($request->all(), [
//            'job_id' => 'required',
//            'user_id' => 'required',
//            'Jobrecruitment_id'     =>'required',
//            ]);
//         if ($validator->fails()) {
//             return response()->json(['error'=>$validator->errors()], 422);
//         }else{
//   //return $this->successJson('Job Assign successfully',200,$request->all());

//             try {

//                 \DB::beginTransaction();
              
//              $jobrecruitment = Jobrecruitment::with(['category','skills','qualification','subqualifications','replacements','anycertification','assignBy','assigned'])->where(['job_id'=>$request->job_id,'id'=>$request->Jobrecruitment_id])->first();
//                 $jobrecruitment->status = 1;
// 		$jobrecruitment->assign_id = $request->user_id;
//                 $jobrecruitment->user_id=auth()->user()->id;		
//                 $jobrecruitment->save();
//                 $user=User::where('id',$request->user_id)->first();
//                 $myEmail = $user->email;
//                 $details = [
//                     'title' => 'Lead assign',
//                     'url' =>  config('app.AppBaseURL')
//                 ];   
//                Mail::to($myEmail)->send(new AssignLeadMail($details));
//                \DB::commit();
//                 return $this->successJson('Job Assign successfully',200,$jobrecruitment);
//             }catch (Exception $e) {
//                 \DB::rollBack();
//                 return $this->errorJson('something else wrong',403,$e);
//             }

//         }
//      }

public function assign1(Request $request)
{
    Log::info('JobCategoryController@assign1: Method execution started.', ['request' => $request->all()]);

    $validator = Validator::make($request->all(), [
        'job_id' => 'required',
        'user_id' => 'required',
        'Jobrecruitment_id' => 'required',
    ]);
    Log::info('JobCategoryController@assign1: Validation completed.', ['validation' => $validator->passes()]);

    if ($validator->fails()) {
        Log::warning('JobCategoryController@assign1: Validation failed.', ['errors' => $validator->errors()]);
        return response()->json(['error' => $validator->errors()], 422);
    } else {
        try {
            \DB::beginTransaction();
            Log::info('JobCategoryController@assign1: Transaction started.');

            $jobrecruitment = Jobrecruitment::with([
                'category', 'skills', 'qualification', 'subqualifications', 
                'replacements', 'anycertification', 'assignBy', 'assigned'
            ])->where([
                'job_id' => $request->job_id,
                'id' => $request->Jobrecruitment_id
            ])->first();
            Log::info('JobCategoryController@assign1: Jobrecruitment fetched.', ['jobrecruitment' => $jobrecruitment]);

            if (!$jobrecruitment) {
                Log::error('JobCategoryController@assign1: Jobrecruitment not found.', ['job_id' => $request->job_id, 'Jobrecruitment_id' => $request->Jobrecruitment_id]);
                \DB::rollBack();
                return $this->errorJson('Jobrecruitment not found', 404);
            }

            $jobrecruitment->status = 1;
            $jobrecruitment->assign_id = $request->user_id;
            $jobrecruitment->user_id = auth()->user()->id;
            $jobrecruitment->save();
            Log::info('JobCategoryController@assign1: Jobrecruitment updated.', ['jobrecruitment' => $jobrecruitment]);

            $user = User::where('id', $request->user_id)->first();
            Log::info('JobCategoryController@assign1: User fetched.', ['user' => $user]);

            if (!$user) {
                Log::error('JobCategoryController@assign1: User not found.', ['user_id' => $request->user_id]);
                \DB::rollBack();
                return $this->errorJson('User not found', 404);
            }

            $myEmail = $user->email;
            $details = [
                'title' => 'Lead assign',
                'url' => config('app.AppBaseURL')
            ];
            Mail::to($myEmail)->send(new AssignLeadMail($details));
            Log::info('JobCategoryController@assign1: Email sent to user.', ['email' => $myEmail, 'details' => $details]);

            \DB::commit();
            Log::info('JobCategoryController@assign1: Transaction committed.');

            return $this->successJson('Job Assign successfully', 200, $jobrecruitment);
        } catch (Exception $e) {
            Log::error('JobCategoryController@assign1: An error occurred.', ['exception' => $e]);
            \DB::rollBack();
            return $this->errorJson('Something went wrong, please try again.', 500, $e->getMessage());
        }
    }
}



//     public function assignold(Request $request){
//         $validator = Validator::make($request->all(), [
//            'job_id' => 'required',
//             'user_id' => 'required',
//            ]);
//         if ($validator->fails()) {
//             return response()->json(['error'=>$validator->errors()], 422);
//         }else{
//   //return $this->successJson('Job Assign successfully',200,$request->all());

//             try {

//                 \DB::beginTransaction();
//                /* $jobassign = new Jobassign();
//                 $jobassign->job_id = $request->job_id;
//                 $jobassign->user_id = $request->user_id;
		
//                 $jobassign->save(); */
//                 $job = Job::where(['status'=>'1','id'=>$request->job_id])->first();
//                   $job->status = 3;
// 		$job->assign_id = $request->user_id;		
//                   $job->save();

//                 $user=User::where('id',$request->user_id)->first();
//                 $myEmail = $user->email;
//                 $details = [
//                     'title' => 'Lead assign',
//                     'url' =>  config('app.AppBaseURL')
//                 ];   
//                Mail::to($myEmail)->send(new AssignLeadMail($details));
//                \DB::commit();
//                 return $this->successJson('Job Assign successfully',200,$user);
//             }catch (Exception $e) {
//                 \DB::rollBack();
//                 return $this->errorJson('something else wrong',403,$e);
//             }

//         }
//      }

public function assignold(Request $request)
{
    Log::info('JobCategoryController@assignold: Method execution started.', ['request' => $request->all()]);

    $validator = Validator::make($request->all(), [
        'job_id' => 'required',
        'user_id' => 'required',
    ]);
    Log::info('JobCategoryController@assignold: Validation completed.', ['validation' => $validator->passes()]);

    if ($validator->fails()) {
        Log::warning('JobCategoryController@assignold: Validation failed.', ['errors' => $validator->errors()]);
        return response()->json(['error' => $validator->errors()], 422);
    } else {
        try {
            \DB::beginTransaction();
            Log::info('JobCategoryController@assignold: Transaction started.');

            $job = Job::where(['status' => '1', 'id' => $request->job_id])->first();
            Log::info('JobCategoryController@assignold: Job fetched.', ['job' => $job]);

            if (!$job) {
                Log::error('JobCategoryController@assignold: Job not found or not in required status.', ['job_id' => $request->job_id]);
                \DB::rollBack();
                return $this->errorJson('Job not found or not in required status', 404);
            }

            $job->status = 3;
            $job->assign_id = $request->user_id;
            $job->save();
            Log::info('JobCategoryController@assignold: Job updated.', ['job' => $job]);

            $user = User::where('id', $request->user_id)->first();
            Log::info('JobCategoryController@assignold: User fetched.', ['user' => $user]);

            if (!$user) {
                Log::error('JobCategoryController@assignold: User not found.', ['user_id' => $request->user_id]);
                \DB::rollBack();
                return $this->errorJson('User not found', 404);
            }

            $myEmail = $user->email;
            $details = [
                'title' => 'Lead assign',
                'url' => config('app.AppBaseURL')
            ];
            Mail::to($myEmail)->send(new AssignLeadMail($details));
            Log::info('JobCategoryController@assignold: Email sent to user.', ['email' => $myEmail, 'details' => $details]);

            \DB::commit();
            Log::info('JobCategoryController@assignold: Transaction committed.');

            return $this->successJson('Job Assign successfully', 200, $user);
        } catch (Exception $e) {
            Log::error('JobCategoryController@assignold: An error occurred.', ['exception' => $e]);
            \DB::rollBack();
            return $this->errorJson('Something went wrong, please try again.', 500, $e->getMessage());
        }
    }
}


// public function linkget($id){
        
//         try {
               
//             $erflist = Job::with(['department'])->where(['status'=>'2','erf_id'=>$id])->first();
//             $jobrecruitment=Jobrecruitment::with(['category','skills','qualification','subqualifications','replacements','anycertification','jd'])->where('job_id',$erflist->id)->get();
           
//                if($erflist){
//                 $data=['erfgroup'=>$erflist,
//                         'jobrecruitment'=>$jobrecruitment,
//                ];
//                    return $this->successJson('ERf approval link',200,$data);
//                }else{
//                    return $this->errorJson('Already Approved',403);
//                }
               
//                 }catch (\Throwable $th) {
                    
//                     return $this->errorJson('ERF not founds',404,$th);
//         }
     
//     }  

public function linkget($id)
{
    Log::info('JobCategoryController@linkget: Method execution started.', ['id' => $id]);

    try {
        $erflist = Job::with(['department','jobCategory'])->where(['status' => 'waiting for approval', 'erf_id' => $id])->first();
       // echo $erflist;
        Log::info('JobCategoryController@linkget: ERF list fetched.', ['erflist' => $erflist]);

        if ($erflist) {
            $jobrecruitment = Jobrecruitment::with(['jobCategory', 'skills', 'qualification', 'subqualifications', 'replacements', 'anycertification', 'jd'])
                ->where('job_id', $erflist->id)
                ->get();
            Log::info('JobCategoryController@linkget: Job recruitment details fetched.', ['jobrecruitment' => $jobrecruitment]);

            $data = [
                'erfgroup' => $erflist,
                'jobrecruitment' => $jobrecruitment,
            ];

            Log::info('JobCategoryController@linkget: Data prepared for response.', ['data' => $data]);
            return $this->successJson('ERF approval link', 200, $data);
        } else {
            Log::warning('JobCategoryController@linkget: ERF already approved or not found.', ['id' => $id]);
            return $this->errorJson('Already Approved', 403);
        }
    } catch (\Throwable $th) {
        Log::error('JobCategoryController@linkget: An error occurred.', ['exception' => $th]);
        return $this->errorJson('ERF not found', 404, $th);
    }
}


    // public function approved_by(Request $request,$id){
      
    //         try {
    //             \DB::beginTransaction();
    //             $job = Job::where(['erf_id'=>$id])->first();
    //             if($job){
    //                 $job->status = $request->status;
    //                 $job->note=$request->note;
    //                 $job->save();
    //                 \DB::commit();
    //                 return $this->successJson('Job Approved',200);
    //             }else{
    //                 return $this->errorJson('oops something else wrong',$job);
    //             }
                
    //         }catch (\Throwable $th) {
    //             \DB::rollBack();
    //             return $this->errorJson('something else wrong',403,$th);
    //         }
    // }
    public function approved_by(Request $request, $id)
{
    Log::info('JobCategoryController@approved_by: Method execution started.', ['id' => $id]);

    try {
        \DB::beginTransaction();
        Log::info('JobCategoryController@approved_by: Database transaction started.');

        $job = Job::where(['erf_id' => $id])->first();
        Log::info('JobCategoryController@approved_by: Job fetched by erf_id.', ['job' => $job]);

        if ($job) {
            $job->status = $request->status;
            $job->note = $request->note;
            Log::info('JobCategoryController@approved_by: Job status and note updated.', ['status' => $request->status, 'note' => $request->note]);

            $job->save();
            Log::info('JobCategoryController@approved_by: Job saved.', ['job' => $job]);

            \DB::commit();
            Log::info('JobCategoryController@approved_by: Database transaction committed.');

            return $this->successJson('Job Approved', 200);
        } else {
            Log::warning('JobCategoryController@approved_by: Job not found for given erf_id.', ['erf_id' => $id]);
            return $this->errorJson('Job not found', 404);
        }
    } catch (\Throwable $th) {
        \DB::rollBack();
        Log::error('JobCategoryController@approved_by: An error occurred.', ['exception' => $th]);

        return $this->errorJson('Something else went wrong', 403, $th);
    }
}


}
