<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\User;
use App\JobLocation;
use Illuminate\Support\Facades\Log;

class LocationController extends Controller
{
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }

    // public function index()
    // {
    //     try {
    //         if(!auth()->user()->cans('view_locations')){
    //             return $this->errorJson('Not authenticated to perform this request',403);
    //         } else {
    //             $locations = JobLocation::all();
    //             if(!empty($locations)) {
    //                 return $this->successJson('Location Details',200,$locations);
    //             } else {
    //                 return $this->errorJson('not found Details',404);
    //             }
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    public function index()
    {
        Log::info('JobCategoryController@index: Method execution started.');
    
        try {
            if (!auth()->user()->cans('view_locations')) {
                Log::warning('JobCategoryController@index: User is not authorized to view locations.', ['user_id' => auth()->user()->id]);
                return $this->errorJson('Not authenticated to perform this request', 403);
            } else {
                Log::info('JobCategoryController@index: User is authorized to view locations.', ['user_id' => auth()->user()->id]);
    
                $locations = JobLocation::all();
                Log::info('JobCategoryController@index: Job locations fetched.', ['locations_count' => $locations->count()]);
    
                if ($locations->isNotEmpty()) {
                    Log::info('JobCategoryController@index: Job locations found.', ['locations' => $locations]);
                    return $this->successJson('Location Details', 200, $locations);
                } else {
                    Log::info('JobCategoryController@index: No job locations found.');
                    return $this->errorJson('Not found details', 404);
                }
            }
        } catch (\Exception $e) {
            Log::error('JobCategoryController@index: An error occurred.', ['exception' => $e]);
            return $this->errorJson('An error occurred', 500);
        }
    }
    


}
