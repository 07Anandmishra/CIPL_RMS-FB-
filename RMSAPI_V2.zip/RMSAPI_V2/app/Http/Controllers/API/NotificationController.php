<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Certification;
use App\Http\Requests\StoreCertification;
use App\Http\Requests\UpdateCertification;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class NotificationController extends Controller
{


    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }


    // public function unread(Request $request){
    //     $res = [
    //         'unread' => auth()->user()->unreadnotifications,
    //         'read' => auth()->user()->notifications()->whereNotNull('read_at')->get(),
    //     ];
        
    //         return $this->successJson('Qualification Details',200,$res);
        
    // }

    public function unread(Request $request)
{
    Log::info('NotificationController@unread: Method execution started.');

    try {
        Log::info('NotificationController@unread: Fetching unread notifications for user.', ['user_id' => auth()->user()->id]);
        $unreadNotifications = auth()->user()->unreadNotifications;

        Log::info('NotificationController@unread: Fetching read notifications for user.', ['user_id' => auth()->user()->id]);
        $readNotifications = auth()->user()->notifications()->whereNotNull('read_at')->get();

        $res = [
            'unread' => $unreadNotifications,
            'read' => $readNotifications,
        ];

        return $this->successJson('Notification Details', 200, $res);

    } catch (\Exception $e) {
        Log::error('NotificationController@unread: An error occurred while fetching notifications.', ['exception' => $e]);
        return $this->errorJson('An error occurred', 500);
    }
}


    // public function index()
    // {
    //     try {
    //         $categories = Certification::with('skill')->get();
    
    //         if ($categories->isEmpty()) {
    //             return $this->successJson('No categories found', 200, $categories);
    //         } else {
    //             return $this->successJson('Certification Details', 200, $categories);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500, $e->getMessage());
    //     }
    // }
    public function index()
{
    try {
        Log::info('CertificationController@index: Method execution started.');

        // Fetching certification categories with associated skills
        Log::info('CertificationController@index: Fetching certification categories with skills.');
        $categories = Certification::with('skill')->orderby('name','asc')->get();

        if ($categories->isEmpty()) {
            Log::info('CertificationController@index: No certification categories found.');
            return $this->successJson('No categories found', 200, $categories);
        } else {
            Log::info('CertificationController@index: Certification categories found.', ['count' => $categories->count()]);
            return $this->successJson('Certification Details', 200, $categories);
        }
    } catch (\Exception $e) {
        Log::error('CertificationController@index: An error occurred', ['exception' => $e]);
        return $this->errorJson('An error occurred', 500, $e->getMessage());
    }
}

    

    // public function index1()
    // {
    //     try {
    //         $categories = Certification::all();
    //         if(!empty($categories)) {
    //             return $this->successJson('Certification Details', 200, $categories);
    //         } else {
    //             return $this->successJson('not found Details', 200, $categories);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    
    public function index1()
{
    try {
        Log::info('CertificationController@index1: Method execution started.');

        // Fetch all certification categories
        Log::info('CertificationController@index1: Fetching all certification categories.');
        $categories = Certification::all();

        if ($categories->isEmpty()) {
            Log::info('CertificationController@index1: No certification categories found.');
            return $this->successJson('No categories found', 200, $categories);
        } else {
            Log::info('CertificationController@index1: Certification categories found.', ['count' => $categories->count()]);
            return $this->successJson('Certification Details', 200, $categories);
        }
    } catch (\Exception $e) {
        Log::error('CertificationController@index1: An error occurred', ['exception' => $e]);
        return $this->errorJson('An error occurred', 500);
    }
}


   
    
    
    // public function add(Request $request)
    // {
    //     try {
    //         if (!auth()->user()->cans('add_category')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }

    //         $validator = Validator::make($request->all(), [
    //             'name' => 'required|unique:certifications',
    //             'skill_id' => 'required|exists:skills,id', // Ensure skill_id is provided and exists in the skills table
    //         ]);

    //         if ($validator->fails()) {
    //             return response()->json(['error' => $validator->errors()], 422);
    //         }

    //         $category = Certification::create([
    //             'name' => $request->name,
    //             'skill_id' => $request->skill_id, // Save the skill_id
    //         ]);

    //         if ($category) {
    //             return $this->successJson('Certification Added Successfully', 200, $category);
    //         } else {
    //             return $this->successJson('Something went wrong', 200);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500, $e->getMessage());
    //     }
    // }

    public function add(Request $request)
{
    try {
        Log::info('Starting to add certification...');

        // Check if user is authorized to add a category
        if (!auth()->user()->cans('add_category')) {
            Log::warning('User not authorized to perform this request');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        Log::info('User authorized to add certification');

        // Validate incoming request data
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:certifications',
            'skill_id' => 'required|exists:skills,id', // Ensure skill_id is provided and exists in the skills table
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        Log::info('Validation successful');

        // Create a new certification category
        $category = Certification::create([
            'name' => $request->name,
            'skill_id' => $request->skill_id, // Save the skill_id
        ]);

        if ($category) {
            Log::info('Certification added successfully', ['category' => $category->toArray()]);
            return $this->successJson('Certification Added Successfully', 200, $category);
        } else {
            Log::error('Failed to add certification');
            return $this->errorJson('Failed to add certification', 500);
        }
    } catch (\Exception $e) {
        Log::error('An error occurred', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred', 500, $e->getMessage());
    }
}




    // public function addold(StoreCertification $request){
    //     if(!auth()->user()->cans('add_category')){
    //         return $this->errorJson('Not authenticated to perform this request',403);
    //     }else{
    //     $category=Certification::create(['name' => $request->name]);
    //     if(!empty($category)){
    //         return $this->successJson('Certification Added Successfully',200,$category);
    //     }else{
    //         return $this->successJson('something else wrong',200);
    //     }
    //    }
    // }
    public function addold(StoreCertification $request)
{
    try {
        Log::info('Starting to add certification...');

        // Check if user is authorized to add a category
        if (!auth()->user()->cans('add_category')) {
            Log::warning('User not authorized to perform this request');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        Log::info('User authorized to add certification');

        // Create a new certification category
        $category = Certification::create(['name' => $request->name]);

        if (!empty($category)) {
            Log::info('Certification added successfully', ['category' => $category->toArray()]);
            return $this->successJson('Certification Added Successfully', 200, $category);
        } else {
            Log::error('Failed to add certification');
            return $this->errorJson('Failed to add certification', 500);
        }
    } catch (\Exception $e) {
        Log::error('An error occurred', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred', 500, $e->getMessage());
    }
}



    // public function edit(StoreCertification $request, $id = null)
    // {
    //     try {
    //         if (!auth()->user()->cans('edit_category')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }

    //         $category = Certification::find($id);
    //         if (!empty($category)) {
    //             return $this->successJson('Details', 200, $category);
    //         } else {
    //             return $this->successJson('Category not found', 200);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }

    public function edit(StoreCertification $request, $id = null)
{
    try {
        Log::info('Starting certification edit process...');

        // Check if user is authorized to edit categories
        if (!auth()->user()->cans('edit_category')) {
            Log::warning('User not authorized to perform edit request');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        Log::info('User authorized to edit certification');

        // Find the certification category by ID
        $category = Certification::find($id);

        if (!empty($category)) {
            Log::info('Certification details retrieved', ['category' => $category->toArray()]);
            return $this->successJson('Certification Details', 200, $category);
        } else {
            Log::info('Certification not found', ['category_id' => $id]);
            return $this->successJson('Category not found', 404);
        }
    } catch (\Exception $e) {
        Log::error('An error occurred', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred', 500, $e->getMessage());
    }
}

    // public function update(UpdateCertification $request, $id = null)
    // {
    //     try {
    //         if (!auth()->user()->cans('edit_category')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }
    
    //         if (!empty($id)) {
    //             $category = Certification::find($id);
    //             if ($category) {
    //                 $category->name = $request->name;
    //                 $category->save();
    //                 return $this->successJson('Certification Updated Successfully', 200, $category);
    //             } else {
    //                 return $this->errorJson('Category not found', 404);
    //             }
    //         } else {
    //             return $this->successJson('Category ID not provided', 200);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    
    public function update(UpdateCertification $request, $id = null)
{
    try {
        Log::info('Starting certification update process...');

        // Check if user is authorized to edit categories
        if (!auth()->user()->cans('edit_category')) {
            Log::warning('User not authorized to perform update request');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        Log::info('User authorized to update certification');

        // Check if ID is provided
        if (!empty($id)) {
            Log::info('Certification ID provided', ['category_id' => $id]);

            // Find the certification category by ID
            $category = Certification::find($id);

            if ($category) {
                Log::info('Certification found for update', ['category' => $category->toArray()]);

                // Update certification name
                $category->name = $request->name;
                $category->save();

                Log::info('Certification updated successfully', ['category' => $category->toArray()]);
                return $this->successJson('Certification Updated Successfully', 200, $category);
            } else {
                Log::info('Certification not found', ['category_id' => $id]);
                return $this->errorJson('Category not found', 404);
            }
        } else {
            Log::info('Certification ID not provided');
            return $this->successJson('Category ID not provided', 200);
        }
    } catch (\Exception $e) {
        Log::error('An error occurred', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred', 500, $e->getMessage());
    }
}

    // public function destroy($id)
    // {
    //     try {
    //         if (!auth()->user()->cans('delete_category')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }

    //         Certification::destroy($id);
    //         return $this->successJson('Certification Delete Successfully', 200);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    public function destroy($id)
{
    try {
        Log::info('Starting certification deletion process...');

        // Check if user is authorized to delete categories
        if (!auth()->user()->cans('delete_category')) {
            Log::warning('User not authorized to perform deletion request');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        Log::info('User authorized to delete certification');

        // Attempt to delete the certification by ID
        Certification::destroy($id);

        Log::info('Certification deleted successfully', ['certification_id' => $id]);
        return $this->successJson('Certification Delete Successfully', 200);
    } catch (\Exception $e) {
        Log::error('An error occurred', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred', 500);
    }
}


}
