<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Offerletter;
use DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;

use Illuminate\Validation\Rule;
class OfferletterController extends Controller
{
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }
  
    // public function index()
    // {
    //     try {
    //         $jd = Offerletter::get();
    //         if ($jd) {
    //             return $this->successJson('Offer Letter List', 200, $jd);
    //         } else {
    //             return $this->errorJson('Data not founds', 404);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    
    public function index()
{
    try {
        Log::info('Fetching offer letter list...');

        // Retrieve all offer letters
        $offerLetters = Offerletter::get();

        if ($offerLetters->isEmpty()) {
            Log::warning('No offer letters found');
            return $this->errorJson('Data not found', 404);
        }

        Log::info('Offer letter list retrieved successfully');

        return $this->successJson('Offer Letter List', 200, $offerLetters);
    } catch (\Exception $e) {
        Log::error('An error occurred while fetching offer letters', ['exception' => $e->getMessage()]);
        return $this->errorJson('An error occurred', 500);
    }
}

    // public function store(Request $request){
        
        
    //     $validator = Validator::make($request->all(), [
    //         'templatename' => 'required|unique:offerletters',
    //         'contents' => 'required',
             
            
            
    //     ]);
    //     if ($validator->fails()) {
    //         return response()->json(['error'=>$validator->errors()], 422);
    //     }
    //     try{
    //         \DB::beginTransaction();
    //         $offer=new Offerletter;
    //         if($request->hasFile('signature')) {
    //         $path = public_path('signature/');
    //         if(!File::isDirectory($path)) {
    //             File::makeDirectory($path, 0777, true, true);
    //         }
    //         $image = $request->file('signature');
    //         $name = time().'.'.$image->getClientOriginalExtension();            
    //         $image->move($path, $name);
    //         $offer->signature='public/signature/'.$name;
    //        }

    //         $offer->templatename=$request->templatename;
    //         $offer->contents=$request->contents;            
    //         $offer->save();                          
    //         \DB::commit();
    //         return $this->successJson('Offer Letter Saved Successfully',200,$offer);
    //     }
    //     catch (\Exception $e) {
    //         \DB::rollBack();
    //         return $this->errorJson('oops something went wrong please try again',500,$e->getMessage());
    //     }

    // }

    public function store(Request $request)
    {
        try {
            Log::info('Starting to store offer letter...');
    
            // Validate incoming request data
            $validator = Validator::make($request->all(), [
                'templatename' => 'required|unique:offerletters',
                'contents' => 'required',
                // Add validation rules for other fields if needed
            ]);
    
            if ($validator->fails()) {
                Log::error('Validation failed while storing offer letter', ['errors' => $validator->errors()]);
                return response()->json(['error' => $validator->errors()], 422);
            }
    
            \DB::beginTransaction();
    
            // Create new instance of Offerletter
            $offer = new Offerletter;
    
            // Handle file upload for signature if present
            if ($request->hasFile('signature')) {
                $path = public_path('signature/');
                if (!File::isDirectory($path)) {
                    File::makeDirectory($path, 0777, true, true);
                }
                $image = $request->file('signature');
                $name = time() . '.' . $image->getClientOriginalExtension();
                $image->move($path, $name);
                $offer->signature = 'public/signature/' . $name;
    
                Log::info('Signature uploaded successfully');
            }
    
            // Assign values from request to offer letter object
            $offer->templatename = $request->templatename;
            $offer->contents = $request->contents;
    
            // Save offer letter object
            $offer->save();
    
            \DB::commit();
    
            Log::info('Offer Letter Saved Successfully', ['offer_letter' => $offer]);
    
            return $this->successJson('Offer Letter Saved Successfully', 200, $offer);
        } catch (\Exception $e) {
            \DB::rollBack();
    
            Log::error('An error occurred while storing offer letter', [
                'message' => $e->getMessage(),
                'trace' => $e->getTrace()
            ]);
    
            return $this->errorJson('Oops something went wrong. Please try again.', 500, $e->getMessage());
        }
    }
    

//   public function update(Request $request,$id){
//         $validator = Validator::make($request->all(), [
//             'templatename' => ['required',Rule::unique('offerletters')->ignore($id)],
//             'contents' => 'required',
//             ]);
//         if ($validator->fails()) {
//             return response()->json(['error'=>$validator->errors()], 422);
//         }
//         try{
//             \DB::beginTransaction();
//             $jd=Offerletter::find($id);

//             if(empty($jd)){
//                 return $this->errorJson('not found Details',404);
//             }else{
                
//                 $jd->templatename=$request->templatename;
//                 $jd->contents=$request->contents;
//                  if($request->hasFile('signature')) {
//             $path = public_path('signature/');
//             if(!File::isDirectory($path)) {
//                 File::makeDirectory($path, 0777, true, true);
//             }
//             $image = $request->file('signature');
//             $name = time().'.'.$image->getClientOriginalExtension();            
//             $image->move($path, $name);
//             $jd->signature='public/signature/'.$name;
//            }

//                 $jd->save();                          
//                 \DB::commit();
//                 return $this->successJson('Offer Letter Updated Successfully',200,$jd);
//             }
//         }
//         catch (\Exception $e) {
//             \DB::rollBack();
//             return $this->errorJson('oops something went wrong please try again',500,$e->getMessage());
//         }
//     }

public function update(Request $request, $id)
{
    try {
        Log::info('Starting to update offer letter...');

        // Validate incoming request data
        $validator = Validator::make($request->all(), [
            'templatename' => ['required', Rule::unique('offerletters')->ignore($id)],
            'contents' => 'required',
            // Add validation rules for other fields if needed
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed while updating offer letter', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        \DB::beginTransaction();

        // Retrieve the offer letter by ID
        $offer = Offerletter::find($id);

        if (empty($offer)) {
            Log::error('Offer letter not found', ['id' => $id]);
            return $this->errorJson('Offer letter not found', 404);
        }

        // Update offer letter fields from request
        $offer->templatename = $request->templatename;
        $offer->contents = $request->contents;

        // Handle file upload for signature if present
        if ($request->hasFile('signature')) {
            $path = public_path('signature/');
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }
            $image = $request->file('signature');
            $name = time() . '.' . $image->getClientOriginalExtension();
            $image->move($path, $name);
            $offer->signature = 'public/signature/' . $name;

            Log::info('Signature uploaded successfully');
        }

        // Save updated offer letter
        $offer->save();

        \DB::commit();

        Log::info('Offer Letter Updated Successfully', ['offer_letter' => $offer]);

        return $this->successJson('Offer Letter Updated Successfully', 200, $offer);
    } catch (\Exception $e) {
        \DB::rollBack();

        Log::error('An error occurred while updating offer letter', [
            'message' => $e->getMessage(),
            'trace' => $e->getTrace()
        ]);

        return $this->errorJson('Oops something went wrong. Please try again.', 500, $e->getMessage());
    }
}

    // public function delete($id)
    // {
    //     try {
    //         $validator = Validator::make(['id' => $id], [
    //             'id' => 'required|exists:offerletters,id',
    //         ]);

    //         if ($validator->fails()) {
    //             return response()->json(['error' => $validator->errors()], 422);
    //         }

    //         Offerletter::destroy($id);
    //         return $this->successJson('Offerletter Deleted Successfully', 200);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }

    public function delete($id)
{
    try {
        // Validate incoming request data
        $validator = Validator::make(['id' => $id], [
            'id' => 'required|exists:offerletters,id',
        ]);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        // Find and delete the offer letter by ID
        Offerletter::destroy($id);

        // Return success response if deletion is successful
        return $this->successJson('Offerletter Deleted Successfully', 200);
    } catch (\Exception $e) {
        // Handle any exceptions that occur during deletion
        return $this->errorJson('An error occurred', 500);
    }
}



}
