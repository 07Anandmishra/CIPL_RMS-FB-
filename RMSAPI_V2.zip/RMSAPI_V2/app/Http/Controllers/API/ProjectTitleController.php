<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use App\ProjectTitle;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\DB; 

class ProjectTitleController extends Controller
{

    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }

     // Display a listing of the resource.
    //  public function index()    
    // {
    //     try {
    //         $projectTitels = ProjectTitle::all();
            
    //         if($projectTitels->isEmpty())
    //         {
    //             return $this->errorJson('No Project Titles Found', 404);
    //         }
            
    //         return $this->successJson('Project Title Details', 200, $projectTitels);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Failed to fetch project titles', 500, $e->getMessage());
    //     }
    // }

    public function index()
{
    try {
        // Log that the index method is being accessed
        \Log::info('Accessing index method of ProjectTitleController');

        // Retrieve all project titles
        $projectTitles = ProjectTitle::orderby('title','asc')->get();

        // Log the number of project titles retrieved
        \Log::info('Retrieved ' . count($projectTitles) . ' project titles');

        // Check if project titles are empty
        if ($projectTitles->isEmpty()) {
            // Log that no project titles were found
            \Log::warning('No project titles found');

            return $this->errorJson('No Project Titles Found', 404);
        }

        // Log success message
        \Log::info('Successfully fetched project titles');

        // Return success response with project titles
        return $this->successJson('Project Title Details', 200, $projectTitles);

    } catch (\Exception $e) {
        // Log the exception
        \Log::error('Failed to fetch project titles: ' . $e->getMessage());

        // Handle exceptions that may occur during retrieval
        return $this->errorJson('Failed to fetch project titles', 500, $e->getMessage());
    }
}



 
     // Store a newly created resource in DataBase.
     public function store(Request $request)
    {
        try {
            // Log that the store method is being accessed
            \Log::info('Accessing store method of ProjectTitleController');
    
            // Validate the incoming request
            $validator = Validator::make($request->all(), [
                'title' => 'required|string|max:255|unique:projectTitle,title',
            ]);

            // Check if the title already exists
            $existingProjectTitle = ProjectTitle::where('title', $request->title)->first();
            
            // If the title exists and it's not the current project title, return an error
            if ($existingProjectTitle ) {
                return $this->errorJson('Title already exists', 409, null);
            }

            // Create a new project title
            $projectTitle = ProjectTitle::create([
                'title' => $request->title
            ]);

            return $this->successJson('Project Title Created Successfully', 201, $projectTitle);
        } catch (\Exception $e) {
            return $this->errorJson('Failed to create project title', 500, $e->getMessage());
        }
    }
    // public function store(Request $request)
    // {
    //     try {
    //         // Log that the store method is being accessed
    //         \Log::info('Accessing store method of ProjectTitleController');
    
    //         // Validate the incoming request
    //         $validator = Validator::make($request->all(), [
    //             'title' => 'required|string|max:255|unique:projecttitles,title',
    //         ]);
    
    //         // Check if validation fails
    //         if ($validator->fails()) {
    //             // Log validation errors
    //             \Log::error('Validation failed during project title creation', ['errors' => $validator->errors()]);
    //             return response()->json(['error' => $validator->errors()], 422);
    //         }
    
    //         // Check if the title already exists
    //         $existingProjectTitle = ProjectTitle::where('title', $request->title)->first();
    
    //         // If the title exists, return a conflict response
    //         if ($existingProjectTitle) {
    //             // Log title conflict
    //             \Log::warning('Project title already exists', ['title' => $request->title]);
    //             return $this->errorJson('Title already exists', 409);
    //         }
    
    //         // Create a new project title
    //         $projectTitle = ProjectTitle::create([
    //             'title' => $request->title
    //         ]);
    
    //         // Log successful creation of project title
    //         \Log::info('Project Title Created Successfully', ['project_title' => $projectTitle]);
    
    //         // Return success response with created project title
    //         return $this->successJson('Project Title Created Successfully', 201, $projectTitle);
    
    //     } catch (\Exception $e) {
    //         // Log exception if any error occurs
    //         \Log::error('Failed to create project title', ['exception' => $e]);
            
    //         // Return error response with appropriate message
    //         return $this->errorJson('Failed to create project title', 500, $e->getMessage());
    //     }
    // }

 
     // Display the specified resource.
   
    //  public function show($id)
    // {
    //     try {
    //         $projectTitel = ProjectTitle::find($id);

    //         if (!$projectTitel) {
    //             return $this->errorJson('Project Title Not Found', 404, null);
    //         }

    //         return $this->successJson('Project Title Retrieved Successfully', 200, $projectTitel);
    //     }catch (\Exception $e) {
    //         return $this->errorJson('Failed to retrieve project title', 500, $e->getMessage());
    //     }
    // }

    public function show($id)
{
    try {
        // Log that the show method is being accessed
        \Log::info('Accessing show method of ProjectTitleController');

        // Find the project title by ID
        $projectTitle = ProjectTitle::find($id);

        // If project title not found, return error response
        if (!$projectTitle) {
            // Log project title not found
            \Log::warning('Project Title Not Found', ['id' => $id]);
            return $this->errorJson('Project Title Not Found', 404);
        }

        // Log successful retrieval of project title
        \Log::info('Project Title Retrieved Successfully', ['project_title' => $projectTitle]);

        // Return success response with retrieved project title
        return $this->successJson('Project Title Retrieved Successfully', 200, $projectTitle);

    } catch (\Exception $e) {
        // Log exception if any error occurs
        \Log::error('Failed to retrieve project title', ['exception' => $e]);

        // Return error response with appropriate message
        return $this->errorJson('Failed to retrieve project title', 500, $e->getMessage());
    }
}

 
     // Update the specified resource in DataBase.
    //  public function update(Request $request, $id)
    //  {
    //      try {
    //          $request->validate([
    //              'title' => 'required|string|max:255',
    //          ]);
     
    //          // Find the project title by ID
    //          $projectTitle = ProjectTitle::find($id);
     
    //          if (!$projectTitle) {
    //              return $this->errorJson('Project Title Not Found', 404, null);
    //          }
     
    //          // Check if the title already exists in the database
    //          $existingProjectTitle = ProjectTitle::where('title', $request->title)->first();
             
    //          // If the title exists and it's not the current project title, return an error
    //          if ($existingProjectTitle && $existingProjectTitle->id != $id) {
    //              return $this->errorJson('Title already exists', 409, null);
    //          }
     
    //          // Update the project title
    //          $projectTitel->title = $request->title;
    //          $projectTitel->save();
     
    //          return $this->successJson('Project Title Updated Successfully', 200, $projectTitle);
    //      } catch (\Exception $e) {
    //          return $this->errorJson('Failed to update project title', 500, $e->getMessage());
    //      }
    //  }
    public function update(Request $request, $id)
{
    try {
        \Log::info('Starting update method for ProjectTitleController', [
            'request_data' => $request->all(),
            'id' => $id,
        ]);

        // Validate incoming request data
        \Log::info('Validating request data', [
            'title' => $request->title,
        ]);
        $request->validate([
            'title' => ['required', 'string', 'max:255'],
        ]);

        // Find the project title by ID
        \Log::info('Finding project title by ID', [
            'id' => $id,
        ]);
        $projectTitle = ProjectTitle::find($id);

        // If project title not found, return error response
        if (!$projectTitle) {
            \Log::warning('Project Title Not Found', [
                'id' => $id,
            ]);
            return $this->errorJson('Project Title Not Found', 404);
        }

        // Check if the title already exists in the database
        \Log::info('Checking if title already exists', [
            'title' => $request->title,
        ]);
        $existingProjectTitle = ProjectTitle::where('title', $request->title)
            ->where('id', '!=', $id)
            ->first();

        // If the title exists and it's not the current project title, return an error
        if ($existingProjectTitle) {
            \Log::warning('Title already exists', [
                'title' => $request->title,
            ]);
            return $this->errorJson('Title already exists', 409);
        }

        // Update the project title
        \Log::info('Updating project title', [
            'title' => $request->title,
        ]);
        $projectTitle->title = $request->title;
        $projectTitle->save();

        // Log successful update of project title
        \Log::info('Project Title Updated Successfully', [
            'project_title' => $projectTitle,
        ]);

        // Return success response with updated project title
        return $this->successJson('Project Title Updated Successfully', 200, $projectTitle);

    } catch (\Exception $e) {
        // Log exception if any error occurs
        \Log::error('Failed to update project title', [
            'exception_message' => $e->getMessage(),
            'exception_trace' => $e->getTrace(),
        ]);

        // Return error response with appropriate message
        return $this->errorJson('Failed to update project title', 500, $e->getMessage());
    }
}
     
 
     // Remove the specified resource from DataBase.
    
    //  public function destroy($id)
    // {
    //     try {
    //         $projectTitle = ProjectTitle::find($id);

    //         if (!$projectTitle) {
    //             return $this->errorJson('Project Title Not Found', 404, null);
    //         }

    //         $projectTitle->delete();

    //         return $this->successJson('Project Title Deleted Successfully', 200, null);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('Failed to delete project title', 500, $e->getMessage());
    //     }
    // }

    public function destroy($id)
{
    try {
        \Log::info('Starting destroy method for ProjectTitleController', [
            'id' => $id,
        ]);

        // Find the project title by ID
        \Log::info('Finding project title by ID', [
            'id' => $id,
        ]);
        $projectTitle = ProjectTitle::find($id);

        // If project title not found, return error response
        if (!$projectTitle) {
            \Log::warning('Project Title Not Found', [
                'id' => $id,
            ]);
            return $this->errorJson('Project Title Not Found', 404);
        }

        // Delete the project title
        \Log::info('Deleting project title', [
            'project_title' => $projectTitle,
        ]);
        $projectTitle->delete();

        // Log successful deletion of project title
        \Log::info('Project Title Deleted Successfully', [
            'id' => $id,
        ]);

        // Return success response indicating successful deletion
        return $this->successJson('Project Title Deleted Successfully', 200);

    } catch (\Exception $e) {
        // Log exception if any error occurs
        \Log::error('Failed to delete project title', [
            'exception_message' => $e->getMessage(),
            'exception_trace' => $e->getTrace(),
        ]);

        // Return error response with appropriate message
        return $this->errorJson('Failed to delete project title', 500, $e->getMessage());
    }
}
}
