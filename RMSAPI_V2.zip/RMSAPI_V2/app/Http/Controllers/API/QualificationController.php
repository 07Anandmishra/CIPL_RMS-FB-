<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helper\Reply;
use App\Onlinequestion;
use App\JobCategory;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Qualification;
use Illuminate\Support\Facades\Log;
class QualificationController extends Controller
{
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0, 
        ], $code);
    }
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }

    // public function index()
    // {
    //     try {
    //         $qualification = Qualification::all();
    //         if (!empty($qualification)) {
    //             return $this->successJson('Qualification Details', 200, $qualification);
    //         } else {
    //             return $this->errorJson('not found Details', 404);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    public function index()
{
    try {
        Log::info('Fetching all qualifications from the database.');

        // Retrieve all qualifications
        $qualifications = Qualification::orderby('name','asc')->get();

        // Check if qualifications exist
        if ($qualifications->isNotEmpty()) {
            Log::info('Qualifications retrieved successfully.', ['count' => $qualifications->count()]);
            return $this->successJson('Qualification Details', 200, $qualifications);
        } else {
            Log::warning('No qualifications found in the database.');
            return $this->errorJson('Qualification Details not found', 404);
        }
    } catch (\Exception $e) {
        Log::error('Failed to fetch qualifications.', ['exception' => $e]);
        return $this->errorJson('An error occurred', 500);
    }
}


//   public function index1(){
        
//             $qualification = Qualification::all();
//             if(!empty($qualification)){
//                 return $this->successJson('Qualification Details',200,$qualification);
//             }else{
//                 return $this->successJson('not found Details',200,$qualification);
//             }
       
//     }

public function index1()
{
    try {
        Log::info('Fetching all qualifications from the database.');

        // Retrieve all qualifications
        $qualifications = Qualification::all();

        // Check if qualifications exist
        if ($qualifications->isNotEmpty()) {
            Log::info('Qualifications retrieved successfully.', ['count' => $qualifications->count()]);
            return $this->successJson('Qualification Details', 200, $qualifications);
        } else {
            Log::warning('No qualifications found in the database.');
            return $this->successJson('No qualifications found', 200, []);
        }
    } catch (\Exception $e) {
        Log::error('Failed to fetch qualifications.', ['exception' => $e]);
        return $this->errorJson('An error occurred', 500);
    }
}

    // public function add(Request $request)
    // {
    //     try {
    //         if (!auth()->user()->cans('add_qualification')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }
    
    //         $validator = Validator::make($request->all(), [
    //             'name' => 'required|unique:qualifications',
    //         ]);
    
    //         if ($validator->fails()) {
    //             return response()->json(['error' => $validator->errors()], 422);
    //         }
    
    //         $ins = Qualification::create(['name' => $request->name]);
    
    //         if (!empty($ins)) {
    //             return $this->successJson('Qualification Added Successfully', 200, $ins);
    //         } else {
    //             return $this->errorJson('Something else wrong', 200);
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }

    public function add(Request $request)
{
    try {
        Log::info('Attempting to add a new qualification.');

        // Check if user has permission to add qualification
        if (!auth()->user()->cans('add_qualification')) {
            Log::warning('User not authenticated to perform this request.');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        // Validate incoming request data
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:qualifications',
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed for adding qualification.', ['errors' => $validator->errors()->toArray()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        // Create a new qualification
        $qualification = Qualification::create(['name' => $request->name]);

        if ($qualification) {
            Log::info('Qualification added successfully.', ['qualification_id' => $qualification->id]);
            return $this->successJson('Qualification Added Successfully', 200, $qualification);
        } else {
            Log::error('Failed to add qualification.');
            return $this->errorJson('Something went wrong', 200);
        }
    } catch (\Exception $e) {
        Log::error('An error occurred while adding qualification.', ['exception' => $e]);
        return $this->errorJson('An error occurred', 500);
    }
}
    

    // public function update(Request $request, $id)
    // {
    //     try {
    //         if (!auth()->user()->cans('edit_qualification')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }
    
    //         if (empty($id)) {
    //             return $this->successJson('Not found Details', 404);
    //         }
    
    //         $qualification = Qualification::find($id);
    
    //         if (empty($qualification)) {
    //             return $this->errorJson('Not found Details', 404);
    //         }
    
    //         $validator = Validator::make($request->all(), [
    //             'name' => ['required', Rule::unique('qualifications')->ignore($id)],
    //         ]);
    
    //         if ($validator->fails()) {
    //             return response()->json(['error' => $validator->errors()], 422);
    //         }
    
    //         $qualification->name = $request->name;
    //         $qualification->save();
    
    //         return $this->successJson('Qualification Updated Successfully', 200, $qualification);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    
    public function update(Request $request, $id)
{
    try {
        Log::info('Attempting to update qualification.', ['qualification_id' => $id]);

        // Check if user has permission to edit qualification
        if (!auth()->user()->cans('edit_qualification')) {
            Log::warning('User not authenticated to perform this request.');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        // Check if ID is provided
        if (empty($id)) {
            Log::error('Qualification ID not provided.');
            return $this->errorJson('Not found Details', 404);
        }

        // Find the qualification by ID
        $qualification = Qualification::find($id);
        
        if (empty($qualification)) {
            Log::error('Qualification not found.', ['qualification_id' => $id]);
            return $this->errorJson('Not found Details', 404);
        }

        // Validate incoming request data
        $validator = Validator::make($request->all(), [
            'name' => ['required', Rule::unique('qualifications')->ignore($id)],
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed for updating qualification.', ['errors' => $validator->errors()->toArray()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        // Update the qualification name
        $qualification->name = $request->name;
        $qualification->save();

        Log::info('Qualification updated successfully.', ['qualification_id' => $qualification->id]);
        return $this->successJson('Qualification Updated Successfully', 200, $qualification);
    } catch (\Exception $e) {
        Log::error('An error occurred while updating qualification.', ['exception' => $e]);
        return $this->errorJson('An error occurred', 500);
    }
}

    // public function destroy($id)
    // {
    //     try {
    //         if (!auth()->user()->cans('delete_qualification')) {
    //             return $this->errorJson('Not authenticated to perform this request', 403);
    //         }
    
    //         Qualification::destroy($id);
    //         return $this->successJson('Qualification Delete Successfully', 200);
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred', 500);
    //     }
    // }
    
    public function destroy($id)
{
    try {
        Log::info('Attempting to delete qualification.', ['qualification_id' => $id]);

        // Check if user has permission to delete qualification
        if (!auth()->user()->cans('delete_qualification')) {
            Log::warning('User not authenticated to perform this request.');
            return $this->errorJson('Not authenticated to perform this request', 403);
        }

        // Attempt to delete the qualification by ID
        Qualification::destroy($id);

        Log::info('Qualification deleted successfully.', ['qualification_id' => $id]);
        return $this->successJson('Qualification Deleted Successfully', 200);
    } catch (\Exception $e) {
        Log::error('An error occurred while deleting qualification.', ['qualification_id' => $id, 'exception' => $e]);
        return $this->errorJson('An error occurred', 500);
    }
}
}
