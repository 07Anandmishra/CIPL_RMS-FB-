<?php

namespace App\Http\Controllers\API;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Module;
use App\Permission;
use App\PermissionRole;
use App\Role;
use App\RoleUser;
use App\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\StoreRole;
use App\Http\Requests\StoreUserRole;
use Illuminate\Support\Facades\Log;
class RolePermission extends Controller
{
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }
    public function get()
    {
        try {
            $roles = Role::where('id', '>', 1)->get();
            $totalPermissions = Permission::count();
            $modules = Module::with(['permissions'])->get();
            $data=['roles'=>$roles,'totalPermissions'=>$totalPermissions,'modules'=>$modules];
            
            if(empty($data)){
                return $this->errorJson('data not founds',404);
            } else {    
                return $this->successJson('data found',200,$data);
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred', $e->getMessage(), 500);
        }
    }

    public function permisioncheck(Request $request) 
    {
        try {                                                               
            $roles = DB::table('permission_role')->where(['permission_id'=>$request->permission_id,'role_id'=>$request->role_id])->count();
                                               
            if(empty($roles)){                               
                return $this->errorJson('data not founds',404,false);            
            } else {                                              
                return $this->successJson('data found',200,true);                       
            }                     
        } catch (\Exception $e) {                                               
            return $this->errorJson('An error occurred', $e->getMessage(), 500);           
        }                                    
    }                                                         
                                                          
    public function assignAllPermission(Request $request)                         
    {
        try {
            $roleId = $request->roleId;
            $permissions = Permission::all();

            $role = Role::findOrFail($roleId);
            $role->perms()->sync([]);
            $role->attachPermissions($permissions);

            return $this->successJson('Permissions added successfully', 200, $role);
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred', $e->getMessage(), 500);
        }
    }

    public function removeAllPermission(Request $request)
    {
        try {
            $roleId = $request->roleId;

            $role = Role::findOrFail($roleId);
            $role->perms()->sync([]);

            return $this->successJson('Permissions removed successfully', 200, $role);
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred', $e->getMessage(), 500);
        }
    }



    // public function store(Request $request)
    // {
    //     try {
    //         $roleId = $request->role_id;
    //         $permissionId = $request->permission_id;
    
    //         if ($request->assignPermission == '1') {
    //             $permissionRole = PermissionRole::firstOrCreate([
    //                 'permission_id' => $permissionId,
    //                 'role_id' => $roleId
    //             ]);
    //             return $this->successJson('Permission assigned successfully', 200, $permissionRole);
    //         } else {
    //             $deleted = PermissionRole::where('role_id', $roleId)->where('permission_id', $permissionId)->delete();
    //             if ($deleted) {
    //                 return $this->successJson('Permission removed successfully', 200);
    //             } else {
    //                 return $this->errorJson('Permission not found for deletion', 404);
    //             }
    //         }
    //     } catch (\Exception $e) {
    //         return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
    //     }
    // }
    

    public function store(Request $request)
    {
        Log::info('Store method called.', ['request' => $request->all()]);
    
        try {
            $roleId = $request->role_id;
            $permissionId = $request->permission_id;
    
            Log::info('Received role_id and permission_id.', ['role_id' => $roleId, 'permission_id' => $permissionId]);
    
            if ($request->assignPermission == '1') {
                Log::info('Assigning permission.');
    
                // Check if the permission is already assigned
                $existingPermissionRole = PermissionRole::where('permission_id', $permissionId)
                    ->where('role_id', $roleId)
                    ->first();
    
                if ($existingPermissionRole) {
                    Log::warning('Permission is already assigned.', ['permission_id' => $permissionId, 'role_id' => $roleId]);
                    return $this->errorJson('Permission is already assigned', 409); 
                } else {
                    $permissionRole = PermissionRole::create([
                        'permission_id' => $permissionId,
                        'role_id' => $roleId
                    ]);
                    Log::info('Permission assigned successfully.', ['permission_role' => $permissionRole]);
                    return $this->successJson('Permission assigned successfully', 200, $permissionRole);
                }
            } else {
                Log::info('Removing permission.');
    
                $deleted = PermissionRole::where('role_id', $roleId)->where('permission_id', $permissionId)->delete();
                if ($deleted) {
                    Log::info('Permission removed successfully.', ['role_id' => $roleId, 'permission_id' => $permissionId]);
                    return $this->successJson('Permission removed successfully', 200);
                } else {
                    Log::warning('Permission not found for deletion.', ['role_id' => $roleId, 'permission_id' => $permissionId]);
                    return $this->errorJson('Permission not found for deletion', 404);
                }
                
            }
        } catch (\Exception $e) {
            Log::error('An error occurred.', ['exception' => $e->getMessage()]);
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }



    public function storeRole(StoreRole $request)
    {
        try {
            $roleUser = new Role();
            $roleUser->name = $request->name;
            $roleUser->display_name = ucwords($request->name);
            $roleUser->save();
            if($roleUser){
                return $this->successJson('create Role Successfully',200,$roleUser);
            }else{
                return $this->errorJson('something else wrong',500);
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
    
    public function update(StoreRole $request, $id)
    {
        try {
            $roleUser = Role::findOrFail($id);
            $roleUser->name = $request->name;
            $roleUser->display_name = ucwords($request->name);
            $roleUser->save();
            if($roleUser){
            return $this->successJson('Role updated successfully', 200, $roleUser);}
            else{
                return $this->errorJson('something else wrong',500);
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
    public function activateDeactivate(Request $request, $id)
    {
        try
        {
            // Log the start of the process
            Log::info('Starting the diactivate process', ['role_id' => $id]);
    
            // Find the role by ID
            $roleUser = Role::findOrFail($id);
            Log::info('Role found', ['role' => $roleUser]);
    
            // Check if the current user is an Admin
            if ($request->user()->id==1) {
                Log::info('Admin user attempting to toggle role activation', ['user_id' => $request->user()->id]);
    
                // If the role is deactivated, activate it
                if ($roleUser->deleted_at == 1) {
                    $roleUser->deleted_at = 0;  // Mark as active
                    $roleUser->save();
                    Log::info('Role activated successfully', ['role' => $roleUser]);
    
                    return $this->successJson('Role activated successfully', 200, $roleUser);
                }
                // If the role is active, deactivate it
                else {
                    $roleUser->deleted_at = 1;  // Mark as deactivated
                    $roleUser->save();
                    Log::info('Role deactivated successfully', ['role' => $roleUser]);
    
                    return $this->successJson('Role deactivated successfully', 200, $roleUser);
                }
            } 
            else {
                // For non-admin users, handle deactivation attempt
                Log::info('Non-admin user attempting to deactivate role', ['user_id' => $request->user()->id]);
    
                // Check if the role is already deactivated
                if ($roleUser->deleted_at == 1) {
                    Log::warning('Role is already deactivated', ['role' => $roleUser]);
    
                    return $this->errorJson('Role is already deactivated', 400);
                } 
                // Deactivate the role
                $roleUser->deleted_at = 1;  // Mark as deactivated
                $roleUser->save();
                Log::info('Role deactivated successfully', ['role' => $roleUser]);
                return $this->successJson('Role deactivated successfully', 200, $roleUser);
            } 
        }
        catch (\Exception $e)
        {
            // Log the exception
            Log::error('An error occurred during the diactivate process', [
                'error' => $e->getMessage(),
                'role_id' => $id,
            ]);
    
            // Return error response
            return $this->errorJson('An error occurred: ' . $e->getMessage(), 500);
        }
    }
    

    

}

    


