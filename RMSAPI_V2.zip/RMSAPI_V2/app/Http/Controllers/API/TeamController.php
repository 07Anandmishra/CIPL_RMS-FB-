<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\EmailSetting;
use App\Helper\Files;
use App\Helper\Reply;
use App\Http\Requests\StoreTeam;
use App\Http\Requests\UpdateTeam;
use App\Notifications\NewUser;
use App\Role;
use App\RoleUser;
use App\User; 
use Illuminate\Support\Facades\Mail;
use App\Mail\TeamCreatedMail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpKernel\Tests\HttpCache\StoreTest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log; 
class TeamController extends Controller
{
    protected function successJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>1,
        ], 200);
    }
    protected function errorJson($message, $code, $data = [])
    {
        return response()->json([
            'code' => $code,
            'message' =>  $message,
            'data' => $data,
            'status'=>0,
        ], $code);
    }



   public function index()
    {
        try {
            $role = Role::orderby('name','asc')->get();
            if (!empty($role)) {    
                return $this->successJson('Role List', 200, $role);
            } else {
                return $this->errorJson('not found Details', 200);
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred', 500, $e->getMessage());
        }
    }

    public function Store(Request $request)
    {
        if (!auth()->user()->cans('add_team')) {
            return $this->errorJson('Not authenticated to perform this request', 403);
        }
    
        // Check if the selected role is active
        $role = Role::find($request->role_id);
        if ($role->deleted_at == 1) 
        { 
            return $this->errorJson('Selected role is disabled', 400);
        }else if($role->id==1) 
        {
            return $this->errorJson('App Administrator cannot be duplicated', 400);
        }

        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
                'password' => 'required|min:6',
                'image' => 'image|max:2048',
                'mobile' => 'required|numeric',
                'role_id' => 'required'
            ]);
    
            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 422);
            }
    
            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->calling_code = '+91';
            $user->mobile = $request->mobile;
            $user->ishod = $request->ishod;
            $user->isprojectlead = $request->isprojectlead;
    
            if ($request->hasFile('image')) {
                $user->image = Files::uploadLocalOrS3($request->image, 'profile');
            }
    
            $user->save();
                
            // Attach role
            $user->roles()->attach($request->role_id);
            // Send email notification
        $createdBy = auth()->user(); // The user who created the team member
        Mail::to($user->email)->send(new TeamCreatedMail($user, $role, $createdBy));
    
            return $this->successJson('Team Created Successfully', 200, $user);
    
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while creating the team', 500, $e->getMessage());
        }
    }
    
   public function getbyishod($ishod)
   {
       try
       {
           $users = User::where('ishod', $ishod)->get();

           if ($users->isEmpty()) {
               return $this->errorJson('No users found with the specified ishod', 404,$users);
           }
           
           return $this->successJson('Is hod Team List', 200, $users);
       }
       catch (\Exception $e) {
           return $this->errorJson('Failed to fetch users', 500, $e->getMessage());
       }
   }

   public function getbyisprojeclead($isprojectlead)
   {
       try
       {
           $users = User::where('isprojectlead', $isprojectlead)->get();

           if ($users->isEmpty()) {
               return $this->errorJson('No users found with the specified isprojectlead', 404,$users);
           }
           
           return $this->successJson('Is ProjectLead Team List', 200, $users);
       }
       catch (\Exception $e) {
           return $this->errorJson('Failed to fetch users', 500, $e->getMessage());
       }
   }

   public function getallhod()
   {
    try
    {
        $users = User::where('ishod', 1)
        ->orderBy('name','asc')
        ->get();
        if ($users->isEmpty()) {
            return $this->errorJson('No users found with the specified isprojectlead', 404,$users);
        }
        
        return $this->successJson('Is Hod Team List', 200, $users);
    }catch (\Exception $e) {
        return $this->errorJson('Failed to fetch users', 500, $e->getMessage());
    }
    
   }

   public function getallprojectlead()
   {
    try
    {
        $users = User::where('isprojectlead', 1)
        ->orderby('name','asc')
        ->get();
        if ($users->isEmpty()) {
            return $this->errorJson('No users found with the specified isprojectlead', 404,$users);
        }
        
        return $this->successJson('Is ProjectLead Team List', 200, $users);
    }catch (\Exception $e) {
         return $this->errorJson('Failed to fetch users', 500, $e->getMessage());
    }
   }

    public function get() 
    {
        try {
            $users = User::with(['roles.permissions.permission'])->orderby('name','asc')->get();
            
            if ($users->isEmpty()) {
                return $this->errorJson('Not found details', 404);
            }
            
            return $this->successJson('Team List', 200, $users);
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while fetching the team list', 500, $e->getMessage());
        }
    }


    public function filter($name)
    {
        try {
            $users = User::where('name', 'LIKE', "%$name%")->get();
            
            if($users){
                return $this->successJson('Team List',200,$users);
            }else{
                return $this->errorJson('not found Details',404);
            }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while filtering the team list', 500, $e->getMessage());
        }
    }

    public function changeRole(Request $request)
    {
        try {
            $user = User::find($request->teamId);
    
            // Delete existing roles
            RoleUser::where('user_id', $request->teamId)->delete();
    
            // Attach new role
            $user->roles()->attach($request->roleId);
    
            if($user){
                return $this->successJson('Update ',200,$user);
                }else{
                    return $this->errorJson('not found Details',404);
                }
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while updating the role', 500, $e->getMessage());
        }
    }
    

    public function destroy(Request $request,$id)
    {
        try {

            if (!auth()->user()->cans('delete_team')) {
                return $this->errorJson('Not authenticated to perform this request', 403);
            }
            //$deleted = User::destroy($id);
             // Find the user by ID
             $User = User::findOrFail($id);
             if ($request->user()->id == 1) 
             {
                  // If the user is deactivated, activate it
                  if ( $User->deleted_at == 1) {
                    $User->deleted_at = 0;  // Mark as active
                    $User->save();
                    Log::info('User activated successfully', ['role' => $User]);
                    return $this->successJson('User activated successfully', 200,$User);
             }
             // If the user is active, deactivate it
             else
             {
                $User->deleted_at = 1;  // Mark as deactivated
                $User->save();
                    Log::info('User deactivated successfully', ['role' => $User]);
                    return $this->successJson('User deactivated successfully', 200, $User);
             }
            }else
            {
                return $this->errorJson('Only Admin can be deactivated any user', 403);
            }
        }
        catch (\Exception $e) {
            return $this->errorJson('An error occurred while deactivated the team', 500, $e->getMessage());
        }
    }
    


    public function update(UpdateTeam $request, $id)
    {
        try {
            if (!auth()->user()->cans('edit_team')) {
                return $this->errorJson('Not authenticated to perform this request', 403);
            }
    
            $user = User::find($id);
    
            $user->name = $request->name;
            $user->email = $request->email;
    
            if ($request->password != '') {
                $user->password = Hash::make($request->password);
            }
    
            $user->mobile = $request->mobile;
    
            if ($request->hasFile('image')) {
                Files::deleteFile($user->image, 'profile');
                $user->image = Files::uploadLocalOrS3($request->image, 'profile');
            }
    
            $user->save();
    
            // Attach role
            RoleUser::where('user_id', $id)->delete();
            $user->roles()->attach($request->role_id);
    
            if($user){
                return $this->successJson('Team Updated Successfully',200,$user);
          }
    
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while updating the team', 500, $e->getMessage());
        }
    }
    

    public function changepassword(Request $request, $id)
    {
        try {
            $user = User::find($id);
            $user->name = $request->name;
    
            if ($request->password != '') {
                $user->password = Hash::make($request->password);
            }
    
            if ($request->mobile != '' || $request->mobile == null) {
                $user->mobile = $request->mobile;
            }
    
            if ($request->hasFile('image')) {
                Files::deleteFile($user->image, 'profile');
                $user->image = Files::uploadLocalOrS3($request->image, 'profile');
            }
    
            $user->save();
    
            return $this->successJson('Profile Updated Successfully', 200, $user);
    
        } catch (\Exception $e) {
            return $this->errorJson('An error occurred while updating the profile', 500, $e->getMessage());
        }
    }

    //role permission
    public function rolePermission(Request $request, $roleId)
    {
        // Log the incoming request
        Log::info('Received request for role permissions', ['roleId' => $roleId]);
    
        try {
            // Check if the role exists
            $role = DB::table('roles')->where('id', $roleId)->first();
    
            if (!$role) {
                Log::info('Role ID does not exist', ['roleId' => $roleId]);
                return $this->errorJson('The specified role ID does not exist', 404);
            }
    
            $roleDeletedAt = $role->deleted_at;
    
            // If role is deleted (deleted_at = 1), remove all assigned permissions
            if ($roleDeletedAt == 1) {
                Log::info('Role is disabled, removing all permissions for this role.', ['roleId' => $roleId]);
    
                // Remove all assigned permissions for this role
                $deletedPermissions = DB::table('permission_role')
                    ->where('role_id', $roleId)
                    ->delete();
    
                if ($deletedPermissions) {
                    Log::info('All permissions removed for disabled role.', ['roleId' => $roleId]);
                    return $this->successJson('Role is disabled. All assigned permissions have been removed.', 200);
                } else {
                    Log::warning('No permissions found to remove for disabled role.', ['roleId' => $roleId]);
                    return $this->errorJson('No permissions found to remove for this role.', 404);
                }
            }
    
            // Restore permissions if the role is active (deleted_at = 0)
            if ($roleDeletedAt == 0) {
                Log::info('Role is active, restoring permissions for this role.', ['roleId' => $roleId]);
    
                // Retrieve all permissions along with their modules and check for their assignment to the specified role
                $rawData = DB::table('permissions')
                    ->leftJoin('permission_role', function ($join) use ($roleId) {
                        Log::info('Joining tables: permissions with permission_role for role_id', ['roleId' => $roleId]);
                        $join->on('permissions.id', '=', 'permission_role.permission_id')
                             ->where('permission_role.role_id', $roleId);
                    })
                    ->leftJoin('modules', 'permissions.module_id', '=', 'modules.id')
                    ->select(
                        'permissions.id as permission_id',
                        'permissions.name as permission_name',
                        'permissions.display_name as permission_displayname',
                        'permissions.module_id as permission_module_id',
                        'modules.id as module_id',
                        'modules.module_name as module_name',
                        'permission_role.role_id as pr_role_id',
                        'permission_role.permission_id as pr_permission_id'
                    )
                    ->orderBy('modules.id')
                    ->orderBy('permissions.id')
                    ->get();
                
                Log::info('Fetched raw data', ['data' => $rawData]);
    
                // Check if data is found for the given role ID
                if ($rawData->isEmpty()) {
                    Log::info('No data found for role_id', ['roleId' => $roleId]);
                    return response()->json(['message' => 'No data found for the specified role ID'], 404);
                }
    
                // Initialize the result array
                $result = [
                    'role_id' => $roleId,
                    'modules' => []
                ];
    
                // Process the raw data into an array of modules and permissions
                foreach ($rawData as $item) {
                    Log::info('Processing item', ['item' => $item]);
    
                    // Initialize module if not already done
                    if (!isset($result['modules'][$item->module_id])) {
                        Log::info('Initializing module', ['module_id' => $item->module_id, 'module_name' => $item->module_name]);
    
                        $result['modules'][$item->module_id] = [
                            'module_id' => $item->module_id,
                            'module_name' => $item->module_name,
                            'permissions' => []
                        ];
                    } else {
                        Log::info('Module already exists', ['module_id' => $item->module_id]);
                    }
    
                    // Add permission to the module
                    $result['modules'][$item->module_id]['permissions'][] = [
                        'permission_id' => $item->permission_id,
                        'permission_name' => $item->permission_name,
                        'permission_display_name' => $item->permission_displayname,
                        'permission_role' => [
                            'role_id' => $item->pr_role_id,  // This will be null if the permission is not assigned to the role
                            'permission_id' => $item->pr_permission_id  // This will be null if the permission is not assigned to the role
                        ]
                    ];
                }
    
                Log::info('Processed data into result format', ['result' => $result]);
    
                // Convert the associative array to an indexed array for modules
                $result['modules'] = array_values($result['modules']);
    
                // Return the response
                Log::info('Returning JSON response for role permissions', ['response' => $result]);
    
                return $this->successJson('Successfully fetched all permissions for the role ID.', 200, $result);
            }
    
        } catch (\Exception $e) {
            // Log the exception message
            Log::error('Error fetching role permissions', [
                'roleId' => $roleId,
                'error' => $e->getMessage()
            ]);
    
            // Return a generic error response
            return response()->json(['error' => 'Unable to fetch role permissions'], 500);
        }
    }
    
    
        

}
