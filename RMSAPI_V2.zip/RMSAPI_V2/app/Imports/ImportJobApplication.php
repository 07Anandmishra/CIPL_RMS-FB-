<?php

namespace App\Imports;
use Mail;
use App\JobApplication;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\Rule;
use Validator;
use Maatwebsite\Excel\Concerns\WithValidation;
use App\Notifications\NewUserNotification;
use DB;
use App\Models\UserProfile;
use App\Models\Usereducation;
use App\Models\Userskill;
use App\Models\Useremploymentdetail;
use App\Models\Usercertification;
use App\Models\Userprojectdetail;
use App\Models\Userprojecttechnology;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Carbon\Carbon;
use App\JobLocation;
use App\Helper\Files;
use App\Helper\Reply; 
use App\ApplicationStatus;
use App\InterviewSchedule;
use App\ApplicationSetting;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Notifications\ScheduleInterview;
use App\Http\Requests\UpdateJobApplication;
use App\Notifications\CandidateStatusChange;
use Illuminate\Support\Facades\Notification;
use App\Notifications\CandidateScheduleInterview;
use App\Http\Requests\InterviewSchedule\StoreRequest;
use App\JobApplicationsubqualification; 
use App\JobCategory;
use App\Notifications\RatingNotification;
use App\Subqualification;
use App\Qualification;
use App\Candidate;
use App\Mail\CandidateShortlistBulk;
use Illuminate\Support\Facades\Crypt;
use App\candidate_history;
use App\Jobrecruitment;
use App\User;

use DateTime;
use Illuminate\Support\Facades\Log; 
class ImportJobApplication implements ToCollection,WithHeadingRow,WithValidation
{
    public function collection(Collection $rows)
    {
        $candidates = [];
        $errors = [];
        $seenEmails = [];
        $seenPhones = [];
        
        foreach ($rows as $row) 
        {
            //  // Check for duplicates within the Excel file
            //  if (in_array($row['email'], $seenEmails)) {
            //     $errors[] = "Duplicate email found in Excel file: " . $row['email'];
            //     continue;
            // }

            // if (in_array($row['phone'], $seenPhones)) {
            //     $errors[] = "Duplicate phone number found in Excel file: " . $row['phone'];
            //     continue;
            // }

            // // Mark email and phone as seen
            // $seenEmails[] = $row['email'];
            // $seenPhones[] = $row['phone'];

            // $duplicateEmail = Candidate::where('EmailId', $row['email'])->first();
            // $duplicatePhone = Candidate::where('PhoneNumber', $row['phone'])->first();

            // if ($duplicateEmail) {
            //     $errors[] = "Duplicate email found: " . $row['email'];
            //     continue;
            // }

            // if ($duplicatePhone) {
            //     $errors[] = "Duplicate phone number found: " . $row['phone'];
            //     continue;
            // }
           
           
              
                // if (Qualification::where('name',$row['qualification'])->count()!=0  ) {      


                // $QualificationId = Qualification::where('name',$row['qualification'])->first();
               
                $jobrecruitment_id = session()->get('jobrecruitment_id');
               $job_id= session()->get('job_id');
                $candidate = new Candidate();
                // $candidate->full_name = $row['first_name'];
                // $candidate->lastname = $row['last_name'];
                $candidate->Name = $row['name'];

               
                $candidate->status_id = '1'; //applied status id
                $candidate->Email = $row['email'];
                $candidate->JobTitle = $row['job_title'];
               // $candidate->JobTitle = $row['JobTitle'];
                $candidate->ContactNo = $row['phone'];
                $candidate->FatherName= $row['father_name'];
                
                
         
                $candidate->TotalExperience=$row['total_exp'];
           
                $candidate->ResumeLink=$row['resume_link'];
                 $candidate->CurrentLocation=$row['currentlocation'];
                $candidate->PrefferedLocation=$row['prefferedlocation'];
             
              

              // Handle gender field
              $gender = strtolower($row['gender']);
              if ($gender === 'male') {
                  $candidate->gender = 1;
              } elseif ($gender === 'female') {
                  $candidate->gender = 2;
              } elseif ($gender === 'transgender') {
                  $candidate->gender = 3;
              } else {
                  throw new \Exception("Invalid gender value: '$gender'. Must be 'male', 'female', or 'transgender'.");
              }
              // Handle MaritalStatus field
              $maritalstatus = strtolower($row['maritalstatus']);
              if ($maritalstatus === 'married') {
                  $candidate->MaritalStatus = 1;
              } elseif ($maritalstatus === 'single') {
                  $candidate->MaritalStatus = 2;
              } elseif ($maritalstatus === 'divorce ') {
                  $candidate->MaritalStatus = 3;
              } else {
                  throw new \Exception("Invalid MaritalStatus value: '$maritalstatus'. Must be 'Married', 'Single', or 'Divorce '.");
              }

             
                $candidate->Nationality=$row['nationality'];
                $candidate->Interest=$row['interest'];
                $candidate->Languages=$row['languages'];
                $candidate->CurrentSalary=$row['currentsalary'];
                $candidate->SalaryExpectation=$row['salaryexpectation'];
                $candidate->NoticePeriod=$row['noticeperiod'];
                $candidate->Summary=$row['summary'];

               // $candidate->qualifications_id=$QualificationId->id;
               if($jobrecruitment_id)
               {
                $candidate->MRFId=$jobrecruitment_id;
                $candidate->job_id = $job_id;
               }
               
                $candidate->save();

                        // Save candidate history
                    candidate_history::create([
                        'remarks' => 'Candidate uploaded',
                        'status_id' => 1, // assuming '1' is the status ID for 'uploaded'
                        'candidate_id' => $candidate->Id,
                        'isactive' => 1,
                    ]);
                    
                    // Collect candidate data for the email
                    $encryptedCandidateId = Crypt::encrypt($candidate->Id);
                    $encryptedAccept = Crypt::encrypt('Accept');
                    $encryptedReject = Crypt::encrypt('Reject');
                    $acceptLink = config('app.AppBaseURL') . 'candidate/action/' . $encryptedCandidateId . '/' . $encryptedAccept;
                    $rejectLink = config('app.AppBaseURL') . 'candidate/action/' . $encryptedCandidateId . '/' . $encryptedReject;

                    $candidates[] = [
                        'Name' => $candidate->Name,
                        'ResumeLink' => $candidate->ResumeLink,
                        'acceptLink' => $acceptLink,
                        'rejectLink' => $rejectLink
                    ];

                //  if($row['sub_qualification'] !='' || $row['sub_qualification'] !=null){
                //             $subcatery_array=explode(",",$row['sub_qualification']);
                //             if($subcatery_array){
                            
                //                 foreach($subcatery_array as $rowdata){
                                
                //                     if (Subqualification::where('name',$rowdata)->count()!=0) {
                                    
                                        // $subcategory = Subqualification::where('name',$rowdata)->first();
                                    
                                        // $jobapplicationqualification = new JobApplicationsubqualification();
                                        // $jobapplicationqualification->jobapplication_id = $jobApplication->id;
                                        // $jobapplicationqualification->status='1';
                                        // $jobapplicationqualification->subqualifications_id = $subcategory->id;
                                    
                                        // $jobapplicationqualification->save();
                        //                                            }
                        //         }
                        //     }
                        // }
                    


                    }
                    
                // }


                if (!empty($errors)) {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Some rows have errors',
                        'errors' => $errors
                    ], 400);
                }


                // Send the email if there are candidates to shortlist
            if (!empty($jobrecruitment_id)) {
                $jobrecruitment = Jobrecruitment::find($jobrecruitment_id);
                $teamleadid = $jobrecruitment->reporting_team;
                $teamLead = User::find($teamleadid);

                if ($teamLead) {
                    Mail::to($teamLead->email)->send(new CandidateShortlistBulk($teamLead->name, $candidates));
                }
            }

    }

    

    public function rules(): array
    {       
     
        // $qualificationarr = array();
        // $qualification = Qualification::get(['id','name']);
        // foreach ($qualification as $c) {
           
        //     array_push($qualificationarr, $c->name);
        // }
       
       

        return [

            //  'qualification'=>'required|in:'.implode(',',$qualificationarr), 
              //'qualification'=>'in:'.implode(',',$qualificationarr),           
           // 'Name'=>'required',
            // 'phone' => 'required',
            // 'email' => 'required',
            'phone' => 'required|unique:candidate,ContactNo',
            'email' => 'required|unique:candidate,Email',
            'job_title'=>'required',
            'resume_link'=>'required',
            
          
            'total_exp'=>'required',                              
        ];
    }


    // public function withValidator($validator)
    // {
        
    //     $validator->after(function ($validator) {
            
    //         $datas = $validator->getData();

    //         $dataarr = array();
            
    //         foreach ($datas as $data =>$value) {

                
    //             $category = Qualification::where('name',$value['qualification'])->first();

    //             if ($category==null) {
    //                 $validator->errors()->add($data, 'Qualification does not exists.');
                    
    //             } else{
    //                 $tell =true;
    //             }


                


    //         }
                       
    //     });
    // }


}
