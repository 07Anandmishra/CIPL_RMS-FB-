<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class CandidateShortlistBulk extends Mailable
{
    use Queueable, SerializesModels;

    public $projectManagerName;
    public $candidates;

    public function __construct($projectManagerName, $candidates)
    {
        $this->projectManagerName = $projectManagerName;
        $this->candidates = $candidates;
    }

    public function build()
    {
        return $this->view('emails.CandidateShortlistBulk')
            ->subject('New Candidates Shortlisted')
            ->with([
                'projectManagerName' => $this->projectManagerName,
                'candidates' => $this->candidates
            ]);
    }
}
