<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class InterviewScheduled extends Mailable
{
    use Queueable, SerializesModels;

    public $candidate;
    public $interviewer;
    public $position;
    public $date;
    public $time;
    public $mode;
    public $meetingUrl;
    public $IvStatus;

    public function __construct($candidate, $interviewer, $position, $date, $time, $mode, $meetingUrl,$IvStatus)
    {
        $this->candidate = $candidate;
        $this->interviewer = $interviewer;
        $this->position = $position;
        $this->date = $date;
        $this->time = $time;
        $this->mode = $mode;
        $this->meetingUrl = $meetingUrl;
        $this->IvStatus = $IvStatus;
    }

    public function build()
    {
        return $this->subject($this->IvStatus . ' for ' . $this->position)
                    ->markdown('emails.interview_scheduled');
    }
}
