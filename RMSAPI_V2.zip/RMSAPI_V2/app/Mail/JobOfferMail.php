<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use App\JobApplication; 

class JobOfferMail extends Mailable
{
    use Queueable, SerializesModels;

    public $jobApplication;
    public $acceptLastDate;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(JobApplication $jobApplication, $acceptLastDate)
    {
        $this->jobApplication = $jobApplication;
        $this->acceptLastDate = $acceptLastDate;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Congratulations! Your Offer Letter for ' . $this->jobApplication->Name . ' at Corporate Infotech Private Limited')
                    ->view('emails.job_offer')
                    ->with([
                        'jobApplication' => $this->jobApplication,
                        'acceptLastDate' => $this->acceptLastDate,
                    ]);
    }
}
