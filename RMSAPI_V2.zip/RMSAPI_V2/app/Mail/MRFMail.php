<?php

namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class MRFMail extends Mailable
{
    use Queueable, SerializesModels;

    public $projectManagerName;
    public $requesterName;
    public $position;
    public $project;
    public $mrfNumber;
    public $status;
    public $senderName;
    public $senderPosition;
    public $companyName;
    public $approvalLink;
    public $rejectLink;
    //public $clickHere;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->projectManagerName = $data['projectManagerName'];
        $this->requesterName = $data['requesterName'];
        $this->position = $data['position'];
        $this->project = $data['project'];
        $this->mrfNumber = $data['mrfNumber'];
        $this->status = $data['status'];
        $this->senderName = $data['senderName'];
        $this->senderPosition = $data['senderPosition'];
        $this->companyName = $data['companyName'];
        $this->approvalLink=$data['approvalLink'];
        $this->rejectLink=$data['rejectLink'];
     //   $this->clickHere=$data['clickHere'];
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.mrfMail')
                    ->subject('MRF ' . $this->mrfNumber . ' - Approval Status');
    }

}
