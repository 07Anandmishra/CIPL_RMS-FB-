<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class OfferLetterResponse extends Mailable
{
    use Queueable, SerializesModels;

    public $candidate;
    public $projectLeader;
    public $position;
    public $status;
    public $joiningDate;

    public function __construct($candidate, $projectLeader, $position, $status, $joiningDate = null)
    {
        $this->candidate = $candidate;
        $this->projectLeader = $projectLeader;
        $this->position = $position;
        $this->status = $status;
        $this->joiningDate = $joiningDate;
    }

    public function build()
    {
        return $this->subject('Offer Letter Response for ' . $this->position . ' - ' . $this->candidate->Name)
                    ->view('emails.offer_letter_response');
    }

}
