<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class TeamCreatedMail extends Mailable
{
    use Queueable, SerializesModels;

    use Queueable, SerializesModels;

    public $user;
    public $role;
    public $createdBy;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($user, $role, $createdBy)
    {
        $this->user = $user;
        $this->role = $role;
        $this->createdBy = $createdBy;
    }

    public function build()
    {
        return $this->subject('Welcome to the Team!')
                    ->view('emails.TeamCreate');
    }
}
