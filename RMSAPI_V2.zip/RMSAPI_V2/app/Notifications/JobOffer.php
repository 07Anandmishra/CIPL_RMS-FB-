<?php

namespace App\Notifications;
use Carbon\Carbon;
use Illuminate\Support\HtmlString;
use App\User;
use App\JobApplication;
use App\SmsSetting;
use App\Traits\SmsSettings;
use App\Traits\SmtpSettings;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\NexmoMessage;
use Auth;
class JobOffer extends Notification
{
    use Queueable, SmtpSettings;
//        , SmsSettings;

    /**
     * JobOffer constructor.
     * @param JobApplication $jobApplication
     */
    public function __construct(JobApplication $jobApplication)
    {
        $this->jobApplication = $jobApplication;
//        $this->smsSetting = SmsSetting::first();

        $this->setMailConfigs();
//        $this->setSmsConfigs();
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        $via = ['mail'];

//        if ($this->smsSetting->nexmo_status == 'active' && $notifiable->mobile_verified == 1) {
//            array_push($via, 'nexmo');
//        }

        return $via;
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $acceptLastDate = Carbon::parse($this->jobApplication->onboard->accept_last_date)->format('Y-m-d');
return (new MailMessage)
    ->subject('Congratulations! Your Offer Letter for ' . $this->jobApplication->Name. ' at Corporate Infotech Private Limited')
    ->greeting('Dear ' . ucwords($this->jobApplication->Name) . ',')
    ->line('We are excited to extend an offer for the position of ' . $this->jobApplication->JobTitle . ' at Corporate Infotech Private Limited. Please find the attached offer letter with detailed information about the role and the terms of employment.')
    ->line('We look forward to welcoming you to our team. Please review the offer and respond by ' .  $acceptLastDate. '.')
    ->line('Thank you.')
    //  ->line('Best Regards,')
     ->line('Corporate Infotech Private Limited')
    ->action('View Offer', config('app.AppBaseURL').'job-offer/' . $this->jobApplication->onboard->offer_code)
   
    ->line(new HtmlString('<div class="disclaimer" style="font-size: 10px; color: grey; margin-top: 20px;">
    <p style="font-size: 10px; color: grey; margin-top: 20px;">Disclaimer:</p>
    <p style="font-size: 10px; color: grey; margin-top: 20px;">This email and any attachments are intended solely for the use of the individual or entity to whom they are addressed. This communication may contain confidential and/or privileged information. If you are not the intended recipient, please notify the sender immediately and delete this email from your system. Any unauthorized use, dissemination, copying, or disclosure of this email and its contents is strictly prohibited.</p>
    <p style="font-size: 10px; color: grey; margin-top: 20px;">For any concerns, please reach out to us at tahelpdesk@cipl.org.in.</p>
</div>'));


        
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        //
    }

    /**
     * Get the Nexmo / SMS representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return NexmoMessage
     */
    public function toNexmo($notifiable)
    {
        return (new NexmoMessage)
                    ->content(
                        __($this->jobApplication->Name).' '.__('email.jobOffer.text').' - ' . ucwords($this->jobApplication->job->pid)
                    )->unicode();
    }
}
