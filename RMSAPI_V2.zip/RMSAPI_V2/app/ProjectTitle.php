<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;




class ProjectTitle extends Model
{
   
    protected $primaryKey = 'id';
   protected $primary='id';

    // Table name
    protected $table = 'projectTitle';

  
    // Timestamps
    public $timestamps = true;

    // Columns that are mass assignable
    protected $fillable = [
        'id',
        'title',
        'created_at',
        'updated_at', 
        'deleted_at'
    ];

   
   
}
