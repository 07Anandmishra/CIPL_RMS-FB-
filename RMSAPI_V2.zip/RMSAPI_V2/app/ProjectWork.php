<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectWork extends Model
{
    use HasFactory;
    protected $primaryKey = 'Id';
    protected $table = 'projectwork';
    protected $fillable = [
        'CandidateId',
        'project',
        'description',
    ];
    public function Candidate()
    {
        return $this->belongsTo(Candidate::class, 'CandidateId', 'Id');
    }
}
