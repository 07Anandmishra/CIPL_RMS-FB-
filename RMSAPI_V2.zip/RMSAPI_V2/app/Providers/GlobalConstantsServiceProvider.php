<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class GlobalConstantsServiceProvider extends ServiceProvider
{
    public function register()
    {
        // Define global constant
        define('APP_EMAIL', 'tahelpdesk@cipl.org.in');
    }
}
