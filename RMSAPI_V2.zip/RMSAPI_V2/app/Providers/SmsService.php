<?php

namespace App\Providers;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SmsService
{
    protected $apiUrl;
    protected $apiKey;
    protected $senderId;
    protected $route;

    
    protected $smsTemplateMappings = [
       
        'offer' => '1707172175264766718',
        'interview' => '1707172175231536329',
        'shortlisted' => '1707172111960774104',
        'hold' => '1707172111975253096',
        'candidatereject' => '1707172111969688929',
        
       
    ];

    public function __construct()
    {
        $this->apiUrl = env('TRUSTSIGNAL_API_URL'); // Base URL for sending SMS
        //$this->apiUrl = 'https://api.trustsignal.io/v1/sms'; // Base URL for sending SMS
        $this->apiKey =env('TRUSTSIGNAL_API_KEY'); // API Key
        // $this->apiKey = '0df22503-4429-4d15-a543-8d0952709127'; // API Key
        $this->senderId = env('TRUSTSIGNAL_SENDER_ID');
        $this->route = env('TRUSTSIGNAL_ROUTE', 'transactional'); // Default to 'transactional' if not set
    }

    /**
     * Send SMS based on action (e.g., candidate shortlisted, interview scheduled)
     *
     * @param array $to (Phone numbers array)
     * @param string $action (Action string like 'candidate shortlisted')
     * @param array $variables (Array to replace variables in template)
     * @return \Illuminate\Http\Client\Response|\Illuminate\Http\JsonResponse
     */
    public function sendSms(array $to, string $action, array $variables)
    {
        // Get the template ID based on the action
        $templateId = $this->getTemplateIdByAction($action);
    
        if (!$templateId) {
            Log::error('Template ID not found for the action: ' . $action);
            return response()->json(['error' => 'Template ID not found for the given action'], 404);
        }
    
        // Prepare the message template with variable replacements
        $message = $this->getMessageTemplate($templateId);
    
        if (!$message) {
            Log::error('Message template not found for the template ID: ' . $templateId);
            return response()->json(['error' => 'Message template not found'], 404);
        }
    
       
        foreach ($variables as $key => $value) {
            $placeholder = "{#{$key}#}"; // Create a dynamic placeholder like {#var1#}, {#var2#}, etc.
            $message = str_replace($placeholder, $value, $message);
        }
    
        // Log the message and other details for debugging
        Log::info('Preparing SMS with message: ' . $message);
        Log::info('Sending SMS to: ', $to);
        $numbers = array_map('intval', $to);
        // Prepare the SMS payload
        $payload = [
            'sender_id' => $this->senderId,
            'to' =>  $numbers, // Phone numbers array
            'route' => $this->route,
            'message' => $message,
            'template_id' => $templateId,
        ];
    
        // Log the payload for debugging
        Log::info('Payload for SMS: ', $payload);
    
        // Build the full URL with the API key as a query parameter
        $urlWithApiKey = $this->apiUrl . '?api_key=' . $this->apiKey;
    
        // Log the URL for debugging
        Log::info('API URL with API key: ' . $urlWithApiKey);
    
        // Send the SMS via HTTP POST request with the API key in the query string and JSON payload
        try {
            $response = Http::withoutVerifying()  // Disable SSL verification (for dev only)
                ->withHeaders([
                    'Content-Type' => 'application/json'
                ])
                ->post($urlWithApiKey, $payload);  // Send the POST request with the payload
            
            // Log the response from the API
            Log::info('API Response: ', $response->json());
    
            if ($response->failed()) {
                Log::error('Failed to send SMS: ' . $response->body());
            }
    
            return $response;
    
        } catch (\Exception $e) {
            // Log any errors that occur during the request
            Log::error('Error sending SMS: ' . $e->getMessage());
            return response()->json(['error' => 'Failed to send SMS'], 500);
        }
    }
    

    /**
     * Get the template ID by action
     *
     * @param string $action
     * @return string|null
     */
    private function getTemplateIdByAction(string $action)
    {
        // Convert the action to lowercase and trim any extra spaces
        $action = strtolower(trim($action));

        // Return the corresponding template ID or null if not found
        return $this->smsTemplateMappings[$action] ?? null;
    }

    /**
     * Get the message template from the template ID
     *
     * @param string $templateId
     * @return string|null
     */
    private function getMessageTemplate(string $templateId)
    {
        $templates = [
            '1707172175264766718' => 'Congratulations {#var1#}! We are pleased to offer you the {#var2#} position at CIPL. Please check your email for details.',
            '1707172179797541195' => 'Dear {#var1#}, please provide the additional information requested for your application to the {#var2#} position at CIPL by {#var#}.',
            '1707172175231536329' => 'Dear {#var1#}, your interview for the {#var2#} position at CIPL is scheduled on {#var3#} at {#var4#}. Please be on time.',
            '1707172175247383024' => 'Reminder: Your interview for the {#var2#} position at CIPL is on {#var#} at {#var#}. Good luck!',
            '1707172111978916237' => 'Dear {#var1#}, thank you for attending the interview with us for the {#var2#} position at CIPL. We will be in touch with the results soon.',
            '1707172111969688929' => 'Dear {#var1#}, thank you for applying to CIPL. Unfortunately, we have decided to move forward with other candidates for the {#var2#} position.',
            '1707172111975253096' => 'Dear {#var1#}, your application for the {#var2#} position at CIPL is currently on hold. We will update you as soon as we have more information.',
            '1707172111960774104' => 'Dear {#var1#}, we have received your application for the {#var2#} position at CIPL. We will review it and get back to you soon.',
        ];

        return $templates[$templateId] ?? null;
    }
}
