<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class candidate_history extends Model
{
    protected $primaryKey = 'id';
    use HasFactory;
   

    protected $fillable = [
        'remarks',
        'status_id',
        'candidate_id',
        'activity',
        'isactive',
        'created_at',
        'updated_at'
    ];
    public function candidate_status()
    {
        return $this->belongsTo(candidate_status::class, 'status_id');
    }

    public function Candidate()
    {
        return $this->belongsTo(Candidate::class, 'candidate_id','Id');
    }

    protected $table = 'candidate_history';
}
