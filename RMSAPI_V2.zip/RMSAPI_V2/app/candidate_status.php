<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class candidate_status extends Model
{
    protected $primaryKey = 'id';
    use HasFactory;
    protected $fillable = [
        
        'name',
        'created_at',
        'updated_at'

    ];
public function candidate_history()
    {
        return $this->hasMany(candidate_history::class, 'status_id');
    }
    protected $table = 'candidate_status';
}
