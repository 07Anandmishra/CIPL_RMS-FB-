<tr>
    <td class="header">
        <a href="config('app.AppBaseURL')">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>
<?php /**PATH D:\RMS\RMSAPI\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>