[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\RMS\RMSAPI\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>