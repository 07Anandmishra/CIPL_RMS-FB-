<?php echo e($slot); ?>

<?php /**PATH D:\RMS\RMSAPI\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>